"""Validate the prepared patch, or publish with explicit --publish and a write-capable HF login."""
import argparse, hashlib, json, os, subprocess, sys
from pathlib import Path
from huggingface_hub import HfApi, CommitOperationAdd, hf_hub_download

BASE = 'fcbe6277ca34c6a5dd4a15d82e4f0654b46ffbee'
REPO = 'maxwellinked/time-lapse-artifacts'
PACKAGE = Path(__file__).resolve().parent
MANIFEST = json.loads((PACKAGE/'files.json').read_text())

def digest(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

def run(root,*args):
    subprocess.run(args,cwd=root,check=True)

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source-root',required=True,type=Path,help='Clean HF Git checkout at the documented baseline')
p.add_argument('--publish',action='store_true')
a=p.parse_args();root=a.source_root.resolve()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==BASE, 'Checkout must match the reviewed baseline'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root).strip(), 'Checkout must be clean'
for f in MANIFEST:
    src=PACKAGE/'source-files'/f['path']
    assert digest(src)==f['sha256'], f['path']
    target=root/f['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(src.read_bytes())
run(root,sys.executable,'tools/validate_metadata.py','metadata.csv','--pre-standard-metadata','Pre_Standard_Time_Lapses/metadata.csv','--fragment-relationships-root','Standard_Time_Lapses/Provenance')
run(root,sys.executable,'tools/validate_recording_timing.py','--root','.')
if not a.publish:
    print('Prepared source files installed and validated locally. Publication not requested.');sys.exit(0)
api=HfApi()
assert api.whoami()['name']=='maxwellinked', 'Select the repository owner account'
assert api.repo_info(REPO,repo_type='dataset').sha==BASE, 'Remote source advanced; review before publication'
first=api.create_commit(REPO,repo_type='dataset',parent_commit=BASE,
    commit_message='Restore 168 documented local-ingest source filenames',
    operations=[CommitOperationAdd(path_in_repo=f['path'],path_or_fileobj=str(root/f['path'])) for f in MANIFEST])
run(root,'git','fetch','--depth','1','origin',first.oid)
paired=root/'viewer/recording_physical_references.parquet'
with paired.open('rb') as f: pointer=f.read(128).startswith(b'version https://git-lfs.github.com')
if pointer:
    downloaded=Path(hf_hub_download(REPO,'viewer/recording_physical_references.parquet',repo_type='dataset',revision=BASE))
    paired.write_bytes(downloaded.read_bytes())
run(root,sys.executable,'tools/build_workflow_subsets.py','--write','--source-revision',first.oid,'--check-loading')
outputs=['viewer/'+n+'.parquet' for n in ['canonical','pre_standard','standard_earlier','standard_individual_recordings']]+['viewer/native_viewer.manifest.json']
second=api.create_commit(REPO,repo_type='dataset',parent_commit=first.oid,
    commit_message='Refresh native tables for source-filename enrichment',
    operations=[CommitOperationAdd(path_in_repo=n,path_or_fileobj=str(root/n)) for n in outputs])
for f in MANIFEST:
    remote=Path(hf_hub_download(REPO,f['path'],repo_type='dataset',revision=second.oid))
    assert digest(remote)==f['sha256'], 'Published source verification failed: '+f['path']
for n in outputs:
    remote=Path(hf_hub_download(REPO,n,repo_type='dataset',revision=second.oid))
    assert digest(remote)==digest(root/n), 'Published table verification failed: '+n
print(json.dumps({'published_revision':second.oid,'source_revision':first.oid,'url':second.commit_url},indent=2))
