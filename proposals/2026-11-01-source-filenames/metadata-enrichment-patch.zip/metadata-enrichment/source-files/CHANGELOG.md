# Changelog

## 2026-11-01 - Restore documented local-ingest source filenames

Fill exactly 168 blank Standard `original_filename` cells from the literal
source basenames already published in the frozen Timing v2 observations.
Retain all existing nonblank metadata, record identities and media bytes.
These local-ingest basenames may already follow the canonical naming convention;
they do not establish camera-original names, device provenance or recording clocks.

Add an exact SHA-bound correction receipt and a narrowly checked inverse for
historical timing-v1 validation. The original 549-row metadata receipt and frozen
timing evidence remain unchanged. Wrong names, unrelated cell edits, changed
media identities, altered receipts and changed observations are rejected.

## 2026-11-01 - Publish reviewed photograph access and October 31 recordings

Add the reviewed full-size photograph collection with source fingerprints,
dimensions, direct viewing links and independent relationship evidence.
Preserve the 435 current photograph selections and their original authority.
Assistant visual matches remain provisional; unmatched sources remain unassigned.
Multiple photographs of different drawings may link to one recording.

Retain 38 unchanged original MP4s (12,674,601,564 bytes) for one
creator-confirmed drawing, finished October 31 at 10:40, in confirmed
capture order. Keep the edited export separate. Preserve all prior recording
identities and add one work ID, with no automatic selected-front promotion.
Canonical metadata, checksums, work links and derived access tables are
refreshed together. Drawing-level finish labels do not establish individual
recording end times, recording starts, continuity or completeness.

Current totals: 1,349 Standard and 128 Pre-Standard recordings;
1,477 indexed time-lapses, 436 active works and 1,294 confirmed work links.
The 18 separately indexed real-time recordings retain their existing scope.

## 2026-10-31 - Clarify archive framing and timing evidence

Introduce the 435 active `work_id` values near the opening and describe the
dataset's origin as presenting the drawing process as data. Consolidate repeated
photograph and movement summaries, keeping the experimental findings and their
publication scope with the relevant evidence.

Distinguish recording-start declarations from elapsed-time estimates and explain
how selected real-time references can support testing a shared timing model.
The recent 7:1 relationship and its applicable cohort remain under investigation.
Clarify that null images in the current work-based view do not imply absent
physical-reference evidence; update the coverage generator with that wording.
Photograph display selection and source reconciliation remain ongoing.

Correct the first browsing anchor by a 90-degree clockwise rotation of the
existing display pixels, encoded losslessly with its input identity recorded.
Source media, work memberships, timing values and archived reference images
retain their existing bytes and identities.

## 2026-10-29 - Restore two retained F recordings and clarify support units

Add the two unchanged, previously deferred recordings so all eleven retained F
recordings can be inspected together for drawing progression and the evidence
supporting their order. This restores access to omitted source material while
keeping capture continuity and sequence completeness explicitly unknown.

The two complete original MP4s are retained as Rec03a and Rec03b, preserving
168,573,117 source bytes. F now contains all 11 retained files totaling
4,098,410,930 bytes. The registered supplement places them between Rec03 and
Rec04; order is visually inferred with device-metadata corroboration, while
membership is owner-confirmed. Completeness remains unknown and gapless capture
is not established. Preserve the nine earlier file identities and their dated
release packet, including Rec03's 3,343 coded / 3,342 presented frame qualification.

Current totals are 1,305 Standard and 128 Pre-Standard recordings, or 1,433
indexed time-lapse files. The individual-recording workflow has 941 files and
the earlier Standard workflow 364. The two additions retain blank work IDs and
true null images; 1,205 Standard rows retain their selected photographs and 100
have null images. Positive work links remain 1,256 across 435 active works.
Paired, native and workflow access tables bind the actual metadata-bearing
source revision and preserve earlier selected photograph cells and bytes.

The two recording-start candidates are unresolved. Active ledger coverage is
941 candidates: 607 supported and 334 unresolved, retaining
`pause_systemic_timing_uncertainty`. The current timing observation view remains
841 records, with 592 outside it. The timing pilot remains closed and
inconclusive; process images remain deferred.

The separate checksum-bound owner confirmation clarifies 9 × 12 inches for the
47 existing recordings in the nine reviewed groups, as explicitly scoped by
its record IDs. It preserves literal dimension tokens and does not assign units
to records outside that correction.
Historical counts, evidence packets and sealed ledgers retain their original scope.

## 2026-10-29 - Add 47 unchanged source recordings

Add 47 unchanged MP4s / 29,532,133,448 bytes in nine owner-reviewed groups. Keep
the two unordered F recordings deferred and retain F's selected nine-of-eleven
coverage with completeness unknown. Shared finish labels describe the drawing
or group, never each file's start or stop. The selected recording with 3,343
declared samples and 3,342 default FFmpeg presented frames retains its documented
edit-list qualification; the original bytes remain unchanged.

The Standard index contains 1,303 recordings; with 128 Pre-Standard recordings,
the time-lapse population is 1,431. The 47 additions have blank work IDs, keeping
1,256 positive links and 435 active registered works unchanged. Refresh paired,
native and workflow access tables from the actual metadata-bearing source
revision. Preserve all previous selected image cells; new rows have true null
images. No new photograph or experiment representation is released.

The 47 new recording-start candidates are unresolved. Cumulative active timing
coverage is 939 candidates, 607 supported and 332 unresolved; the independent
`pause_systemic_timing_uncertainty` result remains. The current timing observation
view stays at 841 records, leaving 590 outside that view. Prior frozen packets,
sealed ledgers and historical release counts retain their original scope.

## 2026-10-25 - Complete front masters and correct July 25 drawing identity

Creator review confirms that the existing July 25 10:17 and 19:16 recordings show
two stages of one physical drawing. Retain `tlaw-858a03eb138fbf47` as the active
administrative survivor and preserve `tlaw-b03bbfba8babbf3d` as superseded. Both
recordings and all source media remain unchanged. Current coverage is 437 permanent
IDs, 435 active works, two superseded IDs and 1,256 positive Standard links.

The checksum-bound creator confirmation and correction ledger accompany the
registry and generated index correction. The paired projection retains the
survivor's existing selected display for both recordings: 1,205 Standard rows
remain illustrated across 430 active works, with 51 Standard rows/five works
without a selected display and all 128 Pre-Standard images null. Current workflow
views and native Parquets are rebuilt with explicit current-input hashes and the
unchanged immutable media pin. Historical photographs, status layers and
validation receipts retain their dated revision-specific meanings.

The selected-front master download index adds the five creator-confirmed fronts
for 51 recordings and retires one redundant July 25 JPEG path with its source
binding preserved. All 435 active works now have a distinct master JPEG: 159
native-resolution, 274 limited-resolution and two supplied-source-resolution.
Original sources and prior immutable releases remain unchanged.

## October 25 explicit source recording mode

- Append the authoritative `recording_mode` field to the three source recording
  indexes: `time_lapse` for 1,256 Standard and 128 Pre-Standard records,
  `real_time` for five real-time records. Preserve every prior field value and
  row order, including acquisition protocols, blank real-time work IDs, and
  qualified candidate relationships.
- Advance the shared time-lapse schema from 35 to 36 fields and the separate
  real-time schema from 23 to 24. Carry the source field through the two workflow
  CSVs and four native recording Parquets, with matching feature declarations
  and source/output bindings. Keep the reduced 18-field paired-photograph
  projection and its image bytes unchanged.
- Add source-mode projection/validation and rejection of missing or conflicting
  modes. Establish the Hugging Face source indexes and schemas as the authority
  for future metadata changes; the GitHub browser consumes pinned projections.
  Mode adds no calibrated timing, capture-interval, work-identity, source-lineage,
  or recording-continuity claim.

## October 25 timing counts and evidence navigation

- Reconcile the current timing view with both active indexes: 841 covered
  records plus 543 outside the view equals 1,384 indexed time-lapse files.
  The outside population comprises 492 historical records and the 51-record
  October 23 ingest; the separate wall-clock ledger retains those later starts
  as unresolved. Add a regression check for both current prose summaries.
- Correct the photograph guide to follow the current manifest's hash-bound
  predecessor for retained selection evidence, checking exact source/display
  pairs. Distinguish the paired projection's populated source URLs from the
  separate 431-photograph download index.
- Clarify the separate Standard and Pre-Standard indexes and link existing
  identity, photograph, timing and October 23 validation evidence from the
  documentation index. Media, metadata, identities, selections and historical
  evidence are unchanged.

## October 24 README clarity

- Describe recorded contents and collection origins directly; attribute physical
  retention to the creator and preserve each relationship's evidence scope.
- Bring collection selection and browsing ahead of photograph details, linking
  implementation mechanics to the existing projection guide.
- Distinguish the current 431-of-436 display-selection coverage from the retained
  431-work selection table and the older 841-row loading example.
- Consolidate repeated limits and remove the speculative annotation-study sentence.
  Media, indexes, identities, selections, and historical receipts are unchanged.

## October 23 coordinated ingest

- Published in revision `ed96dab85dea93af4e3a36785a02b90fdeebb976`.
  At this revision, the indexed holdings are 1,256 Standard plus 128
  Pre-Standard time-lapse files (1,384 total), and five separately indexed
  real-time MOVs. The Standard workflow views partition those 1,256 files
  into 364 earlier and 892 individual-recording rows. The registry contains
  437 permanent work IDs (436 active and one superseded), with 1,256 positive
  canonical links. Real-time MOVs are excluded from the five native Parquet
  configurations and all time-lapse totals.
- Add 51 unchanged MP4s and five confirmed work identities, with completeness unknown.
- Preserve five real-time MOV representations in a separate index, including reader timestamp qualifications and candidate pairings.
- Attach 333 displayed-clock readings to 125 checksum-bound time-lapse identities; no external calibration or archive-wide conversion.
- Refresh recording views while preserving prior photograph selections and null images for new works.
- Retain the established audit clarifications and historical evidence scopes.

## Unreleased — work-level high-resolution primary layer

- Add the work-centric `Work_Images` layer with one active research-grade
  `high_res_primary` and its exact `low_res_display` derivative for
  `tlaw-794f3c7a1e5a05b6`.
- Bind both objects to full SHA-256 identities, work-level owner authority,
  preserved capture and reviewed-parent lineage, ICC profiles, a pinned
  deterministic display recipe, sanitized receipts, and complete local
  checksums.
- Preserve the existing `Physical_References` object and its historical
  `proposed` relationship unchanged. The new selection adds no recording
  endpoint, timing, completeness, finish-state, or frame-alignment claim.
- Keep drawing-photograph, recording, and website projections unchanged in this
  first additive ingest; each requires a later separately reviewed regeneration.
- Apply the repository's CC BY-NC 4.0 scope to eligible material in the new
  layer, without independently granting rights in incidental third-party
  content.

## Unreleased — native Parquet Viewer inputs

- Change all five access configurations to source-controlled native Parquet
  inputs while retaining configuration names, the `archive` split, default
  `canonical` view, and typed video features.
- Add reproducible recording-table generation, source/output hash bindings, and
  drift/loading checks to the existing workflow maintenance procedure. Retain
  the paired Parquet bytes and its existing photograph/null semantics.
- Loading an access table retains pinned video references rather than fetching
  all referenced MP4s. Intentional offline media access uses the existing
  verified downloader. Source indexes, media, work identities, and provenance
  are unchanged. Hosted readiness requires checks after a reviewed merge.

## Unreleased — October 13 Pre-Standard physical-reference publication

- Added a versioned public relationship layer for all 128 Pre-Standard
  records: `record_physical_links.csv`, `SCHEMA.md`, `CONFIRMATION.md`,
  `MANIFEST.json`, and a public validator.
- The 128 unique rows resolve at source revision
  `275fef5594ae6302af4f6ee4edaa9d5b6f724e83` and comprise 84
  photograph-to-reviewed-frame links, eight direct in-hand
  front-to-reviewed-frame links, and 36 record-level physical references.
- Supporting photographs, their identifiers, and the in-hand observations
  remain private, so the public release does not make those comparisons
  independently reproducible.
- This layer assigns no `work_id`, merges no drawings across recordings, and
  makes no whole-recording membership, endpoint, final-state, finish-date,
  physical-dimension, sequence-boundary, or process-completeness claim. Active
  media, indexes, and work-identity membership are unchanged.
- The relationship layer was published in content revision
  `64bb5d3645c6f4221dd5229901e64ef1670f7570`; this changelog-only follow-up
  records that publication.

## October 3–5 complete-drawing ingest — historical snapshot

The counts below describe revision
`86ea9b15d045ace96932dc2d5d0d0dc10114cea4`, not the current archive.

- Added 67 unchanged-source silent HEVC Standard recordings across ten
  owner-reviewed complete drawing sequences. One of the 68 selected clips was
  an exact duplicate of an existing October 2 recording and was not added
  again. Original source files remain unchanged.
- Added 27,031,631,328 source bytes and 5206.413898 encoded playback seconds.
  Membership at that revision was 1,106 Standard plus 128 Pre-Standard files, or 1,234
  unique indexed videos; the Standard views contain 364 earlier and 742
  individual-recording rows. The registry held 426 permanent work IDs (425
  active and one superseded) and 1,106 positive canonical links.
- Added three dated relationship packets and three corresponding timing
  packets. The dated packets contain 742 canonical fragments and five
  historical derivatives across 28 packets; the timing view then covered
  742 rows, with 514 filename-derived starts and 228 unknown starts.
- The published content revision is
  86ea9b15d045ace96932dc2d5d0d0dc10114cea4. Its 67 new media objects,
  active indexes, checksums, identity joins, and four Viewer configurations
  passed post-merge checks. Historical evidence, release tags, and DOI
  snapshots remain scoped to their own revisions.

## Unreleased — October 5 work-identity correction

- Recorded the creator's correction that the Batch 64 A and B recordings from
  July 19–20 document one continuous physical drawing.
- Retained `tlaw-7e236cd354b11f35` as the active administrative survivor,
  superseded `tlaw-dfe3358c5e5b0cdc`, and reassigned record
  `tla-bdbd7d2e290b638a` to the survivor. The first-day tie-breaker is an
  administrative choice, not drawing-finish evidence.
- The registry remained at 416 permanent work IDs while its status population
  changed from 416 active and zero superseded to 415 active and one
  superseded. The positive-link row count remained 1,039; active media and
  index membership were unchanged.
- The corrected identity state was published in content revision
  `388223d3612c4598cc1baa15a125f09a9d303bcf`.

The earlier unreleased entries below are historical batch snapshots. Their
counts describe the named stage, not the current archive.

## Unreleased — September 26–October 2 complete-drawing ingest

- Added 116 unchanged-source Standard recordings in 15 owner-confirmed complete drawing sequences. Finish labels remain drawing/group finishes. Original source names and SHA-256 mappings are retained.
- Added 44,623,870,811 source bytes and 8589.946528 encoded playback seconds. Active membership is 1,039 Standard plus 128 Pre-Standard records, 1,167 indexed videos, 416 active work IDs, and 1,039 positive canonical links.
- Added five relationship/timing packets; the earlier September 26 packet is unchanged. The current timing view covers 675 rows: 457 literal device-filename starts and 218 unknown starts.
- The original source audit and files are retained; the focused source-label note records the narrow mappings. Previous rows, media identities, historical receipts, release tags and DOI snapshots are preserved.

## Unreleased — September 21–26 complete-drawing ingest

- Added 178 unchanged-source Standard recordings in 21 creator-confirmed complete drawings. The supplied finish labels remain drawing/group finishes, not individual video stops.
- Added 65,260,888,567 source bytes and 12592.805567 encoded playback seconds. Active membership is 923 Standard plus 128 Pre-Standard records, 1,051 indexed videos, 401 active work IDs, and 923 positive canonical links.
- Added six dated 15-field relationship packets and six revision-pinned timing packets. The current timing view now covers 559 rows: 357 literal device-filename starts and 202 unknown starts; 492 historical records remain outside the current view.
- Preserved one malformed literal source name verbatim and recorded only the owner's narrow Rec18 membership resolution; no per-record material or stop-time inference was added.
- Preserved all previous rows, media identities, historical evidence, immutable release tags, and DOI-backed snapshots.

## Unreleased — September 20 two-drawing ingest

- Added 28 unchanged-source Standard recordings in two creator-confirmed
  complete drawings: 12 with the `2026-09-20.0725.BallpointPen.Ink.Paper.9x12`
  finish label and 16 with the `2026-09-20.1738.FountainPen.Ink.Paper.9x12`
  finish label. These are drawing/group finishes, not individual video stops.
- Added 9,220,341,108 source bytes and 1796.581714 encoded playback seconds.
  Active membership is 745 Standard plus 128 Pre-Standard records, 873
  indexed videos. The two new confirmed work IDs raise the current
  registry to 380 drawings and 745 positive canonical links; 128
  Pre-Standard records remain unlinked.
- Added a 28-row dated relationship packet: 381 prospective canonical
  fragments and five historical derivative rows now occupy fourteen
  packets spanning thirteen calendar dates. The living current
  timing view adds 26 filename-derived starts and two unavailable
  starts, while the frozen 339-row Timing v2 snapshot is unchanged.
- Preserved all previous rows, media identities, historical evidence,
  immutable release tags and DOI-backed snapshots.

## Unreleased — documentation consolidation

- Focused the dataset card on collection selection, file/drawing identity,
  timing interpretation, evidence limits, access, rights, and citation. Moved
  detailed release comparisons and DOI BibTeX to the release guide and linked
  the existing maintenance instructions.
- Standardized archive totals as indexed video files; broadened provenance to
  cover documented file origins and relationships; distinguished retrospective
  dataset organization from prospective acquisition and downstream study design.
- Replaced stale current-cohort counts in acquisition specifications with links
  to generated coverage. Clarified the active 35-field schema.
- Pinned the loading example to a revision containing all four configurations.
  Updated only the workflow generator's documentation template and the existing
  origin-wording assertion so regeneration and validation retain these edits.
- Media, indexes, registry assignments, timing/relationship evidence, checksum
  manifests, configuration front matter, and frozen releases are unchanged.

## Unreleased — September 19 two-drawing ingest

- Added 14 unchanged-source Standard recordings: nine for the
  `2026-09-19.0541.BallpointPen.Ink.Paper.9x12` drawing and five for
  `2026-09-19.1825.BallpointPen.Ink.Paper.9x12`. The creator supplied the
  two complete drawing sets and their local finish labels. These are
  drawing/group finishes, not individual recording stop times.
- Added 10,045,638,676 source bytes and 1944.980380 encoded playback
  seconds. Active membership is 717 Standard plus 128 Pre-Standard records,
  845 indexed videos total. The two new owner-confirmed work IDs raise the
  optional registry to 39 drawings and 374 positive recording links; 471
  indexed records remain unlinked.
- Added a fourteen-row dated relationship packet: the active prospective
  sidecars now contain 353 canonical fragments and five historical derivative
  rows across thirteen packets spanning twelve calendar dates. The active
  35-field schema, frozen 339-row Recording Timing v2 cohort, and its 163
  observed starts remain unchanged; the 14 new rows are outside that timing
  snapshot. Source-name clocks, MP4 creation tags, and drawing finishes
  remain separate observations.
- Preserved the prior 703 Standard rows, 128 Pre-Standard rows, record IDs,
  video objects, historical evidence, and tagged release receipts. No
  version tag or DOI record is changed by this ingest.

## v0.7.0 (2026-09-19)

### Confirmed drawing IDs in Dataset Viewer

- Exposed the registry's `work_id` immediately after `record_id` in both active
  indexes and Viewer configurations: 35 fields per tier.
- Copied the 360 existing creator-confirmed memberships across 37 drawings;
  left 471 unresolved records blank. Registry rows and confirmation history
  are unchanged; no new drawing identities or completeness claims are inferred.
- Added a reproducible projection and validation command with regression tests.
  All prior 34 field values, recording IDs, filenames and media remain unchanged.
- Included this display change in the v0.7.0 release receipt.


### Release scope

This release builds on the verified media and registry content at `521f4ee62ee3843cf36394499c10bf33f07dcaae`:
703 Standard and 128 Pre-Standard video records, with an optional registry of
37 creator-confirmed drawings and 360 recording links. Relative to v0.6.0,
74 unchanged-source recordings are added: 73 prospective fragments across four
complete drawing sequences and one historical August 20 Rec02. The recordings
add 68,125,363,425 bytes and 9,830.501363 seconds of encoded playback.

### Clear recording-start and finish labels in Dataset Viewer

- Added five explicit timing-display columns to both active indexes and Viewer
  configurations. The original 29 field values, all video paths and record IDs
  remain unchanged; with `work_id`, the Viewer exposes 35 fields per tier.
- Projected 163 existing filename-derived starts from Recording Timing v2;
  kept 176 reviewed unknown starts blank and identified 492 records outside
  that snapshot. No new start or stop observations are inferred.
- Added documented-finish aliases and an explicit finish-label scope so shared
  drawing/group completion labels are distinguishable from recording starts.
- Added a reproducible projection validator and regression coverage. Historical
  evidence packets and tagged releases remain byte-for-byte unchanged.


### Repository navigation

- Grouped the six release manifests under `releases/` and supporting archive,
  validation and Viewer-migration documents under `docs/`, reducing the root
  from 22 entries to 15. Folder indexes and active links point to their new homes.
- Preserved prior manifest bytes and immutable release/tag paths. Receipt paths
  inside historical manifests still refer to their declared historical revisions.
  Canonical media, metadata, schema, checksums and evidence packets stay in place.

### Per-record timing evidence

- Added the optional Recording Timing v2 table for all 339 prospective recordings
  across 33 owner-confirmed works. All 339 have retained MP4 format creation
  timestamps; 316 also have matching retained video-stream tags. Filename-based
  starts are available for 163 recordings, while 176 starts remain unknown.
- Published a projection from 13 retained ingest audits, checksum-bound source
  receipts, field definitions, a validator and regression tests. The validator
  preserves the frozen cohort when unrelated later index rows are added.
- Kept creation/finalization observations separate from filename-derived starts
  and canonical group-finish labels. Observed intervals are not validated capture
  durations. No model-estimated starts are inserted into this table.

### Work identity and compatibility

- Added the optional `Work_Identity/` registry with opaque permanent work IDs,
  revision-pinned record joins, and owner-confirmation evidence. Coverage remains
  partial: 471 indexed records are unlinked; an absent link means unknown.
  Different IDs are not independently verified negative pairs for benchmarking.
- Preserved all previous record IDs and media bytes. The documented September 1
  correction renames 12 active paths from `02:13` to `14:13` and updates their
  time labels; the correction ledger preserves the historical path joins.
- Backfilled repository-ingest provenance for 12 August 3–9 records from commit
  history. These updates describe repository history without asserting capture origin.
- Clarified file, recording, work, playback-rate, and source-origin semantics,
  including the limits of file-size comparisons. The original 29 fields remain compatible; five timing-display fields are
  added to the active indexes; the work registry adds a separate optional identity layer.
- Preserved all earlier fragment packets, Recording Timing v1, physical-reference
  data, release manifests, and the v0.5.1 DOI snapshot. Timing validation retains
  the documented correction and verifies the later Rec02 exclusion when
  reconstructing the original pinned snapshot.

Release preparation adds the five-file Recording Timing v2 packet and its
validator/tests, updates the release documents, groups supporting documents and
release receipts into folders, and binds the final tree in
`releases/RELEASE_MANIFEST_V0.7.0.json`. It preserves all media, canonical
indexes, work assignments, dated relationship packets and checksum entries.
The final manifest is added alone after all other release bytes are fixed.
The detailed entries below retain the scope and evidence of each earlier change.

### August 20 Rec02 historical backfill

- Preserved filename sorting and the exact historical timing snapshot with a checksum-bound exclusion for this later ingest; 22 timing regression tests pass.
- Added one owner-confirmed Rec02 (28,666,390,097 bytes) after full
  video/audio decode and local SHA-256 validation; preserved its exact filename.
- Added persistent record `tla-85cdf161df0b807e` and linked it to existing work
  `tlaw-2f587c509d7e6909`, completing the owner's two-recording set.
- Active totals: 703 Standard plus 128 Pre-Standard videos; registry totals:
  37 drawings and 360 linked recordings. Existing records, media, historical
  evidence, release tags, and website previews are unchanged.
- Retained the historical filename time label without asserting a new exact
  finish time, direct-device origin, gapless capture, or prospective protocol membership.

### September 18 two complete drawing-sequence ingestion

- Added 29 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 17,385,403,635 bytes and 3387.532426 seconds of encoded playback.
- Preserved two complete drawings as independently numbered `RecNN` source
  sequences containing 9 and 20 canonical fragments. Their creator-supplied
  group finish labels are September 18, 2026 at 02:44 and 14:44; neither is an
  asserted individual recording end time.
- Increased active membership to 702 Standard plus 128 Pre-Standard records,
  or 830 total, without changing the 29-field schema or 363 earlier-workflow
  Standard rows.
- Added one 29-row, 15-field `2026-09-18` relationship packet containing two
  complete groups and no derivatives. Prospective packet-defined membership is
  now 339 canonical fragments across twelve packets spanning eleven calendar
  dates and 33 complete groups; Recording Timing v1 remains unchanged.
- Preserved all 29 exact source names. The 27 literal `VID_*` start clocks,
  29 MP4 creation/finalization observations, filesystem timestamps, and two
  creator-supplied group finishes remain separate evidence.
- Verified 29/29 ordinary SHA-256 values, 29/29 full HEVC decodes, and 87/87
  decoded start/middle/end samples. Container declarations, stored packets,
  presentation reads, and decoded frames all total 101,627;
  no exception is accepted.
- Bound media at immutable media-only PR revision `e05a264107caa380f20a8bb036d0335ba73f01c9`; the new
  sidecar pins metadata-bearing revision `d3e4da0bb5dd3eb573f561f588f4792b93fbd88b`.
- Retained media-object-level `record_id` identity. This update adds no global
  `work_id`, release tag, DOI change, Recording Timing extension, or mirror
  deployment.

### June 2026 historical file relationship

- Added a revision-pinned provenance note recording Tim's confirmation that the
  15 existing June 18–30, 2026 `FountainPen.Ink.IllustrationBoard.30x40`
  `Rec01`-`Rec15` files document one physical drawing and that `RecNN`
  establishes file order.
- Preserved all active media, paths, record IDs, metadata, checksums,
  `UnknownTime` values, blank provenance fields, and protocol assignments. The
  note does not assert internal recording or session boundaries, per-file
  recording counts, overall completeness, shared finish timing, raw-source
  status, uninterrupted capture, a global `work_id`, or new cohort membership.

### September 1 finish-time correction

- Corrected the creator-supplied finish label for the complete 12-fragment
  drawing sequence from September 1, 2026 at `02:13` to `14:13`
  `America/New_York`. Tim confirmed that the whole drawing finished at 14:13,
  and the physical inscription reads `2:13 PM ET`. A separate start-reference
  image displays `10:26`; it is start evidence, not finish evidence.
- Renamed exactly `Rec01`-`Rec12` from
  `Standard_Time_Lapses/2026-09-01.0213.BallpointPen.Ink.Paper.9x12.RecNN.mp4`
  to
  `Standard_Time_Lapses/2026-09-01.1413.BallpointPen.Ink.Paper.9x12.RecNN.mp4`
  by server-side copy/rename, and updated the same 12 active metadata times
  from `02:13` to `14:13` plus their active `SHA256SUMS` paths.
- Preserved all 12 `record_id` values, ordinary SHA-256 values, Hub Xet
  identities, byte sizes, sequence order, acquisition-protocol assignments,
  and media bytes. The exact mapping is recorded in
  [`finish_time_correction.csv`](Standard_Time_Lapses/Provenance/Corrections/2026-09-01.1413-finish-time/finish_time_correction.csv).
- Kept the revision-pinned `2026-09-02` relationship packet, Recording Timing
  v1 bundle, and existing release artifacts byte-identical. Their `02:13`
  paths, labels, and 43,221-second conflict remain historical evidence. Against
  the corrected active `14:13` finish minute, the retained final MP4 boundary
  is 21 seconds later.
- Added a focused provenance record and correction-aware validation. No
  photograph or photograph hash is published or asserted, and this correction
  creates no release tag or DOI.

### September 17 11:40 complete drawing-sequence ingestion

- Added 23 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 10,419,300,996 bytes and 2010.846325 seconds of encoded playback.
- Preserved one complete drawing as an ordered `RecNN` source sequence containing
  23 canonical fragments. The creator-supplied group finish label is September
  17, 2026 at 11:40; it is not an individual fragment end time.
- Increased active membership to 673 Standard plus 128 Pre-Standard records, or
  801 total, without changing the 29-field index schema or the 363 earlier-workflow
  Standard rows.
- Added a 23-row, 15-field `2026-09-17` relationship packet
  containing one complete group and no derivative rows. Prospective packet-defined
  membership is now 310 canonical fragments across eleven packets spanning ten
  calendar dates and 31 complete groups; timing v1 remains fixed at its historical
  186-fragment scope. Both earlier `2026-09-16` packets remain byte-identical.
- Preserved the exact transferred source name in `original_filename` for all 23
  rows, including 22 literal `VID_*.mp4` names and the descriptive final name.
- Verified 23/23 local SHA-256 values, 23/23 full HEVC decodes, and 69/69
  decoded start/middle/end frame samples with zero decoder errors. Container
  declarations and stored packets total 60,326; presentation-read and
  decoded presentation frames total 60,325. The exact one-frame
  difference is Rec05's single MP4 edit-list presentation-timeline trim (media time 3000,
  time base 1/90000), not evidence of payload corruption.
- Bound the 23 media objects at immutable media-only PR revision
  `3843a9b320df45cd7065f5e54d0609276be0530a`; the new relationship sidecar pins metadata-bearing
  revision `21648a6a76b9174d32a4a3314cbe490219fc2151`.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, alter the immutable v0.5.0, v0.5.1, or v0.6.0 release
  receipts or DOI registration, extend Recording Timing v1, tag a release, or
  deploy a downstream mirror.

### September 16 20:43 complete drawing-sequence ingestion

- Added 21 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 11,654,268,697 bytes and 2241.410613 seconds of encoded playback.
- Preserved one complete drawing as an ordered `RecNN` source sequence containing
  21 canonical fragments. The creator-supplied group finish label is September
  16, 2026 at 20:43; it is not an individual fragment end time.
- Increased active membership to 650 Standard plus 128 Pre-Standard records, or
  778 total, without changing the 29-field index schema or the 363 earlier-workflow
  Standard rows.
- Added a separate 21-row, 15-field `2026-09-16.2043` relationship packet
  containing one complete group and no derivative rows. Prospective packet-defined
  membership is now 287 canonical fragments across ten packets spanning nine
  calendar dates and 30 complete groups; timing v1 remains fixed at its historical
  186-fragment scope. The earlier `2026-09-16` packet remains byte-identical.
- Preserved the exact transferred source name in `original_filename` for all 21
  rows, including 20 literal `VID_*.mp4` names and the descriptive final name.
- Verified 21/21 local SHA-256 values, 21/21 full HEVC decodes, 63/63
  decoded start/middle/end frame samples, and 67,243/67,243
  declared/read/packet/decoded video frames.
- Bound the 21 media objects at immutable media-only PR revision
  `bf4be15ac295fbf631766650660c9b441448c807`; the new relationship sidecar pins metadata-bearing
  revision `ef3a865301091d42e13515d0f5c45bc323c1470e`.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, alter the immutable v0.5.0, v0.5.1, or v0.6.0 release
  receipts or DOI registration, extend Recording Timing v1, tag a release, or
  deploy a downstream mirror.

## v0.6.0 — Release (2026-09-16)

This release freezes the verified 757-record snapshot after the September 15
and 16 drawing-sequence ingests and the intervening dataset-card and helper
maintenance: 629 canonical Standard records plus 128 active Pre-Standard
records. Release preparation changes documentation and adds a versioned receipt
only; it does not change an active index, relationship sidecar, checksum entry,
media path, or media payload.

### September 16 complete drawing-sequence ingestion

- Added 25 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 6,287,296,691 bytes and 1203.554337 seconds of encoded playback.
- Preserved one complete drawing as an ordered `RecNN` source sequence containing
  25 canonical fragments. The creator-supplied group finish label is September
  16, 2026 at 01:22; it is not an individual fragment end time.
- Increased active membership to 629 Standard plus 128 Pre-Standard records, or
  757 total, without changing the 29-field schema or the 363 earlier-workflow
  Standard rows.
- Added a separate 25-row, 15-field September 16 relationship sidecar containing
  one complete group and no derivative rows. Prospective sidecar-defined
  membership is now 266 canonical fragments across nine dated sidecars and 29
  complete groups; timing v1 remains fixed at its historical 186-fragment scope.
- Preserved the exact transferred source name in `original_filename` for all 25
  rows, including 24 literal `VID_*.mp4` names and the descriptive final name.
- Verified 25/25 local SHA-256 values, 25/25 full HEVC decodes, 75/75
  decoded start/middle/end frame samples, and 36,107/36,107
  declared/read/packet/decoded video frames.
- Bound the 25 media objects at immutable media-only PR revision
  `d365fd2dceecd06338c4f5fad823e47b2b830ef1`; the new relationship sidecar pins metadata-bearing
  revision `a2e0d8a25d1ba02336ff8260dac18822ece7cfaa`.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, alter the immutable v0.5.0 or v0.5.1 release receipts or
  DOI registration, extend Recording Timing v1, tag a release, or deploy a
  downstream mirror.

### Dataset-card and helper maintenance

- Condensed the dataset card around archive scope, current-versus-DOI coverage,
  loading, interpretation, evidence limits, integrity, rights, and citation while
  preserving the declared Hub configuration and schema metadata.
- Corrected `tools/download_verified.py` so a record's media path is resolved
  relative to the index that contains it. Pre-Standard basenames now resolve
  under `Pre_Standard_Time_Lapses/` while Standard repository-relative paths
  remain unchanged.
- Hardened `tools/enrich_prestandard.py` to preserve valid persistent
  `record_id` values, generate IDs only for blank fields, reject invalid or
  duplicate IDs before probing, and reuse probe results only when repository,
  revision, path, Xet identity, and byte size all match.
- Added nine focused offline regression tests for the two helpers. No active
  metadata row, media path, media payload, checksum entry, relationship or
  timing sidecar, release receipt, tag, or DOI registration changed.

### September 15 complete drawing-sequence ingestion

- Added 23 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 9,488,375,282 bytes and 1,853.681426 seconds of encoded playback.
- Preserved one complete drawing as an ordered `RecNN` source sequence containing
  23 canonical fragments. The creator-supplied group finish label is September
  15, 2026 at 12:36; it is not an individual fragment end time.
- Increased active membership to 604 Standard plus 128 Pre-Standard records, or
  732 total, without changing the 29-field schema or the 363 earlier-workflow
  Standard rows.
- Added a separate 23-row, 15-field September 15 relationship sidecar containing
  one complete group and no derivative rows. Prospective sidecar-defined
  membership is now 241 canonical fragments across eight dated sidecars and 28
  complete groups; timing v1 remains fixed at its historical 186-fragment scope.
- Preserved the exact transferred source name in `original_filename` for all 23
  rows, including 21 literal `VID_*.mp4` names and two descriptive source names.
- Verified 23/23 local SHA-256 values and complete packet-stream demuxes, 23/23
  full HEVC decodes, 69/69 decoded start/middle/end frame samples, and
  55,611/55,611 declared/countable video frames.
- Bound the 23 media objects at immutable media-only PR revision
  `491fc388b858ef7a247e531970a639c717cc8f9d`; the new relationship sidecar pins metadata-bearing revision
  `65f7a124c6f6d68f79d6cd89f9ef1b40707929b4`.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, alter the immutable v0.5.0 or v0.5.1 release receipts or
  tags, expand timing-v1 coverage, or publish a new tagged release.

## v0.5.1 — Maintenance release (2026-09-14)

### Semantic and release-documentation cleanup

- Aligned the Pre-Standard `tool` list for record
  `tla-34d3d5f4de884c6b` with its literal `.Brush.FountainPen.` filename tokens,
  changing `FountainPen` to `Brush;FountainPen` while preserving the filename,
  `record_id`, `hub_xet_hash`, encoded technical metadata, and all media bytes.
- Added an asymmetric filename-tool invariant: every exact recognized filename
  tool token must appear in active metadata, while historical Pre-Standard
  metadata may retain independently documented tools absent from a filename.
  The literal historical `Pen` token is not normalized without separate
  documentation.
- Replaced the overstated duration summary with the exact active date range,
  corrected the active video total to 2.09 TB, and added tests binding the
  active-row, date-range, and byte-total claims to both indexes.
- Replaced study/subject discovery tags with archive/creator terms and stated
  that research and model-analysis uses are retrospective to the recordings'
  original personal-practice documentation purpose.
- Clarified that the v0.5.0 and v0.4.0 manifests are pre-tag content
  receipts scoped to their declared validated revisions, not byte receipts for
  each resulting final tagged tree.
- Pinned the lightweight loading and single-record verification examples to
  `v0.5.1`, improved documentation links, and normalized the creator, title,
  version, and tag-specific URL in the current release citation.
- Added a versioned v0.5.1 release receipt that separates the validated content
  revision from the critical-file receipt revision used during release
  preparation.
- No media path, media payload, checksum entry, record identity, active-index
  membership, relationship sidecar, or encoded technical field changed.

## v0.5.0 — Release (2026-09-14)

This release freezes the 709-record snapshot after the reviewed
post-v0.4 timing-layer publication and September 14 drawing-sequence ingest:
581 canonical Standard records and 128 active Pre-Standard records. Release
preparation changed documentation and added a pre-tag content receipt only; it
did not alter an active index, relationship sidecar, checksum entry, or media
payload.

### September 14 complete drawing-sequence ingestion

- Added 32 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 9,568,508,054 bytes and 1,859.281028 seconds of encoded playback.
- Preserved two complete drawings as ordered `RecNN` source sequences containing
  four and 28 canonical fragments. The creator-supplied group finish labels are
  September 2, 2026 at 23:58 and September 14, 2026 at 16:35; they are not
  individual fragment end times.
- Increased active membership to 581 Standard plus 128 Pre-Standard records, or
  709 total, without changing the 29-field schema or the 363 earlier-workflow
  Standard rows.
- Added a separate 32-row, 15-field September 14 relationship sidecar containing
  two complete groups and no derivative rows. Prospective sidecar-defined
  membership is now 218 canonical fragments across seven dated sidecars and 27
  complete groups; timing v1 remains fixed at its historical 186-fragment scope.
- Kept `original_filename` blank for the four sources that already bore their
  canonical names and preserved the exact transferred source name for each of
  the remaining 28 rows, including 27 literal `VID_*.mp4` names.
- Verified 32/32 local SHA-256 values and complete packet-stream demuxes, 96/96
  decoded start/middle/end frame samples, and 55,779/55,779 declared/countable
  video frames. The literal container tag `com.android.capture.fps=5.000000` is
  retained without inferring real drawing time.
- Bound the 32 media objects at immutable media-only PR revision
  `0ef0f61cd0c54232baa58774713d57168e5e90de`; the new relationship sidecar pins metadata-bearing
  revision `db1d515c9626adf25207c2e844c913d74dba438f`.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, alter the historical v0.4.0 pre-tag content receipt, or
  expand timing-v1 coverage.

### Exploratory recording-timing sidecar

- Added a revision-pinned, noncanonical timing layer for the 186 canonical
  Framelapse fragments in the six dated relationship sidecars.
- Recorded 22 retained device-filename start observations and matching MP4
  finalization boundaries; used them to fit one profile-specific empirical
  elapsed-time model for 164 additional observable-profile-matched fragments.
- Preserved one 43,221-second documented-finish conflict without silently
  correcting the existing finish label. The calibration has no independent
  holdout and does not claim drawing-active time or source-frame timestamps.
- Added deterministic sidecar validation and SHA-256 inventory. No MP4,
  canonical metadata row or field, relationship sidecar, Viewer configuration,
  or root `SHA256SUMS` payload entry changed.

## v0.4.0 — Release (2026-09-03)

This release consolidates every reviewed post-v0.3 change into one
reviewable 677-record snapshot: 549 canonical Standard records and 128 active
Pre-Standard records. It adds no new media at the release boundary and retains
the exact payload identities covered by `SHA256SUMS`.

### Focused Standard protocol-version boundary

- Defined `standard-2025-07-13` as the earlier Standard workflow and
  `standard-2026-08-27` as the prospective canonical fragment-sequence
  workflow without changing the 29-field metadata schema.
- Applied `standard-2026-08-27` only to the 186 canonical-fragment
  `record_id` values in the six dated relationship sidecars from August 27
  through September 2, 2026. The remaining 363 Standard rows retain
  `standard-2025-07-13`.
- Left all 19 historical `RecNN` rows outside those sidecars on
  `standard-2025-07-13`; a `RecNN` suffix alone does not assign the prospective
  protocol or establish reviewed grouping completeness.
- Defined prospective timestamp scope: all `RecNN` members in one grouping
  share the documented finish date and finish time of the complete
  grouping/physical work. The timestamp is not an individual fragment end
  time; `RecNN` records chronological position within the group.
- Added validation for exact sidecar-to-protocol membership and shared
  prospective grouping timestamps. No MP4, path, `record_id`, Xet identity,
  byte size, technical field, provenance relationship, or `SHA256SUMS` payload
  entry changed.

### September 2 complete fragment-sequence ingestion, second batch

- Added 29 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 10,459,992,162 bytes and 2,029.979370 seconds of encoded playback.
- Preserved two complete source-recording sequences as ordered `RecNN` sets
  containing 10 and 19 canonical fragments.
- Increased active membership to 549 Standard plus 128 Pre-Standard records,
  or 677 total, without changing the 29-field schema or
  `standard-2025-07-13` protocol ID.
- Expanded the existing September 2 relationship sidecar from 32 to 61
  canonical-fragment rows and from three to five complete sequences; no
  concatenated or transcoded derivative was added.
- Left `original_filename` blank because, at ingest-audit time, the source
  files bore canonical archive names and no pre-rename device-name mapping was
  independently retained.
- Verified 29/29 local SHA-256 values and complete packet-stream demuxes, plus
  87/87 decoded start/middle/end frame samples. The literal container tag
  `com.android.capture.fps=5.000000` is retained without inferring real drawing
  time.
- Bound the 29 media objects at immutable media-only PR revision
  `9bfce508b6c6bdca12f475deb9b540f05754d8fd`; the expanded relationship
  sidecar pins metadata-bearing revision
  `7fca6fcc36d873b92a6c64fff5980e8d5afde5a6`.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, backfill historical rows, create a v3 release, or otherwise
  bump the dataset version.

### September 1–2 complete fragment-sequence ingestion

- Added 32 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 10,374,907,938 bytes and 2,027.579415 seconds of encoded playback.
- Preserved three complete source-recording sequences as ordered `RecNN` sets
  containing 12, 9, and 11 canonical fragments.
- Increased active membership to 520 Standard plus 128 Pre-Standard records,
  or 648 total, without changing the 29-field schema or
  `standard-2025-07-13` protocol ID.
- Added a separate 32-row, 15-field dated relationship sidecar containing only
  canonical fragments; no concatenated or transcoded derivative was added.
- Left `original_filename` blank because, at ingest-audit time, the source
  files bore canonical archive names and no pre-rename device-name mapping was
  independently retained.
- Verified 32/32 local SHA-256 values and complete packet-stream demuxes, plus
  96/96 decoded start/middle/end frame samples. The literal container tag
  `com.android.capture.fps=5.000000` is retained without inferring real drawing
  time.
- Bound the 32 media objects at immutable media-only PR revision
  `715d6ba31ae7dcd447d99467352bcf5ee240aa4a`; the relationship sidecar pins
  metadata-bearing revision `e9f8cb1cb909232b1e0c2c95e5db70c7f18b3878`.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, backfill historical rows, create a v3 release, or otherwise
  bump the dataset version.

### Semantic documentation clarification

- Corrected fifteen creator-confirmed June 18–30, 2026 30 × 40 in records from
  `Paper` to `IllustrationBoard` in their paths and metadata. The LFS pointers,
  payload SHA-256 values, stable `record_id` values, Xet identities, byte sizes,
  technical fields, and `Rec01`–`Rec15` order are unchanged.
- Normalized five Pre-Standard `time = 00:00` values to unknown because their
  incomplete dates do not establish documented midnight; the historical paths
  retain literal `0000` and `notes` explain the distinction.
- Restored `Brush;FountainPen`, `Ink`, and `WatercolorPaper` for one
  Pre-Standard row from explicit filename tokens without inferring positional
  tool/medium pairs. One separate row still lacks support evidence and now says
  so explicitly in `notes`.
- Aligned the Pre-Standard tool/medium rule with the canonical contract:
  observed lists are independent and token position does not establish pairs.
- Documented that `date` and `time` preserve finish labels whose recording,
  session, sequence, or work scope is not normalized in the current schema.
- Clarified that dated fragment sidecars cover reviewed ingestions rather than
  every historical `RecNN` row, and that absence does not negate a relationship.
- Relabeled the 404-row Viewer state as a pinned historical snapshot, explained
  the CSV `file_name` to loaded `video` feature mapping, and replaced broad
  raw/master/audio wording with the verified 485-of-616 stream-presence count.
- No media payload, active metadata row, record identity, or relationship
  assertion was added or removed; the fifteen path corrections preserve media
  identity.

### September 1 complete fragment-sequence ingestion

- Added 13 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 5,109,481,466 bytes and 983.556669 seconds of encoded playback.
- Preserved two complete source-recording sequences as ordered `RecNN` sets
  containing 4 and 9 canonical fragments.
- Increased active membership to 488 Standard plus 128 Pre-Standard records,
  or 616 total, without changing the 29-field schema or
  `standard-2025-07-13` protocol ID.
- Added a separate 13-row, 15-field dated relationship sidecar containing only
  canonical fragments; no concatenated or transcoded derivative was added.
- Left `original_filename` blank because, at ingest-audit time, the source
  files bore canonical archive names and no pre-rename device-name mapping was
  independently retained.
- Verified 13/13 local SHA-256 values and complete packet-stream demuxes, plus
  39/39 decoded start/middle/end frame samples. The literal container tag
  `com.android.capture.fps=5.000000` is retained without inferring real drawing
  time.
- Bound the 13 media objects at immutable media-only PR revision
  `e2094ae582c057df9d40e9bfe4dc00afed0bad2a`; the relationship sidecar pins
  metadata-bearing revision `fe66d1dbb117486c2046376423316fd2cc25d488`.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, backfill historical rows, create a v3 release, or otherwise
  bump the dataset version.

### August 31 complete fragment-sequence ingestion

- Added 32 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 9,071,159,472 bytes and 1,762.815248 seconds of encoded playback.
- Preserved four complete source-recording sequences as ordered `RecNN` sets
  containing 8, 6, 7, and 11 canonical fragments.
- Increased active membership to 475 Standard plus 128 Pre-Standard records,
  or 603 total, without changing the 29-field schema or
  `standard-2025-07-13` protocol ID.
- Added a separate 32-row, 15-field dated relationship sidecar containing only
  canonical fragments; no concatenated or transcoded derivative was added.
- Left `original_filename` blank because, at ingest-audit time, the source
  files bore canonical archive names and no pre-rename device-name mapping was
  independently retained.
- Verified 32/32 local SHA-256 values and complete packet-stream demuxes, plus
  96/96 decoded start/middle/end frame samples. The literal container tag
  `com.android.capture.fps=5.000000` is retained without inferring real drawing
  time.
- Bound the 32 media objects at immutable media-only PR revision
  `a05e2fe9d485435f8c3d0adbfe4aa80d289e9867`; the relationship sidecar pins
  metadata-bearing revision `480bc7e24261e6d3bbcacd261a00782b7e40211a`.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, backfill historical rows, create a v3 release, or otherwise
  bump the dataset version.

### August 29–30 complete fragment-sequence ingestion

- Added 39 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 17,470,306,160 bytes and 3,403.665326 seconds of encoded playback.
- Preserved five complete source-recording sequences as ordered `RecNN` sets
  containing 9, 5, 4, 15, and 6 canonical fragments.
- Increased active membership to 443 Standard plus 128 Pre-Standard records,
  or 571 total, without changing the 29-field schema or
  `standard-2025-07-13` protocol ID.
- Added a separate 39-row, 15-field dated relationship sidecar containing only
  canonical fragments; no concatenated or transcoded derivative was added.
- Left `original_filename` blank because, at ingest-audit time, the source
  files bore canonical archive names and no pre-rename device-name mapping was
  independently retained.
- Verified 39/39 local SHA-256 values and complete packet-stream demuxes, plus
  117/117 decoded start/middle/end frame samples. The literal container tag
  `com.android.capture.fps=5.000000` is retained without inferring real drawing
  time.
- Bound the 39 media objects at immutable media-only PR revision
  `b7ac091a06917eb712a4493dbb763e751c2bf459`; the relationship sidecar pins
  metadata-bearing revision `7293edccff883b4c604d710addbf26c85910cfcc`.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, backfill historical rows, create a v3 release, or otherwise
  bump the dataset version.

### Canonical tool-token and timing clarification

- Corrected five active Standard paths whose tool tokens contradicted their
  metadata: three `BallpoinPen` typos, one split `Ballpoint.Pen` token, and one
  split `Fountain.Pen` token.
- Retained every existing `record_id`, media payload, Xet identity, byte size,
  and technical metadata. This is a server-side path normalization, not a
  re-encoding or new recording.
- Added validation requiring each declared Standard tool to appear as an
  exact, case-sensitive filename token. Tool and medium lists remain
  independent; no positional pairing is inferred.
- Left revision-pinned historical relationship sidecars unchanged because
  their earlier paths remain correct evidence at their declared revisions.
- Clarified that 0.2 seconds is the Standard protocol's nominal capture
  setting, not a confirmed per-record measurement or calibrated real-time
  basis.

### Verification and documentation consolidation

- Clarified that each active metadata row represents one published video
  object, not necessarily one drawing, session, or complete process.
- Kept documented fragment-sequence and physical-reference relationships in
  separate sidecars without adding a global `work_id` or changing either
  29-field active video index.
- Replaced batch-by-batch README narration and stale Viewer migration counts
  with current, revision-bound summaries; added a provenance navigation index
  for the nine documented fragment sequences.
- Corrected nine physical-reference `hash_state` values that claimed paired
  hashes despite blank paired filename/hash fields. The correction reports
  ledger availability only and does not reinterpret any photograph or owner
  evidence.
- Added a dedicated physical-reference validator and regression tests; fragment
  validation now checks canonical byte sizes and states whether a pinned remote
  inventory was supplied.
- Removed the unsupported `video-classification` task facet while retaining
  `feature-extraction` and `annotations_creators: expert-generated`.
- This consolidation does not alter media, active video-index rows, record
  identities, or acquisition-protocol identifiers.

### August 7, 2025 date correction

- Corrected creator-confirmed record `tla-c043b4f55b583c4e` from August 7,
  2026 to August 7, 2025 in both its canonical path and metadata date.
- Retained the unchanged 86,415,894-byte media payload, stable `record_id`,
  Xet identity, technical metadata, collection membership, and 23:06 time.
- This is a descriptive date correction, not a new recording, re-encoding, or
  change to the `standard-2025-07-13` acquisition protocol boundary.

### August 28–29 complete fragment-sequence ingestion

- Added 19 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 10,661,404,849 bytes and 2,089.745536 seconds of encoded playback.
- Preserved four complete drawing sequences as ordered `RecNN` sets containing
  10, 4, 2, and 3 canonical fragments.
- Increased active membership to 404 Standard plus 128 Pre-Standard records,
  or 532 total, without changing the 29-field schema or
  `standard-2025-07-13` protocol ID.
- Added a separate 19-row, 15-field dated relationship sidecar containing only
  canonical fragments; no concatenated or transcoded derivative was added.
- Left `original_filename` blank because, at ingest-audit time, the source
  files bore canonical archive names and no pre-rename device-name mapping was
  independently retained.
- Verified 19/19 local SHA-256 values and complete packet-stream demuxes, plus
  57/57 decoded start/middle/end frame samples. The literal container tag
  `com.android.capture.fps=5.000000` is retained without inferring real drawing
  time.
- Bound the 19 media objects at immutable media-only PR revision
  `0c421b555a2558887b65b0b25380b35c642fa7e1`; the final relationship sidecar
  pins metadata-bearing revision `429541ae7f93c869056df956873f3441d580914c`.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, backfill historical rows, create a v3 release, or otherwise
  bump the dataset version.

### August 24–27 complete fragment-sequence ingestion

- Added 22 creator-confirmed, unchanged canonical Framelapse source fragments
  totaling 17,389,875,055 bytes and 3,391.699091 seconds of encoded playback.
- Preserved five complete drawing sequences as ordered `RecNN` sets containing
  2, 2, 6, 2, and 10 canonical fragments.
- Increased active membership to 385 Standard plus 128 Pre-Standard records,
  or 513 total, without changing the 29-field schema or
  `standard-2025-07-13` protocol ID.
- Added a separate 27-row, 15-field dated relationship sidecar covering the 22
  canonical fragments and five unchanged noncanonical InShot derivatives.
- Stored the five derivatives under the nested provenance `InShot/` directory;
  they remain outside both active metadata indexes, Viewer configurations, and
  active byte and duration totals.
- Retained media-object-level `record_id` identity. This update does not add a
  global `work_id`, backfill historical rows, create a v3 release, or otherwise
  bump the dataset version.
- Verified the 27 planned media additions, with no deletion or changed existing
  path, at immutable media-only PR revision
  `bb4160045cae21a71bf360278549398dc9d2a028`.
- Verified all 27 relationship paths, SHA-256 values, byte sizes, Xet
  identities, canonical metadata joins, and exact root metadata bytes against
  immutable metadata-bearing PR revision
  `8a21015210c19936d3b18175ae3f4061ae1e5d8d`. This validation does not assert
  Viewer settlement or merge status.

### June 2026 recording-sequence filename correction

- Corrected the canonical paths of 15 existing 30 × 40 in recordings dated
  June 18–30, 2026, to preserve the creator-confirmed continuous filename
  sequence `Rec01` through `Rec15`.
- Retained every media payload, stable `record_id`, Xet identity, byte size,
  technical field, and membership count; this is a filename correction, not a
  media addition or re-encoding.
- Clarified that documented `RecNN` order may continue across finish dates and
  does not reset merely because the date changes.
- The suffixes document recording order only; they do not by themselves assert
  separate drawings, sessions, or completion states.

### August 22–23 recording-sequence ingestion

- Added three creator-verified Standard recordings dated August 22–23, 2026,
  totaling 51,022,796,325 bytes and 3,895.390997 seconds of encoded playback.
- Increased active membership to 363 Standard plus 128 Pre-Standard records
  without changing the 29-field schema or `standard-2025-07-13` protocol ID.
- Retained literal `Rec01` through `Rec03` filename suffixes for the continuing
  14 × 17 in sequence; the suffixes do not independently claim an endpoint.
- Verified direct visual continuity and drawing progression across all three
  recordings; integrity validation covers every complete video and audio stream.
- Documented the creator-confirmed Rec03 ink change at approximately `00:04:59`:
  Pelikan black before the visible refill handling and unmarked, unknown-brand
  black ink afterward. No replacement brand is inferred.
- Rec03 produced one end-of-stream non-monotonic DTS warning from FFmpeg's null
  output during combined-stream validation. Source packet and decoded-frame
  timestamps at the tail remained strictly increasing, and both streams decoded.

### August 2026 Standard ingestion

- Added three creator-verified Standard recordings dated August 17–19, 2026,
  totaling 50,478,909,746 bytes and 3,856.391997 seconds of encoded playback.
- Increased active membership to 360 Standard plus 128 Pre-Standard records
  without changing the 29-field schema or `standard-2025-07-13` protocol ID.
- Fully decoded all 231,383 video frames and every audio stream; no source
  corruption, dropped frames, duplicated frames, or broken endpoints were
  found.
- Added the first 14 × 17 in Standard record and documented its Strathmore 500
  Series Premium Bristol plate surface from the creator-supplied packaging.
- Retained `Rec01` on the 14 × 17 in filename because `Rec02` is expected; the
  suffix distinguishes recording sequence only.
- Applied media integrity, identity, rights, and traceable-metadata criteria
  without filtering by perceived artistic quality.

### July 13 tier promotion

- Promoted `tla-3f49a8917fe22676` from Pre-Standard to Standard after the
  creator confirmed that clean media integrity is the controlling membership
  criterion.
- Verified all 1,205 video frames and the audio stream decode successfully.
  The shortened clip begins mid-process and reaches a completed, signed
  endpoint without corruption or a broken ending.
- Preserved the 141,221,810-byte media payload, Xet identity, stable record ID,
  and the 485-record active total while relocating its repository path.
- Moved the documented protocol boundary coherently to
  `standard-2025-07-13` across the canonical index.
- Updated active membership to 357 Standard plus 128 Pre-Standard records
  without changing the 29-field schema.

### Standard ingestion

#### Membership and evidence policy

- Added 17 creator-verified Standard records totaling 9,289,459,921 bytes and
  1,071.199 seconds of encoded playback.
- Increased active membership to 356 Standard plus 129 Pre-Standard records.
- Applied technical integrity, identity, rights, and traceable-metadata
  criteria without filtering records by perceived artistic quality or degree
  of completion.
- Preserved the existing 29-field schema and separate
  `canonical/archive` and `pre_standard/archive` configurations.

#### Qualified media conditions

- Documented two shortened derivatives as active Standard representatives
  without describing them as full-duration capture masters.
- Recorded pronounced lighting variation for the 2026-01-11 record.
- Retained one non-monotonic duplicate video-timestamp warning for each of the
  2026-01-11 and 2026-02-08 records; both files decode completely.
- Corrected the publication path `2025-09.27...` to canonical date syntax
  `2025-09-27...` without altering the local source file.

### March/April provenance correction

#### Record identity and physical metadata

- Promoted historical `2026.03.04(214.0).mp4` from the unresolved provenance
  subtree as the true `2026-03-04 14:21` BallpointPen / Ink / Paper / 9x12
  Standard record. Its 6,587,685,497-byte payload receives a new stable record
  ID based on its former archival path.
- Corrected the distinct 496,296,535-byte object formerly occupying that path
  to `2026-04-04 16:49` after curator verification against the physical work.
  Its existing stable record ID remains attached to the same media object.
- Increased active membership to 339 Standard plus 129 Pre-Standard records;
  no video bytes were added to repository storage.
- Preserved the immutable `v0.3.0` tag at its original 467-record commit.

#### Media payload

- Moved both existing Hub objects server-side without transcoding, replacing,
  downloading in full, or uploading video bytes.
- Removed the resolved `Unresolved_Series_9x12/2026.03.04(214.0).mp4` path only
  after preserving that same object at its corrected canonical path.
- No audio stream was modified.

## v0.3.0 — Release

### Metadata contract

- Corrected record `tla-a6bd9380e0256aff` from an unknown finish time to the
  curator-confirmed `2025-09-06 13:46` while retaining the confirmed 12x9
  physical dimensions.
- Linked historical `2025.11.15(116.1).mp4` to that record after curator
  confirmation that it depicts the same physical drawing and near-duplicate
  video content. The files have distinct byte sizes, SHA-256 values, and Xet
  identities, so the relationship is not described as blob identity.
- Added persistent `record_id` values to all 129 active Pre-Standard records.
- Added exact Hub Xet file IDs and byte sizes for every
  Pre-Standard file.
- Added playback duration, stored dimensions/orientation, reported frame rate,
  codec, pixel format, container, and audio-stream presence for every
  Pre-Standard file.
- Normalized Pre-Standard dimension casing and removed duplicate values from
  semicolon lists without inventing missing historical facts.
- Retained the 338 Standard / 129 Pre-Standard media membership unchanged.

### Viewer configuration

- Replaced the combined `default/train` surface with separate
  `canonical/archive` and `pre_standard/archive` configurations.
- Made `canonical` the default configuration.
- Declared the full feature contract inside each builder configuration so the
  generated Parquet schemas remain identical even when a source CSV column
  happens to contain only integer-looking values.
- Declared stored dimensions and byte sizes as integers and `has_audio` as a
  boolean; retained floating-point frame rate for historical encodings.
- Continued to exclude the nested provenance subtree through direct-file
  globs.

### Validation and documentation

- Extended validation across both active tiers, including real calendar-date
  parsing, positive numeric checks, hash format, boolean values, filename/date
  agreement for canonical files, cross-tier identity uniqueness, and complete
  technical metadata.
- Added direct comparison of all indexed content hashes and byte sizes against
  a pinned Hub API repository inventory.
- Corrected three recently added canonical rows whose `hub_xet_hash` values
  contained the LFS-compatible SHA-256 instead of the Xet file ID. Their local
  SHA-256 evidence remains documented in `notes`.
- Documented 50.06 total playback hours and full active-index technical
  coverage.
- Preserved unresolved semantic issues as explicit warnings: the canonical
  30×40 Paper/IllustrationBoard conflict, five unknown-date midnight values,
  and two incomplete Pre-Standard material descriptions.
- Added `tools/enrich_prestandard.py` so the technical enrichment can be
  repeated against a pinned Hub inventory and revision without intentionally
  transferring full video payloads.
- Added `tools/capture_hub_inventory.py` to capture the Hub Xet file IDs used
  by `hub_xet_hash`; these are distinct from the LFS-compatible SHA-256 values
  exposed by the ordinary repository inventory.

### Media payload

- Renamed the canonical object server-side to
  `2025-09-06.1346.BallpointPen.Ink.Paper.12x9.mp4` without changing its video
  bytes.
- Removed the now-resolved near-duplicate `2025.11.15(116.1).mp4` from the
  unresolved provenance payload; its path, relationship, differing object
  identities, and removal remain documented in metadata and repository
  history.
- No video was downloaded in full, transcoded, replaced, or newly uploaded.
- No audio stream was modified.

## v0.2.0 — Release candidate

Base repository revision:
`339e6149de130cbe2d001f7a0e5247872bc788ec`

### Metadata contract

- Added persistent `record_id` values for all 338 canonical records.
- Added `collection_tier`, `is_canonical`, and
  `acquisition_protocol_version`.
- Normalized canonical multi-value `tool` and `medium` fields from pipes to
  semicolons.
- Defined tool and medium fields as independent ordered unique lists rather
  than unsupported positional pairs.
- Preserved every canonical file path, content hash, technical property, and
  provenance value from the pinned source index.
- Removed one pre-standard metadata row whose corresponding media is not
  distributed because the required ownership and provenance threshold was not
  met. No identifying local path or content hash is published for the excluded
  holding.
- Added complete canonical rows for three previously unindexed Standard files.
  Their local inbox SHA-256 values exactly match the current Hub LFS identities;
  stream metadata was extracted from those matching bytes.

### Documentation

- Distinguished archive scope from currently published video coverage.
- Documented that the default Hub `train` split is not an official experiment
  split.
- Distinguished capture orientation from stored encoded orientation.
- Added intended-use, unsupported-use, bias, privacy, incidental-rights, audio,
  access, citation, and reproducibility guidance.
- Documented missing temporal and physical calibration required for rigorous
  motor-control measurement.

### Validation

- Added `tools/repair_metadata.py` for the reproducible v0.1-to-v0.2 transform.
- Added `tools/validate_metadata.py` for identity, schema, technical-field,
  orientation, duplicate, and Viewer-path checks.
- Retained the 465-row pinned Dataset Viewer snapshot as a historical base
  audit input. Final revised membership is validated against the PR repository
  tree because the Viewer has not yet rebuilt from the amended indexes.
- Reconciled the repository tree with both active indexes: 338 indexed
  canonical records and 129 published pre-standard records, both with
  one-to-one row/file coverage.
- Added `tools/metadata_additions_v0.2.csv` so the 338-row index regenerates
  deterministically from the pinned 335-row source plus 3 audited additions.

### Media payload

- No video was downloaded, moved, deleted, renamed, transcoded, or replaced.
- No audio stream was modified.
- No historical relationship was inferred or promoted.

### Deferred

- Formal Hub configurations separating `canonical` and `pre_standard` remain
  pending a Viewer-build test because canonical media and provenance holdings
  share a directory subtree.
- Technical ingestion of 129 pre-standard records remains incomplete.
- Public ingestion of the earlier 2012–2016 archive—primarily uploaded 1080p
  drawing videos, with some livestream-derived material—remains pending.
- No lightweight proxy-video release is included in this metadata-only change.
