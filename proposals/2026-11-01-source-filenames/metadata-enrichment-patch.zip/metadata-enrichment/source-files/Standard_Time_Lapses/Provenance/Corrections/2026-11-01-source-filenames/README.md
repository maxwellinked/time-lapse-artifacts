# Documented local-ingest source filenames

This metadata-only correction fills exactly 168 previously blank
`original_filename` cells in the Standard index from the literal
`source_filename` values already published in the frozen
[Timing v2 observations](../../Recording_Timing_v2/observations.json).
The [v2 schema](../../Recording_Timing_v2/SCHEMA.md) defines these values as
original local basenames retained in ingest audits. The private original audits
remain unavailable for public reproduction; their exported observations and
SHA-256/size receipts are public.

The basenames describe the retained local ingest inputs. Many already use the
canonical naming convention. Twelve preserve the earlier September 1 `0213`
names whose current paths have the documented `1413` correction. These values do
not establish device-original names, camera-original status, recording starts,
recording stops or clock accuracy.

The source index is pinned at
[`fcbe6277ca34c6a5dd4a15d82e4f0654b46ffbee`](https://huggingface.co/datasets/maxwellinked/time-lapse-artifacts/commit/fcbe6277ca34c6a5dd4a15d82e4f0654b46ffbee).
The observation packet retains its own source revision
`521f4ee62ee3843cf36394499c10bf33f07dcaae`.
The [exact correction receipt](source_filename_backfill.json) binds:

- source and resulting metadata byte lengths and SHA-256 values;
- unchanged observation and packet-manifest bytes;
- all 168 permanent record IDs, active paths, ordinary media SHA-256 values,
  Xet identities and byte sizes;
- blank old values, exact literal new basenames and retained audit identities.

Every other metadata cell, row position and field is preserved. Required
technical fields were already complete. Unknown finish times, recording starts,
work identities and unrelated optional provenance fields retain their existing
values and evidence scope. Native access tables are derived from the updated
source index; this correction does not change recording content or identities.

The timing-v1 validator pins the correction receipt SHA-256, validates its exact
source/media joins for all 168 records, and reverses only these named cells in
memory before checking the unchanged original 549-row metadata receipt. Four of
the 168 records fall outside that historical snapshot and receive the same
source/media identity checks. Frozen timing packets are not rewritten.

Run `python tools/validate_recording_timing.py --root .` and
`python -m unittest discover -s tools -p 'test_recording_timing*.py'`.
Regression tests reject wrong or removed basenames, an unrelated changed cell,
current identity/fixity drift, altered correction bytes and altered observations.
