#!/usr/bin/env python3
"""Validate the exploratory recording-timing sidecar and its source joins."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from zoneinfo import ZoneInfo


TIMING_FIELDS = [
    "record_id",
    "file_path",
    "sha256",
    "hub_xet_hash",
    "fragment_set_label",
    "sequence_position",
    "sequence_count",
    "source_hub_revision",
    "source_audit_id",
    "source_filename",
    "format_creation_time_utc",
    "video_creation_time_utc",
    "capture_fps_tag_literal",
    "video_frame_count",
    "local_time_zone",
    "device_filename_start_local",
    "format_creation_time_local",
    "capture_start_time_utc",
    "capture_start_time_local",
    "timing_basis",
    "recording_elapsed_seconds",
    "start_uncertainty_seconds",
    "timing_model_id",
    "calibration_profile_status",
    "previous_record_id",
    "inter_fragment_gap_seconds",
    "gap_uncertainty_seconds",
    "gap_status",
    "documented_group_finish_date",
    "documented_group_finish_time",
    "group_finish_delta_seconds",
    "group_finish_crosscheck_status",
    "timing_evidence_state",
    "notes",
]

CALIBRATION_FIELDS = [
    "record_id",
    "file_path",
    "source_filename",
    "direct_start_local",
    "direct_start_utc",
    "creation_boundary_local",
    "creation_boundary_utc",
    "video_frame_count",
    "observed_elapsed_seconds",
    "nominal_five_fps_elapsed_seconds",
    "nominal_five_fps_error_seconds",
    "model_elapsed_seconds",
    "model_residual_seconds",
    "video_frames_per_observed_wall_second",
]

GROUP_FIELDS = [
    "fragment_set_label",
    "fragment_count",
    "direct_start_count",
    "calibrated_start_count",
    "first_capture_start_utc",
    "last_creation_boundary_utc",
    "recording_elapsed_seconds_sum",
    "group_wall_span_seconds",
    "within_group_gap_seconds_sum",
    "within_uncertainty_gap_count",
    "documented_group_finish_date",
    "documented_group_finish_time",
    "group_finish_delta_seconds",
    "group_finish_crosscheck_status",
    "source_hub_revision",
    "notes",
]

CORRECTION_FIELDS = [
    "record_id",
    "sequence_position",
    "old_file_path",
    "new_file_path",
    "old_finish_date",
    "old_finish_time",
    "new_finish_date",
    "new_finish_time",
    "sha256",
    "hub_xet_hash",
    "size_bytes",
    "acquisition_protocol_version",
]

MODEL_ID = "tla-framelapse-android14-tag5-empirical-v1"
MODEL_INTERCEPT = Decimal("0.8")
MODEL_FRAME_NUMERATOR = Decimal(7)
MODEL_FRAME_DENOMINATOR = Decimal(30)
LOCAL_ZONE_NAME = "America/New_York"
LOCAL_ZONE = ZoneInfo(LOCAL_ZONE_NAME)
EXPECTED_ROWS = 186
EXPECTED_GROUPS = 25
EXPECTED_DIRECT = 22
EXPECTED_CALIBRATED = 164
EXPECTED_TRANSITIONS = 161
EXPECTED_SOURCE_REVISION = "b4b58f0ce0effb31ebf7671fbb0bd9c11765db4e"
EXPECTED_CANONICAL_METADATA_RECEIPT = {
    "file_path": "metadata.csv",
    "size_bytes": 370833,
    "sha256": "d516da7a4341dddf0b2b5ad50f6200f283ea0cdefc6de465882fbc021abfba8a",
    "field_count": 29,
    "row_count": 549,
}
EXPECTED_SOURCE_SCHEMA_SHA256 = "3624d5858bd4c0df796775ee6400106eb146101acbf112a515ad4a49c3262082"
EXPECTED_SOURCE_SCHEMA_SIZE = 19411
EXPECTED_CONFLICT_GROUP = "2026-09-01.0213.BallpointPen.Ink.Paper.9x12"
EXPECTED_CONFLICT_DELTA = Decimal(43221)
EXPECTED_CORRECTED_GROUP = "2026-09-01.1413.BallpointPen.Ink.Paper.9x12"
EXPECTED_CORRECTED_DELTA = Decimal(21)
EXPECTED_CORRECTION_ROWS = 12
CORRECTION_RELATIVE_PATH = Path(
    "Standard_Time_Lapses/Provenance/Corrections/"
    "2026-09-01.1413-finish-time/finish_time_correction.csv"
)

# The pinned timing packet predates the metadata-only provenance backfill merged
# through discussion #67.  These exact records were blank in the pinned
# b4b58f0... snapshot and were later classified from repository commit history.
# Reconstruction must verify the active values before reversing them; otherwise
# an arbitrary metadata change could be hidden behind the historical receipt.
EXPECTED_POST_SNAPSHOT_PROVENANCE_BACKFILL_IDS = frozenset(
    {
        "tla-0107ee972bd69249",
        "tla-11133b0b1b853e6c",
        "tla-1a660f24ff2b9c29",
        "tla-1a9f4f9fd2bc201b",
        "tla-218a8b5ec3c7bfaf",
        "tla-3017b3e41ca4fde9",
        "tla-306b28137c489dcd",
        "tla-99a5dc21515237f6",
        "tla-b82dcb656ccbe84a",
        "tla-d7854942f5a02ddb",
        "tla-e4b72a42f403a134",
        "tla-f57ebbd6fbc4d2a5",
    }
)
EXPECTED_POST_SNAPSHOT_PROVENANCE_BACKFILL_VALUES = {
    "provenance_status": "direct_root_upload",
    "evidence_method": "commit_history",
    "notes": (
        "Added directly to Standard_Time_Lapses in Hub commit "
        "d56edd18253806582d691fb075df5538202d20c3 (2026-08-10); current Hub "
        "LFS SHA-256 and byte size match that upload. Classification records "
        "repository ingest history only."
    ),
}
# Only this exact, SHA-bound receipt authorizes the 168 literal local-ingest
# basenames exported by frozen Timing v2. No other metadata cell is inverted.
SOURCE_FILENAME_BACKFILL_PATH = Path(
    "Standard_Time_Lapses/Provenance/Corrections/"
    "2026-11-01-source-filenames/source_filename_backfill.json"
)
EXPECTED_SOURCE_FILENAME_BACKFILL_SHA256 = "a3e73cc220f99e049559ead64ca8559d27751eb35b859c0bc13f933ae03116e9"
EXPECTED_SOURCE_FILENAME_BACKFILL_ROWS = 168
# PR #70 ingests this historical recording after the pinned timing snapshot.
# Its filename sorts inside that snapshot; exclude only this verified identity
# when reconstructing the original 549 rows. Historical receipts stay unchanged.
EXPECTED_POST_SNAPSHOT_MEDIA_BACKFILLS = {
    "tla-85cdf161df0b807e": {
        "file_name": (
            "Standard_Time_Lapses/2026-08-20.1434.Pencil.Graphite."
            "FountainPen.Ink.Paper.14x17.Rec02.mp4"
        ),
        "hub_xet_hash": "752f5f26945ceae6ebfd44fc702af3a65860b7c9d50d2ec7b74c3a153c40b16a",
        "size_bytes": "28666390097",
        "acquisition_protocol_version": "standard-2025-07-13",
        "sha256": "a9b9c6bb11c4da7d3a7e99ca72f86702999192b06009bccb447757a25ebbb074",
    },
}
EXPECTED_RELATIONSHIP_PATHS = {
    f"Standard_Time_Lapses/Provenance/{date}/fragment_sequence_relationships.csv"
    for date in (
        "2026-08-27",
        "2026-08-29",
        "2026-08-30",
        "2026-08-31",
        "2026-09-01",
        "2026-09-02",
    )
}

RECORD_RE = re.compile(r"^tla-[0-9a-f]{16}$")
HASH_RE = re.compile(r"^[0-9a-f]{64}$")
REVISION_RE = re.compile(r"^[0-9a-f]{40}$")
DEVICE_FILENAME_RE = re.compile(
    r"^VID_(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})\.mp4$"
)


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError(f"missing CSV header: {path}")
        return list(reader.fieldnames), list(reader)


def read_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def serialize_csv_bytes(
    fieldnames: list[str], rows: list[dict[str, str]]
) -> bytes:
    output = io.StringIO(newline="")
    writer = csv.DictWriter(
        output, fieldnames=fieldnames, lineterminator="\n"
    )
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue().encode("utf-8")


def read_sha256_manifest(path: Path, errors: list[str]) -> dict[str, str]:
    entries: dict[str, str] = {}
    if not path.is_file():
        errors.append("root SHA256SUMS is missing")
        return entries
    for line_number, line in enumerate(
        path.read_text(encoding="utf-8").splitlines(), start=1
    ):
        match = re.fullmatch(r"([0-9a-f]{64})  (\S.*)", line)
        if not match:
            errors.append(f"SHA256SUMS line {line_number}: malformed entry")
            continue
        digest, file_path = match.groups()
        if file_path in entries:
            errors.append(f"SHA256SUMS: duplicate path {file_path}")
            continue
        entries[file_path] = digest
    return entries


def parse_decimal(text: str, label: str, errors: list[str]) -> Decimal | None:
    try:
        value = Decimal(text)
    except (InvalidOperation, ValueError):
        errors.append(f"{label}: invalid decimal {text!r}")
        return None
    if not value.is_finite():
        errors.append(f"{label}: decimal is not finite")
        return None
    return value


def parse_int(text: str, label: str, errors: list[str]) -> int | None:
    try:
        value = int(text)
    except ValueError:
        errors.append(f"{label}: invalid integer {text!r}")
        return None
    return value


def parse_timestamp(text: str, label: str, errors: list[str]) -> datetime | None:
    try:
        value = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        errors.append(f"{label}: invalid ISO-8601 timestamp {text!r}")
        return None
    if value.tzinfo is None:
        errors.append(f"{label}: timestamp has no UTC offset")
        return None
    return value


def device_filename_timestamp(
    source_filename: str, label: str, errors: list[str]
) -> datetime | None:
    match = DEVICE_FILENAME_RE.fullmatch(source_filename)
    if not match:
        errors.append(f"{label}: invalid retained device filename")
        return None
    year, month, day, hour, minute, second = map(int, match.groups())
    try:
        return datetime(year, month, day, hour, minute, second, tzinfo=LOCAL_ZONE)
    except ValueError:
        errors.append(f"{label}: invalid date/time in retained device filename")
        return None


def close_decimal(
    actual: Decimal | None,
    expected: Decimal,
    tolerance: Decimal,
    label: str,
    errors: list[str],
) -> None:
    if actual is not None and abs(actual - expected) > tolerance:
        errors.append(f"{label}: expected {expected}, found {actual}")


def close_timestamp(
    actual: datetime | None,
    expected: datetime,
    tolerance_seconds: float,
    label: str,
    errors: list[str],
) -> None:
    if actual is None:
        return
    difference = abs((actual.astimezone(timezone.utc) - expected.astimezone(timezone.utc)).total_seconds())
    if difference > tolerance_seconds:
        errors.append(f"{label}: timestamp differs by {difference:.6f} seconds")


def decimal_mean(values: list[Decimal]) -> Decimal:
    return sum(values, Decimal(0)) / Decimal(len(values))


def decimal_population_standard_deviation(values: list[Decimal]) -> Decimal:
    mean = decimal_mean(values)
    variance = sum((value - mean) ** 2 for value in values) / Decimal(len(values))
    return variance.sqrt()


def decimal_root_mean_square(values: list[Decimal]) -> Decimal:
    mean_square = sum(value**2 for value in values) / Decimal(len(values))
    return mean_square.sqrt()


def validate_metric_block(
    block: object,
    expected: dict[str, Decimal],
    tolerance: Decimal,
    label: str,
    errors: list[str],
) -> None:
    if not isinstance(block, dict):
        errors.append(f"{label} is missing")
        return
    if set(block) != set(expected):
        errors.append(
            f"{label} fields differ: expected {sorted(expected)}, found {sorted(block)}"
        )
    for name, expected_value in expected.items():
        close_decimal(
            parse_decimal(str(block.get(name, "")), f"{label} {name}", errors),
            expected_value,
            tolerance,
            f"{label} {name}",
            errors,
        )


def validate_bundle(timing_dir: Path, errors: list[str]) -> None:
    bundle_path = timing_dir / "bundle.sha256"
    if not bundle_path.is_file():
        errors.append("bundle.sha256 is missing")
        return
    expected_files = {
        path.name for path in timing_dir.iterdir() if path.is_file() and path.name != "bundle.sha256"
    }
    listed_files: set[str] = set()
    for line_number, line in enumerate(
        bundle_path.read_text(encoding="utf-8").splitlines(), start=1
    ):
        match = re.fullmatch(r"([0-9a-f]{64})  ([^/\\]+)", line)
        if not match:
            errors.append(f"bundle.sha256 line {line_number}: malformed entry")
            continue
        expected_hash, name = match.groups()
        if name in listed_files:
            errors.append(f"bundle.sha256: duplicate entry {name}")
            continue
        listed_files.add(name)
        target = timing_dir / name
        if not target.is_file():
            errors.append(f"bundle.sha256: missing listed file {name}")
        elif sha256_file(target) != expected_hash:
            errors.append(f"bundle.sha256: SHA-256 mismatch for {name}")
    if listed_files != expected_files:
        errors.append(
            "bundle.sha256 inventory differs from directory files: "
            f"listed={sorted(listed_files)} actual={sorted(expected_files)}"
        )


def validate_source_receipts(
    root: Path,
    manifest: dict[str, object],
    errors: list[str],
) -> list[dict[str, str]]:
    if manifest.get("packet_status") != "exploratory_public_derived_sidecar_v1":
        errors.append("source_manifest packet_status is unexpected")
    if manifest.get("dataset") != "maxwellinked/time-lapse-artifacts":
        errors.append("source_manifest dataset is unexpected")
    if manifest.get("pinned_dataset_revision") != EXPECTED_SOURCE_REVISION:
        errors.append("source_manifest pinned_dataset_revision is unexpected")

    canonical_metadata = manifest.get("canonical_metadata")
    if not isinstance(canonical_metadata, dict):
        errors.append("source_manifest canonical_metadata is missing")
        return []
    if canonical_metadata != EXPECTED_CANONICAL_METADATA_RECEIPT:
        errors.append("source_manifest canonical metadata receipt differs")

    source_snapshot_schema = manifest.get("source_snapshot_schema")
    if not isinstance(source_snapshot_schema, dict):
        errors.append("source_manifest source_snapshot_schema is missing")
    else:
        if source_snapshot_schema.get("file_path") != "SCHEMA.md":
            errors.append("source snapshot schema path is unexpected")
        if source_snapshot_schema.get("sha256") != EXPECTED_SOURCE_SCHEMA_SHA256:
            errors.append("source snapshot schema SHA-256 receipt is unexpected")
        if source_snapshot_schema.get("size_bytes") != EXPECTED_SOURCE_SCHEMA_SIZE:
            errors.append("source snapshot schema byte-size receipt is unexpected")

    relationship_rows: list[dict[str, str]] = []
    relationship_sidecars = manifest.get("relationship_sidecars")
    if not isinstance(relationship_sidecars, list) or len(relationship_sidecars) != 6:
        errors.append("source_manifest must list six relationship sidecars")
        return relationship_rows
    listed_paths = {
        str(receipt.get("file_path", ""))
        for receipt in relationship_sidecars
        if isinstance(receipt, dict)
    }
    if listed_paths != EXPECTED_RELATIONSHIP_PATHS:
        errors.append("source_manifest relationship path set is unexpected")
    for receipt in relationship_sidecars:
        if not isinstance(receipt, dict):
            errors.append("source_manifest relationship receipt is not an object")
            continue
        relative_path = str(receipt.get("file_path", ""))
        sidecar_path = root / relative_path
        if not sidecar_path.is_file():
            errors.append(f"relationship sidecar is missing: {relative_path}")
            continue
        _, rows = read_csv(sidecar_path)
        relationship_rows.extend(rows)
        if sha256_file(sidecar_path) != receipt.get("sha256"):
            errors.append(f"relationship sidecar SHA-256 mismatch: {relative_path}")
        if sidecar_path.stat().st_size != receipt.get("size_bytes"):
            errors.append(f"relationship sidecar byte-size mismatch: {relative_path}")
        if len(rows) != receipt.get("row_count"):
            errors.append(f"relationship sidecar row-count mismatch: {relative_path}")
        role_counts = dict(Counter(row.get("object_role", "") for row in rows))
        if role_counts != receipt.get("object_role_counts"):
            errors.append(f"relationship sidecar role counts mismatch: {relative_path}")
        revisions = {row.get("source_hub_revision", "") for row in rows}
        if revisions != {receipt.get("source_hub_revision")}:
            errors.append(f"relationship sidecar source revision mismatch: {relative_path}")
    return relationship_rows


def validate_source_filename_backfill(
    root: Path,
    current_by_id: dict[str, dict[str, str]],
    sha256_entries: dict[str, str],
    errors: list[str],
) -> dict[str, dict[str, str]]:
    """Bind the exact named cells to immutable observations and current media."""
    receipt_path = root / SOURCE_FILENAME_BACKFILL_PATH
    if not receipt_path.is_file():
        errors.append("source-filename backfill receipt is missing")
        return {}
    if sha256_file(receipt_path) != EXPECTED_SOURCE_FILENAME_BACKFILL_SHA256:
        errors.append("source-filename backfill receipt SHA-256 differs")
        return {}
    receipt = read_json(receipt_path)
    if (receipt.get("schema") != "recording-source-filename-backfill/v1"
            or receipt.get("field") != "original_filename"
            or receipt.get("row_count") != EXPECTED_SOURCE_FILENAME_BACKFILL_ROWS):
        errors.append("source-filename backfill field contract differs")
        return {}
    for key, label in (("source_observations", "observation"),
                       ("source_packet_manifest", "packet manifest")):
        expected = receipt[key]
        path = root / expected["file_path"]
        if (not path.is_file() or path.stat().st_size != expected["size_bytes"]
                or sha256_file(path) != expected["sha256"]):
            errors.append(f"source-filename backfill {label} receipt differs")
            return {}
    observations = read_json(root / receipt["source_observations"]["file_path"])["observations"]
    observations_by_id = {row["record_id"]: row for row in observations}
    manifest = read_json(root / receipt["source_packet_manifest"]["file_path"])
    if (len(observations_by_id) != len(observations)
            or manifest["source_hub_revision"] != receipt["observation_source_hub_revision"]):
        errors.append("source-filename backfill observation identity contract differs")
        return {}
    changes = receipt["changes"]
    by_id = {change["record_id"]: change for change in changes}
    if len(changes) != EXPECTED_SOURCE_FILENAME_BACKFILL_ROWS or len(by_id) != len(changes):
        errors.append("source-filename backfill must name exactly 168 unique cells")
        return {}
    for record_id, change in by_id.items():
        label = f"source-filename backfill {record_id}"
        current = current_by_id.get(record_id)
        observation = observations_by_id.get(record_id)
        if current is None or observation is None:
            errors.append(f"{label}: record_id is absent from metadata or observations")
            continue
        if change["old_value"] != "" or not change["new_value"]:
            errors.append(f"{label}: only a blank-to-literal-name change is authorized")
        if (change["new_value"] != observation["source_filename"]
                or change["source_audit_id"] != observation["source_audit_id"]
                or change["sha256"] != observation["source_sha256"]
                or int(change["size_bytes"]) != observation["source_size_bytes"]):
            errors.append(f"{label}: source observation identity differs")
        for field in ("file_name", "hub_xet_hash", "size_bytes"):
            if current.get(field) != change[field]:
                errors.append(f"{label}: current metadata {field} differs")
        if current.get("original_filename") != change["new_value"]:
            errors.append(f"{label}: current metadata original_filename differs")
        if sha256_entries.get(change["file_name"]) != change["sha256"]:
            errors.append(f"{label}: active SHA256SUMS path/hash differs")
    return by_id


def validate_correction_bridge(
    root: Path,
    metadata_fields: list[str],
    metadata_rows: list[dict[str, str]],
    timing_rows: list[dict[str, str]],
    errors: list[str],
) -> dict[str, dict[str, str]]:
    correction_path = root / CORRECTION_RELATIVE_PATH
    if not correction_path.is_file():
        errors.append(f"documented correction is missing: {CORRECTION_RELATIVE_PATH.as_posix()}")
        return {}
    correction_fields, correction_rows = read_csv(correction_path)
    if correction_fields != CORRECTION_FIELDS:
        errors.append(
            f"finish_time_correction.csv field contract differs: {correction_fields}"
        )
    if len(correction_rows) != EXPECTED_CORRECTION_ROWS:
        errors.append(
            f"expected {EXPECTED_CORRECTION_ROWS} correction rows, "
            f"found {len(correction_rows)}"
        )

    correction_by_id: dict[str, dict[str, str]] = {}
    correction_by_position: dict[int, dict[str, str]] = {}
    correction_positions: list[int] = []
    old_paths: list[str] = []
    new_paths: list[str] = []
    for row_number, correction in enumerate(correction_rows, start=2):
        label = f"finish_time_correction.csv row {row_number}"
        record_id = correction.get("record_id", "")
        if not RECORD_RE.fullmatch(record_id):
            errors.append(f"{label}: invalid record_id")
        if record_id in correction_by_id:
            errors.append(f"{label}: duplicate record_id {record_id}")
        correction_by_id[record_id] = correction
        position = parse_int(
            correction.get("sequence_position", ""),
            f"{label} sequence_position",
            errors,
        )
        if position is not None:
            correction_positions.append(position)
            if position in correction_by_position:
                errors.append(f"{label}: duplicate sequence_position {position}")
            correction_by_position[position] = correction
        old_paths.append(correction.get("old_file_path", ""))
        new_paths.append(correction.get("new_file_path", ""))
        if not HASH_RE.fullmatch(correction.get("sha256", "")):
            errors.append(f"{label}: invalid ordinary SHA-256")
        if not HASH_RE.fullmatch(correction.get("hub_xet_hash", "")):
            errors.append(f"{label}: invalid Xet identity")
        size = parse_int(correction.get("size_bytes", ""), f"{label} size_bytes", errors)
        if size is not None and size <= 0:
            errors.append(f"{label}: size_bytes must be positive")
    if len(old_paths) != len(set(old_paths)) or not all(old_paths):
        errors.append("finish_time_correction.csv old paths must be nonblank and unique")
    if len(new_paths) != len(set(new_paths)) or not all(new_paths):
        errors.append("finish_time_correction.csv new paths must be nonblank and unique")
    if set(correction_by_position) != set(range(1, EXPECTED_CORRECTION_ROWS + 1)):
        errors.append("finish_time_correction.csv sequence positions must be exactly 1 through 12")
    if correction_positions != list(range(1, EXPECTED_CORRECTION_ROWS + 1)):
        errors.append("finish_time_correction.csv rows must be in sequence order")

    sep02_path = (
        root
        / "Standard_Time_Lapses"
        / "Provenance"
        / "2026-09-02"
        / "fragment_sequence_relationships.csv"
    )
    _, sep02_rows = read_csv(sep02_path)
    historical_relationship_rows = [
        row
        for row in sep02_rows
        if row.get("object_role") == "canonical_fragment"
        and row.get("fragment_set_label") == EXPECTED_CONFLICT_GROUP
    ]
    historical_timing_rows = [
        row
        for row in timing_rows
        if row.get("fragment_set_label") == EXPECTED_CONFLICT_GROUP
    ]
    if len(historical_relationship_rows) != EXPECTED_CORRECTION_ROWS:
        errors.append(
            "Sep-02 historical relationship packet does not contain exactly "
            "12 affected canonical rows"
        )
    if len(historical_timing_rows) != EXPECTED_CORRECTION_ROWS:
        errors.append(
            "historical recording_timing.csv does not contain exactly "
            "12 affected rows"
        )
    relationship_by_position = {
        int(row["sequence_position"]): row
        for row in historical_relationship_rows
        if row.get("sequence_position", "").isdigit()
    }
    timing_by_position = {
        int(row["sequence_position"]): row
        for row in historical_timing_rows
        if row.get("sequence_position", "").isdigit()
    }

    metadata_path = root / EXPECTED_CANONICAL_METADATA_RECEIPT["file_path"]
    metadata_bytes = metadata_path.read_bytes()
    malformed_metadata = False
    for row_number, row in enumerate(metadata_rows, start=2):
        if None in row or any(value is None for value in row.values()):
            errors.append(f"metadata.csv row {row_number} has malformed field width")
            malformed_metadata = True
    if not malformed_metadata:
        deterministic_bytes = serialize_csv_bytes(metadata_fields, metadata_rows)
        if metadata_bytes != deterministic_bytes:
            errors.append(
                "metadata.csv is not deterministic UTF-8 CSV with LF line endings"
            )
    if [row.get("file_name", "") for row in metadata_rows] != sorted(
        row.get("file_name", "") for row in metadata_rows
    ):
        # An explicitly registered insertion may append new rows to preserve
        # the prior index bytes. Exempt only validated addition IDs, never the
        # older sequence members or arbitrary later records. The frozen timing
        # snapshot reconstruction below still requires its exact original hash.
        from sequence_insertions import validate_insertions
        insertion = validate_insertions(root, metadata_path, bind_inventory=False)
        additions = {
            record_id for sequence in insertion["sequences"]
            for record_id in sequence["additions"]
        }
        ordinary_paths = [
            row.get("file_name", "") for row in metadata_rows
            if row.get("record_id") not in additions
        ]
        if insertion["errors"] or not additions or ordinary_paths != sorted(ordinary_paths):
            errors.append("metadata.csv rows are not sorted by file_name outside validated registered additions")
            errors.extend(f"metadata order insertion validation: {error}" for error in insertion["errors"])
    # The historical receipt binds the original columns, not later declared
    # fields. Only the named timing/work projections and the independently
    # checked recording_mode source enrichment may be excluded. Reconstructed
    # original bytes must still match the exact size and SHA-256.
    display_fields = {
        "recording_start_local", "recording_start_basis",
        "documented_finish_date", "documented_finish_time", "finish_label_scope",
    }
    present_display_fields = display_fields.intersection(metadata_fields)
    if present_display_fields and present_display_fields != display_fields:
        errors.append("metadata.csv has an incomplete timing display extension")
    # Historical inputs may predate this source field. When present, validate
    # every current row before omitting it from the older 29-field receipt.
    if "recording_mode" in metadata_fields:
        if metadata_fields.count("recording_mode") != 1:
            errors.append("metadata.csv recording_mode column must occur once")
        for row_number, row in enumerate(metadata_rows, start=2):
            if row.get("recording_mode") != "time_lapse":
                errors.append(f"metadata.csv row {row_number}: recording_mode must be time_lapse")
    # work_id is validated independently against Work_Identity by project_work_ids.py.
    pinned_metadata_fields = [
        f for f in metadata_fields
        if f not in display_fields | {"work_id", "recording_mode"}
    ]
    if len(pinned_metadata_fields) != EXPECTED_CANONICAL_METADATA_RECEIPT["field_count"]:
        errors.append("metadata.csv original field count differs from the pinned snapshot")
    if len(metadata_rows) < EXPECTED_CANONICAL_METADATA_RECEIPT["row_count"]:
        errors.append("metadata.csv current row count is below the pinned source snapshot")

    current_by_id = {row.get("record_id", ""): row for row in metadata_rows}
    sha256_entries = read_sha256_manifest(root / "SHA256SUMS", errors)
    source_filename_changes = validate_source_filename_backfill(
        root, current_by_id, sha256_entries, errors
    )
    for record_id, expected in EXPECTED_POST_SNAPSHOT_MEDIA_BACKFILLS.items():
        current = current_by_id.get(record_id)
        if current is None:
            continue
        label = f"post-snapshot media backfill {record_id}"
        for field, value in expected.items():
            if field == "sha256":
                if sha256_entries.get(expected["file_name"]) != value:
                    errors.append(f"{label}: active SHA256SUMS path/hash differs")
            elif current.get(field) != value:
                errors.append(f"{label}: current metadata {field} differs")
    inverse_rows = [
        dict(row) for row in metadata_rows
        if row.get("record_id") not in EXPECTED_POST_SNAPSHOT_MEDIA_BACKFILLS
    ]
    inverse_by_id = {row.get("record_id", ""): row for row in inverse_rows}
    for record_id, correction in correction_by_id.items():
        inverse = inverse_by_id.get(record_id)
        if inverse is not None:
            inverse["file_name"] = correction.get("old_file_path", "")
            inverse["date"] = correction.get("old_finish_date", "")
            inverse["time"] = correction.get("old_finish_time", "")
    for record_id in sorted(EXPECTED_POST_SNAPSHOT_PROVENANCE_BACKFILL_IDS):
        current = current_by_id.get(record_id)
        inverse = inverse_by_id.get(record_id)
        label = f"post-snapshot provenance backfill {record_id}"
        if current is None or inverse is None:
            errors.append(f"{label}: record_id is absent from current metadata.csv")
            continue
        for field, expected in EXPECTED_POST_SNAPSHOT_PROVENANCE_BACKFILL_VALUES.items():
            if current.get(field) != expected:
                errors.append(f"{label}: current metadata {field} differs")
            inverse[field] = ""
    for record_id, change in source_filename_changes.items():
        inverse = inverse_by_id.get(record_id)
        if inverse is not None:
            inverse["original_filename"] = change["old_value"]
    inverse_rows.sort(key=lambda row: row.get("file_name", ""))
    pinned_row_count = int(EXPECTED_CANONICAL_METADATA_RECEIPT["row_count"])
    reconstructed_rows = inverse_rows[:pinned_row_count]
    reconstructed_bytes = (
        serialize_csv_bytes(pinned_metadata_fields, [
            {field: row[field] for field in pinned_metadata_fields}
            for row in reconstructed_rows
        ])
        if not malformed_metadata
        else b""
    )
    if len(reconstructed_bytes) != EXPECTED_CANONICAL_METADATA_RECEIPT["size_bytes"]:
        errors.append(
            "reconstructed pinned metadata snapshot byte size differs from the "
            "source_manifest receipt"
        )
    if (
        hashlib.sha256(reconstructed_bytes).hexdigest()
        != EXPECTED_CANONICAL_METADATA_RECEIPT["sha256"]
    ):
        errors.append(
            "reconstructed pinned metadata snapshot differs from the "
            "source_manifest receipt"
        )
    reconstructed_by_id = {
        row.get("record_id", ""): row for row in reconstructed_rows
    }

    for position in range(1, EXPECTED_CORRECTION_ROWS + 1):
        correction = correction_by_position.get(position)
        relationship = relationship_by_position.get(position)
        timing = timing_by_position.get(position)
        if correction is None or relationship is None or timing is None:
            continue
        label = f"documented correction position {position}"
        old_path = (
            f"Standard_Time_Lapses/{EXPECTED_CONFLICT_GROUP}.Rec{position:02d}.mp4"
        )
        new_path = (
            f"Standard_Time_Lapses/{EXPECTED_CORRECTED_GROUP}.Rec{position:02d}.mp4"
        )
        expected_literals = {
            "old_file_path": old_path,
            "new_file_path": new_path,
            "old_finish_date": "2026-09-01",
            "old_finish_time": "02:13",
            "new_finish_date": "2026-09-01",
            "new_finish_time": "14:13",
        }
        for field, expected in expected_literals.items():
            if correction.get(field) != expected:
                errors.append(f"{label}: {field} differs from {expected!r}")
        if relationship.get("sequence_count") != str(EXPECTED_CORRECTION_ROWS):
            errors.append(f"{label}: relationship sequence_count differs")
        if timing.get("sequence_count") != str(EXPECTED_CORRECTION_ROWS):
            errors.append(f"{label}: timing sequence_count differs")
        for field in ("record_id", "sha256", "hub_xet_hash", "size_bytes"):
            relationship_value = relationship.get(field, "")
            if correction.get(field) != relationship_value:
                errors.append(f"{label}: {field} differs from Sep-02 relationship")
        for field in ("record_id", "sha256", "hub_xet_hash"):
            if correction.get(field) != timing.get(field):
                errors.append(f"{label}: {field} differs from historical timing row")
        if timing.get("file_path") != old_path:
            errors.append(f"{label}: historical timing path differs")
        if timing.get("documented_group_finish_date") != "2026-09-01":
            errors.append(f"{label}: historical timing finish date differs")
        if timing.get("documented_group_finish_time") != "02:13":
            errors.append(f"{label}: historical timing finish time differs")

        record_id = correction.get("record_id", "")
        current = current_by_id.get(record_id)
        if current is None:
            errors.append(f"{label}: record_id is absent from current metadata.csv")
        else:
            current_expectations = {
                "file_name": new_path,
                "date": correction.get("new_finish_date", ""),
                "time": correction.get("new_finish_time", ""),
                "hub_xet_hash": correction.get("hub_xet_hash", ""),
                "size_bytes": correction.get("size_bytes", ""),
                "acquisition_protocol_version": correction.get(
                    "acquisition_protocol_version", ""
                ),
            }
            for field, expected in current_expectations.items():
                if current.get(field) != expected:
                    errors.append(f"{label}: current metadata {field} differs")
        reconstructed = reconstructed_by_id.get(record_id)
        if reconstructed is None:
            errors.append(f"{label}: record_id is absent from reconstructed snapshot")
        else:
            reconstructed_expectations = {
                "file_name": old_path,
                "date": correction.get("old_finish_date", ""),
                "time": correction.get("old_finish_time", ""),
                "hub_xet_hash": correction.get("hub_xet_hash", ""),
                "size_bytes": correction.get("size_bytes", ""),
                "acquisition_protocol_version": correction.get(
                    "acquisition_protocol_version", ""
                ),
            }
            for field, expected in reconstructed_expectations.items():
                if reconstructed.get(field) != expected:
                    errors.append(f"{label}: reconstructed metadata {field} differs")
        if old_path in sha256_entries:
            errors.append(f"{label}: old path remains in active SHA256SUMS")
        if sha256_entries.get(new_path) != correction.get("sha256"):
            errors.append(f"{label}: active SHA256SUMS path/hash differs")

    expected_ids = {
        row.get("record_id", "") for row in historical_relationship_rows
    }
    if set(correction_by_id) != expected_ids:
        errors.append(
            "finish_time_correction.csv record IDs differ from the affected "
            "Sep-02 relationship rows"
        )
    return correction_by_id


def validate_local_audit_receipts(
    manifest: dict[str, object], errors: list[str]
) -> dict[str, int]:
    receipts = manifest.get("local_source_audits")
    if not isinstance(receipts, list) or len(receipts) != 7:
        errors.append("source_manifest must list seven retained local audit receipts")
        return {}
    canonical_counts: dict[str, int] = {}
    total_rows = 0
    total_roles: Counter[str] = Counter()
    for receipt in receipts:
        if not isinstance(receipt, dict):
            errors.append("source_manifest local audit receipt is not an object")
            continue
        audit_id = str(receipt.get("source_audit_id", ""))
        if not audit_id or audit_id in canonical_counts:
            errors.append(f"duplicate or blank source_audit_id: {audit_id!r}")
            continue
        if receipt.get("availability") != "retained_locally_not_bundled":
            errors.append(f"{audit_id}: local audit availability is unexpected")
        digest = receipt.get("sha256")
        if not isinstance(digest, str) or not HASH_RE.fullmatch(digest):
            errors.append(f"{audit_id}: local audit SHA-256 receipt is malformed")
        if not isinstance(receipt.get("size_bytes"), int) or receipt["size_bytes"] <= 0:
            errors.append(f"{audit_id}: local audit byte-size receipt is malformed")
        revision = receipt.get("base_hub_revision")
        if not isinstance(revision, str) or not REVISION_RE.fullmatch(revision):
            errors.append(f"{audit_id}: local audit base revision is malformed")
        row_count = receipt.get("row_count")
        role_counts = receipt.get("object_role_counts")
        if not isinstance(row_count, int) or not isinstance(role_counts, dict):
            errors.append(f"{audit_id}: local audit counts are malformed")
            continue
        if any(not isinstance(value, int) or value < 0 for value in role_counts.values()):
            errors.append(f"{audit_id}: local audit role counts are malformed")
            continue
        if sum(role_counts.values()) != row_count:
            errors.append(f"{audit_id}: local audit role counts do not sum to row_count")
        total_rows += row_count
        total_roles.update(role_counts)
        canonical_counts[audit_id] = int(role_counts.get("canonical_fragment", 0))
    if total_rows != 191 or total_roles != Counter(
        {"canonical_fragment": EXPECTED_ROWS, "noncanonical_inshot_derivative": 5}
    ):
        errors.append("local audit receipt aggregate counts are unexpected")
    expected_scope = {
        "audit_rows": 191,
        "relationship_rows": 191,
        "canonical_fragment_rows": EXPECTED_ROWS,
        "excluded_noncanonical_derivative_rows": 5,
        "fragment_groups": EXPECTED_GROUPS,
    }
    if manifest.get("source_scope") != expected_scope:
        errors.append("source_manifest source_scope differs")
    return canonical_counts


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--timing-dir", type=Path)
    args = parser.parse_args()

    root = args.root.resolve()
    timing_dir = (
        args.timing_dir.resolve()
        if args.timing_dir
        else root / "Standard_Time_Lapses" / "Provenance" / "Recording_Timing"
    )
    errors: list[str] = []

    required_files = {
        "README.md",
        "SCHEMA.md",
        "recording_timing.csv",
        "calibration_observations.csv",
        "group_timing_summary.csv",
        "calibration_model.json",
        "source_manifest.json",
        "validation_summary.json",
        "bundle.sha256",
    }
    missing = sorted(name for name in required_files if not (timing_dir / name).is_file())
    if missing:
        raise SystemExit(f"missing timing files: {missing}")

    timing_fields, timing_rows = read_csv(timing_dir / "recording_timing.csv")
    calibration_fields, calibration_rows = read_csv(
        timing_dir / "calibration_observations.csv"
    )
    group_fields, group_rows = read_csv(timing_dir / "group_timing_summary.csv")
    model = read_json(timing_dir / "calibration_model.json")
    manifest = read_json(timing_dir / "source_manifest.json")
    validation = read_json(timing_dir / "validation_summary.json")

    if timing_fields != TIMING_FIELDS:
        errors.append(f"recording_timing.csv field contract differs: {timing_fields}")
    if calibration_fields != CALIBRATION_FIELDS:
        errors.append(
            f"calibration_observations.csv field contract differs: {calibration_fields}"
        )
    if group_fields != GROUP_FIELDS:
        errors.append(f"group_timing_summary.csv field contract differs: {group_fields}")
    if len(timing_rows) != EXPECTED_ROWS:
        errors.append(f"expected {EXPECTED_ROWS} timing rows, found {len(timing_rows)}")
    if len(calibration_rows) != EXPECTED_DIRECT:
        errors.append(
            f"expected {EXPECTED_DIRECT} calibration rows, found {len(calibration_rows)}"
        )
    if len(group_rows) != EXPECTED_GROUPS:
        errors.append(f"expected {EXPECTED_GROUPS} group rows, found {len(group_rows)}")

    relationship_rows = validate_source_receipts(root, manifest, errors)
    expected_audit_counts = validate_local_audit_receipts(manifest, errors)
    metadata_fields, metadata_rows = read_csv(root / "metadata.csv")
    correction_by_id = validate_correction_bridge(
        root, metadata_fields, metadata_rows, timing_rows, errors
    )
    for field in ("record_id", "file_name", "hub_xet_hash"):
        values = [row.get(field, "") for row in metadata_rows]
        if not all(values) or len(values) != len(set(values)):
            errors.append(f"metadata.csv {field} values must be nonblank and unique")
    metadata_by_id = {row["record_id"]: row for row in metadata_rows}
    canonical_relationships = {
        row["record_id"]: row
        for row in relationship_rows
        if row.get("object_role") == "canonical_fragment"
    }
    if len(canonical_relationships) != EXPECTED_ROWS:
        errors.append(
            f"expected {EXPECTED_ROWS} canonical relationship rows, "
            f"found {len(canonical_relationships)}"
        )

    for field in ("record_id", "file_path", "sha256", "hub_xet_hash"):
        values = [row.get(field, "") for row in timing_rows]
        if not all(values) or len(values) != len(set(values)):
            errors.append(f"{field} values must be nonblank and unique")

    timing_by_id = {row["record_id"]: row for row in timing_rows}
    groups: dict[str, list[dict[str, str]]] = defaultdict(list)
    basis_counts: Counter[str] = Counter()
    profile_counts: Counter[str] = Counter()
    audit_counts: Counter[str] = Counter()
    serialized_elapsed_values: list[Decimal] = []
    unrounded_elapsed_values: list[Decimal] = []

    for row_number, row in enumerate(timing_rows, start=2):
        label = f"recording_timing.csv row {row_number} {row.get('record_id', '')}"
        record_id = row.get("record_id", "")
        if not RECORD_RE.fullmatch(record_id):
            errors.append(f"{label}: invalid record_id")
        if not HASH_RE.fullmatch(row.get("sha256", "")):
            errors.append(f"{label}: invalid ordinary SHA-256")
        if not HASH_RE.fullmatch(row.get("hub_xet_hash", "")):
            errors.append(f"{label}: invalid Xet identity")
        if not REVISION_RE.fullmatch(row.get("source_hub_revision", "")):
            errors.append(f"{label}: invalid source_hub_revision")

        relationship = canonical_relationships.get(record_id)
        metadata = metadata_by_id.get(record_id)
        correction = correction_by_id.get(record_id)
        if relationship is None:
            errors.append(f"{label}: record_id is absent from canonical relationships")
        else:
            for timing_name, relationship_name in (
                ("file_path", "file_path"),
                ("sha256", "sha256"),
                ("hub_xet_hash", "hub_xet_hash"),
                ("fragment_set_label", "fragment_set_label"),
                ("sequence_position", "sequence_position"),
                ("sequence_count", "sequence_count"),
                ("source_hub_revision", "source_hub_revision"),
            ):
                if row.get(timing_name) != relationship.get(relationship_name):
                    errors.append(f"{label}: {timing_name} differs from relationship source")
        if metadata is None:
            errors.append(f"{label}: record_id is absent from metadata.csv")
        else:
            expected_current_path = (
                correction.get("new_file_path", "")
                if correction is not None
                else row.get("file_path", "")
            )
            if expected_current_path != metadata.get("file_name"):
                errors.append(f"{label}: file_path differs from metadata.csv")
            if row.get("hub_xet_hash") != metadata.get("hub_xet_hash"):
                errors.append(f"{label}: hub_xet_hash differs from metadata.csv")
            if relationship is not None:
                expected_relationship_path = (
                    correction.get("old_file_path", "")
                    if correction is not None
                    else metadata.get("file_name", "")
                )
                if relationship.get("file_path") != expected_relationship_path:
                    errors.append(f"{label}: relationship path differs from metadata.csv")
                if relationship.get("hub_xet_hash") != metadata.get("hub_xet_hash"):
                    errors.append(f"{label}: relationship Xet identity differs from metadata.csv")
                if relationship.get("size_bytes") != metadata.get("size_bytes"):
                    errors.append(f"{label}: relationship byte size differs from metadata.csv")
            expected_current_date = (
                correction.get("new_finish_date", "")
                if correction is not None
                else row.get("documented_group_finish_date", "")
            )
            expected_current_time = (
                correction.get("new_finish_time", "")
                if correction is not None
                else row.get("documented_group_finish_time", "")
            )
            if expected_current_date != metadata.get("date"):
                errors.append(f"{label}: documented finish date differs from metadata.csv")
            if expected_current_time != metadata.get("time"):
                errors.append(f"{label}: documented finish time differs from metadata.csv")

        if row.get("format_creation_time_utc") != row.get("video_creation_time_utc"):
            errors.append(f"{label}: format/video creation_time values differ")
        if row.get("capture_fps_tag_literal") != "5.000000":
            errors.append(f"{label}: literal capture tag is not preserved")
        if row.get("local_time_zone") != LOCAL_ZONE_NAME:
            errors.append(f"{label}: unexpected local time zone")
        if row.get("timing_model_id") != MODEL_ID:
            errors.append(f"{label}: unexpected timing model ID")

        frames = parse_int(row.get("video_frame_count", ""), label, errors)
        if frames is not None and frames <= 0:
            errors.append(f"{label}: video_frame_count must be positive")
        boundary = parse_timestamp(
            row.get("format_creation_time_utc", ""), f"{label} creation boundary", errors
        )
        boundary_local = parse_timestamp(
            row.get("format_creation_time_local", ""), f"{label} local boundary", errors
        )
        if boundary is not None and boundary_local is not None:
            close_timestamp(
                boundary_local,
                boundary,
                0.001,
                f"{label} local/UTC creation boundary",
                errors,
            )
        capture_start = parse_timestamp(
            row.get("capture_start_time_utc", ""), f"{label} capture start", errors
        )
        capture_start_local = parse_timestamp(
            row.get("capture_start_time_local", ""),
            f"{label} local capture start",
            errors,
        )
        if capture_start is not None and capture_start_local is not None:
            close_timestamp(
                capture_start_local,
                capture_start,
                0.001,
                f"{label} local/UTC capture start",
                errors,
            )

        basis = row.get("timing_basis", "")
        profile = row.get("calibration_profile_status", "")
        basis_counts[basis] += 1
        profile_counts[profile] += 1
        audit_counts[row.get("source_audit_id", "")] += 1
        elapsed = parse_decimal(
            row.get("recording_elapsed_seconds", ""), f"{label} elapsed", errors
        )
        uncertainty = parse_decimal(
            row.get("start_uncertainty_seconds", ""),
            f"{label} start uncertainty",
            errors,
        )
        if elapsed is not None:
            serialized_elapsed_values.append(elapsed)
        if basis == "direct_device_filename_start":
            if profile != "calibration_observation":
                errors.append(f"{label}: direct row has unexpected profile status")
            direct_start = device_filename_timestamp(row.get("source_filename", ""), label, errors)
            retained_start = parse_timestamp(
                row.get("device_filename_start_local", ""),
                f"{label} retained filename timestamp",
                errors,
            )
            if direct_start is not None:
                close_timestamp(
                    retained_start,
                    direct_start,
                    0.001,
                    f"{label} retained filename timestamp",
                    errors,
                )
                close_timestamp(
                    capture_start,
                    direct_start,
                    0.001,
                    f"{label} selected direct start",
                    errors,
                )
                if boundary is not None:
                    expected_elapsed = Decimal(
                        str(
                            (
                                boundary.astimezone(timezone.utc)
                                - direct_start.astimezone(timezone.utc)
                            ).total_seconds()
                        )
                    )
                    unrounded_elapsed_values.append(expected_elapsed)
                    close_decimal(
                        elapsed,
                        expected_elapsed,
                        Decimal("0.001"),
                        f"{label} direct elapsed",
                        errors,
                    )
            close_decimal(
                uncertainty,
                Decimal(1),
                Decimal(0),
                f"{label} direct uncertainty",
                errors,
            )
        elif basis == "calibrated_frame_model":
            if profile != "observable_profile_match_only":
                errors.append(f"{label}: calibrated row has unexpected profile status")
            if row.get("device_filename_start_local"):
                errors.append(f"{label}: calibrated row has a device filename start")
            if frames is not None:
                expected_elapsed = (
                    MODEL_INTERCEPT
                    + Decimal(frames) * MODEL_FRAME_NUMERATOR / MODEL_FRAME_DENOMINATOR
                )
                unrounded_elapsed_values.append(expected_elapsed)
                close_decimal(
                    elapsed,
                    expected_elapsed,
                    Decimal("0.0006"),
                    f"{label} calibrated elapsed",
                    errors,
                )
                if boundary is not None and capture_start is not None:
                    expected_start = boundary - timedelta(seconds=float(expected_elapsed))
                    close_timestamp(
                        capture_start,
                        expected_start,
                        0.001,
                        f"{label} calibrated start",
                        errors,
                    )
            close_decimal(
                uncertainty,
                Decimal(2),
                Decimal(0),
                f"{label} calibrated uncertainty",
                errors,
            )
        else:
            errors.append(f"{label}: invalid timing_basis {basis!r}")

        evidence = row.get("timing_evidence_state", "")
        evidence_tokens = evidence.split(";") if evidence else []
        if not evidence_tokens or len(evidence_tokens) != len(set(evidence_tokens)):
            errors.append(f"{label}: timing_evidence_state is blank or duplicated")
        if "capture-fps-tag-preserved-not-used" not in evidence_tokens:
            errors.append(f"{label}: evidence does not state capture tag non-use")

        groups[row.get("fragment_set_label", "")].append(row)

    if basis_counts != Counter(
        {
            "direct_device_filename_start": EXPECTED_DIRECT,
            "calibrated_frame_model": EXPECTED_CALIBRATED,
        }
    ):
        errors.append(f"unexpected timing_basis counts: {dict(basis_counts)}")
    if profile_counts != Counter(
        {
            "calibration_observation": EXPECTED_DIRECT,
            "observable_profile_match_only": EXPECTED_CALIBRATED,
        }
    ):
        errors.append(f"unexpected calibration_profile_status counts: {dict(profile_counts)}")
    if dict(audit_counts) != expected_audit_counts:
        errors.append(
            f"source_audit_id counts differ from retained receipts: {dict(audit_counts)}"
        )
    if len(groups) != EXPECTED_GROUPS:
        errors.append(f"expected {EXPECTED_GROUPS} timing groups, found {len(groups)}")

    gap_counts: Counter[str] = Counter()
    conflict_groups: dict[str, Decimal] = {}
    near_finish_deltas: list[Decimal] = []
    computed_group_rows: dict[str, dict[str, Decimal | int | str]] = {}
    transition_count = 0
    for group_label, rows in groups.items():
        rows.sort(key=lambda item: int(item["sequence_position"]))
        positions = [int(row["sequence_position"]) for row in rows]
        counts = {int(row["sequence_count"]) for row in rows}
        if positions != list(range(1, len(rows) + 1)) or counts != {len(rows)}:
            errors.append(f"{group_label}: sequence positions/count are not contiguous")
        if len({row["source_hub_revision"] for row in rows}) != 1:
            errors.append(f"{group_label}: mixed source_hub_revision values")
        finish_pairs = {
            (row["documented_group_finish_date"], row["documented_group_finish_time"])
            for row in rows
        }
        if len(finish_pairs) != 1:
            errors.append(f"{group_label}: mixed documented group finish values")
            continue
        finish_date, finish_time = next(iter(finish_pairs))
        try:
            documented_finish = datetime.strptime(
                f"{finish_date} {finish_time}", "%Y-%m-%d %H:%M"
            ).replace(tzinfo=LOCAL_ZONE)
        except ValueError:
            errors.append(f"{group_label}: invalid documented group finish")
            continue
        final_boundary = parse_timestamp(
            rows[-1]["format_creation_time_utc"], f"{group_label} final boundary", errors
        )
        if final_boundary is None:
            continue
        expected_finish_delta = Decimal(
            str(
                (
                    final_boundary.astimezone(timezone.utc)
                    - documented_finish.astimezone(timezone.utc)
                ).total_seconds()
            )
        )
        expected_finish_status = (
            "near_documented_finish_minute"
            if abs(expected_finish_delta) <= Decimal(120)
            else "documented_finish_conflict"
        )
        for row in rows:
            close_decimal(
                parse_decimal(
                    row["group_finish_delta_seconds"],
                    f"{group_label} finish delta",
                    errors,
                ),
                expected_finish_delta,
                Decimal("0.001"),
                f"{group_label} finish delta",
                errors,
            )
            if row["group_finish_crosscheck_status"] != expected_finish_status:
                errors.append(f"{group_label}: incorrect finish crosscheck status")
        if expected_finish_status == "documented_finish_conflict":
            conflict_groups[group_label] = expected_finish_delta
        else:
            near_finish_deltas.append(abs(expected_finish_delta))

        elapsed_sum = Decimal(0)
        gap_sum = Decimal(0)
        first_start: datetime | None = None
        previous_boundary: datetime | None = None
        previous_record_id = ""
        within_uncertainty_count = 0
        for index, row in enumerate(rows):
            elapsed_value = parse_decimal(
                row["recording_elapsed_seconds"], f"{group_label} elapsed", errors
            )
            if elapsed_value is not None:
                elapsed_sum += elapsed_value
            start = parse_timestamp(
                row["capture_start_time_utc"], f"{group_label} capture start", errors
            )
            boundary = parse_timestamp(
                row["format_creation_time_utc"], f"{group_label} boundary", errors
            )
            if index == 0:
                first_start = start
                if row["previous_record_id"] or row["inter_fragment_gap_seconds"] or row["gap_uncertainty_seconds"]:
                    errors.append(f"{group_label}: first row has previous/gap values")
                if row["gap_status"] != "blank_for_first":
                    errors.append(f"{group_label}: first row gap_status is not blank_for_first")
            else:
                transition_count += 1
                if row["previous_record_id"] != previous_record_id:
                    errors.append(f"{group_label}: previous_record_id chain is broken")
                if start is not None and previous_boundary is not None:
                    expected_gap = Decimal(
                        str(
                            (
                                start.astimezone(timezone.utc)
                                - previous_boundary.astimezone(timezone.utc)
                            ).total_seconds()
                        )
                    )
                    gap = parse_decimal(
                        row["inter_fragment_gap_seconds"], f"{group_label} gap", errors
                    )
                    close_decimal(
                        gap,
                        expected_gap,
                        Decimal("0.001"),
                        f"{group_label} gap",
                        errors,
                    )
                    if gap is not None:
                        gap_sum += gap
                    uncertainty = Decimal(
                        2 if row["timing_basis"] == "direct_device_filename_start" else 3
                    )
                    close_decimal(
                        parse_decimal(
                            row["gap_uncertainty_seconds"],
                            f"{group_label} gap uncertainty",
                            errors,
                        ),
                        uncertainty,
                        Decimal(0),
                        f"{group_label} gap uncertainty",
                        errors,
                    )
                    expected_gap_status = (
                        "negative_beyond_uncertainty"
                        if expected_gap < -uncertainty
                        else "within_uncertainty_of_zero"
                        if abs(expected_gap) <= uncertainty
                        else "positive_above_uncertainty"
                    )
                    if row["gap_status"] != expected_gap_status:
                        errors.append(f"{group_label}: incorrect gap_status")
                    if expected_gap_status == "within_uncertainty_of_zero":
                        within_uncertainty_count += 1
                gap_counts[row["gap_status"]] += 1
            previous_boundary = boundary
            previous_record_id = row["record_id"]

        if first_start is not None:
            wall_span = Decimal(
                str(
                    (
                        final_boundary.astimezone(timezone.utc)
                        - first_start.astimezone(timezone.utc)
                    ).total_seconds()
                )
            )
            if abs(wall_span - elapsed_sum - gap_sum) > Decimal("0.01"):
                errors.append(f"{group_label}: elapsed + gaps does not equal wall span")
            computed_group_rows[group_label] = {
                "fragment_count": len(rows),
                "direct_start_count": sum(
                    row["timing_basis"] == "direct_device_filename_start" for row in rows
                ),
                "calibrated_start_count": sum(
                    row["timing_basis"] == "calibrated_frame_model" for row in rows
                ),
                "elapsed_sum": elapsed_sum,
                "gap_sum": gap_sum,
                "wall_span": wall_span,
                "within_uncertainty_count": within_uncertainty_count,
                "finish_delta": expected_finish_delta,
                "finish_status": expected_finish_status,
            }

    if transition_count != EXPECTED_TRANSITIONS:
        errors.append(
            f"expected {EXPECTED_TRANSITIONS} transitions, found {transition_count}"
        )
    expected_gap_counts = Counter(
        {"positive_above_uncertainty": 159, "within_uncertainty_of_zero": 2}
    )
    if gap_counts != expected_gap_counts:
        errors.append(f"unexpected transition gap counts: {dict(gap_counts)}")
    if conflict_groups != {EXPECTED_CONFLICT_GROUP: EXPECTED_CONFLICT_DELTA}:
        errors.append(f"unexpected finish conflicts: {conflict_groups}")

    corrected_historical_rows = sorted(
        (
            row
            for row in timing_rows
            if row.get("record_id") in correction_by_id
        ),
        key=lambda row: int(row["sequence_position"]),
    )
    active_finish_delta: Decimal | None = None
    active_finish_status = ""
    if len(corrected_historical_rows) != EXPECTED_CORRECTION_ROWS:
        errors.append("documented correction does not bridge exactly 12 timing rows")
    else:
        active_final_boundary = parse_timestamp(
            corrected_historical_rows[-1]["format_creation_time_utc"],
            "corrected active group final boundary",
            errors,
        )
        active_documented_finish = datetime(
            2026, 9, 1, 14, 13, tzinfo=LOCAL_ZONE
        )
        if active_final_boundary is not None:
            active_finish_delta = Decimal(
                str(
                    (
                        active_final_boundary.astimezone(timezone.utc)
                        - active_documented_finish.astimezone(timezone.utc)
                    ).total_seconds()
                )
            )
            active_finish_status = (
                "near_documented_finish_minute"
                if abs(active_finish_delta) <= Decimal(120)
                else "documented_finish_conflict"
            )
            close_decimal(
                active_finish_delta,
                EXPECTED_CORRECTED_DELTA,
                Decimal(0),
                "corrected active finish delta",
                errors,
            )
            if active_finish_status != "near_documented_finish_minute":
                errors.append("corrected active finish is not near the documented minute")

    group_by_label = {row["fragment_set_label"]: row for row in group_rows}
    if len(group_by_label) != len(group_rows):
        errors.append("group_timing_summary.csv has duplicate fragment_set_label values")
    for group_label, computed in computed_group_rows.items():
        row = group_by_label.get(group_label)
        if row is None:
            errors.append(f"group summary is missing {group_label}")
            continue
        for field, key in (
            ("fragment_count", "fragment_count"),
            ("direct_start_count", "direct_start_count"),
            ("calibrated_start_count", "calibrated_start_count"),
            ("within_uncertainty_gap_count", "within_uncertainty_count"),
        ):
            if int(row[field]) != computed[key]:
                errors.append(f"{group_label}: group summary {field} differs")
        for field, key in (
            ("recording_elapsed_seconds_sum", "elapsed_sum"),
            ("within_group_gap_seconds_sum", "gap_sum"),
            ("group_wall_span_seconds", "wall_span"),
            ("group_finish_delta_seconds", "finish_delta"),
        ):
            close_decimal(
                parse_decimal(row[field], f"{group_label} summary {field}", errors),
                computed[key],
                Decimal("0.01"),
                f"{group_label} summary {field}",
                errors,
            )
        if row["group_finish_crosscheck_status"] != computed["finish_status"]:
            errors.append(f"{group_label}: group summary finish status differs")

    calibration_by_id = {row["record_id"]: row for row in calibration_rows}
    if len(calibration_by_id) != EXPECTED_DIRECT:
        errors.append("calibration observations have duplicate record IDs")
    residuals: list[Decimal] = []
    no_intercept_residuals: list[Decimal] = []
    wall_frame_rates: list[Decimal] = []
    nominal_five_errors: list[Decimal] = []
    for record_id, calibration in calibration_by_id.items():
        timing = timing_by_id.get(record_id)
        label = f"calibration {record_id}"
        if timing is None or timing.get("timing_basis") != "direct_device_filename_start":
            errors.append(f"{label}: does not join to a direct timing row")
            continue
        if calibration["file_path"] != timing["file_path"] or calibration["source_filename"] != timing["source_filename"]:
            errors.append(f"{label}: identity fields differ from timing row")
        start = parse_timestamp(calibration["direct_start_utc"], f"{label} start", errors)
        boundary = parse_timestamp(
            calibration["creation_boundary_utc"], f"{label} boundary", errors
        )
        frames = parse_int(calibration["video_frame_count"], label, errors)
        if start is None or boundary is None or frames is None:
            continue
        observed = Decimal(str((boundary - start).total_seconds()))
        nominal = Decimal(frames) / Decimal(5)
        modeled = MODEL_INTERCEPT + Decimal(frames) * MODEL_FRAME_NUMERATOR / MODEL_FRAME_DENOMINATOR
        residual = observed - modeled
        residuals.append(residual)
        no_intercept_residuals.append(
            observed - Decimal(frames) * MODEL_FRAME_NUMERATOR / MODEL_FRAME_DENOMINATOR
        )
        wall_frame_rates.append(Decimal(frames) / observed)
        nominal_five_errors.append(observed - nominal)
        for field, expected, tolerance in (
            ("observed_elapsed_seconds", observed, Decimal("0.001")),
            ("nominal_five_fps_elapsed_seconds", nominal, Decimal("0.001")),
            ("nominal_five_fps_error_seconds", observed - nominal, Decimal("0.001")),
            ("model_elapsed_seconds", modeled, Decimal("0.0006")),
            ("model_residual_seconds", residual, Decimal("0.0006")),
        ):
            close_decimal(
                parse_decimal(calibration[field], f"{label} {field}", errors),
                expected,
                tolerance,
                f"{label} {field}",
                errors,
            )
        effective = Decimal(frames) / observed
        close_decimal(
            parse_decimal(
                calibration["video_frames_per_observed_wall_second"],
                f"{label} video frames per observed wall second",
                errors,
            ),
            effective,
            Decimal("0.000001"),
            f"{label} video frames per observed wall second",
            errors,
        )

    if model.get("model_id") != MODEL_ID:
        errors.append("calibration_model.json has an unexpected model_id")
    if model.get("status") != "revision_pinned_exploratory_in_sample_calibration":
        errors.append("calibration_model.json has an unexpected status")
    if model.get("source_dataset_revision") != EXPECTED_SOURCE_REVISION:
        errors.append("calibration_model.json source revision differs")
    if model.get("formula") != (
        "estimated_elapsed_seconds = 0.8 + video_frame_count * 7 / 30"
    ):
        errors.append("calibration_model.json formula differs")
    constants = model.get("constants")
    if not isinstance(constants, dict):
        errors.append("calibration_model.json constants are missing")
    else:
        expected_constants = {
            "empirical_intercept_seconds": float(MODEL_INTERCEPT),
            "seconds_per_frame_numerator": int(MODEL_FRAME_NUMERATOR),
            "seconds_per_frame_denominator": int(MODEL_FRAME_DENOMINATOR),
        }
        if constants != expected_constants:
            errors.append(f"calibration model constants differ: {constants}")
    calibration_model_section = model.get("calibration")
    if not isinstance(calibration_model_section, dict):
        errors.append("calibration_model.json calibration section is missing")
    else:
        if calibration_model_section.get("sample_count") != EXPECTED_DIRECT:
            errors.append("calibration model sample_count differs")
        if calibration_model_section.get("group_count") != 5:
            errors.append("calibration model group_count differs")
        if calibration_model_section.get("holdout_count") != 0:
            errors.append("calibration model must state that no holdout exists")
        if len(residuals) == EXPECTED_DIRECT:
            validate_metric_block(
                calibration_model_section.get(
                    "model_residual_seconds_observed_minus_estimated"
                ),
                {
                    "minimum": min(residuals),
                    "maximum": max(residuals),
                    "mean": decimal_mean(residuals),
                    "standard_deviation_population": decimal_population_standard_deviation(
                        residuals
                    ),
                    "root_mean_square": decimal_root_mean_square(residuals),
                    "maximum_absolute": max(abs(value) for value in residuals),
                },
                Decimal("0.0000006"),
                "calibration model residual metrics",
                errors,
            )
            validate_metric_block(
                calibration_model_section.get(
                    "no_offset_seven_thirtieths_residual_seconds"
                ),
                {
                    "minimum": min(no_intercept_residuals),
                    "maximum": max(no_intercept_residuals),
                    "mean": decimal_mean(no_intercept_residuals),
                },
                Decimal("0.0000006"),
                "calibration no-intercept residual metrics",
                errors,
            )
            validate_metric_block(
                calibration_model_section.get(
                    "video_frames_per_observed_wall_second"
                ),
                {
                    "minimum": min(wall_frame_rates),
                    "maximum": max(wall_frame_rates),
                    "mean": decimal_mean(wall_frame_rates),
                    "standard_deviation_population": decimal_population_standard_deviation(
                        wall_frame_rates
                    ),
                },
                Decimal("0.00000006"),
                "calibration video-frames-per-observed-wall-second metrics",
                errors,
            )
            validate_metric_block(
                calibration_model_section.get(
                    "nominal_five_fps_error_seconds_observed_minus_n_over_5"
                ),
                {
                    "minimum": min(nominal_five_errors),
                    "maximum": max(nominal_five_errors),
                    "mean": decimal_mean(nominal_five_errors),
                },
                Decimal("0.0006"),
                "calibration nominal-five-fps error metrics",
                errors,
            )

    application = model.get("application")
    if not isinstance(application, dict):
        errors.append("calibration_model.json application section is missing")
    else:
        expected_application_values = {
            "direct_start_rows": EXPECTED_DIRECT,
            "calibrated_estimate_rows": EXPECTED_CALIBRATED,
            "direct_filename_timestamp_resolution_allowance_seconds": 1,
            "estimated_start_uncertainty_seconds": 2,
            "calibrated_gap_uncertainty_seconds": 3,
        }
        for name, expected in expected_application_values.items():
            if application.get(name) != expected:
                errors.append(f"calibration application {name} differs")
        if not isinstance(application.get("profile_match_fields"), list) or len(
            application["profile_match_fields"]
        ) != 8:
            errors.append("calibration application profile-match declaration differs")

    if validation.get("status") != "pass_with_one_preserved_documented_finish_conflict":
        errors.append("validation_summary status differs")
    if validation.get("verification_level") != "repository_packet_self_consistency":
        errors.append("validation_summary verification level differs")
    counts = validation.get("counts")
    if not isinstance(counts, dict):
        errors.append("validation_summary counts are missing")
    else:
        expected_counts = {
            "canonical_timing_rows": EXPECTED_ROWS,
            "direct_device_filename_start_rows": EXPECTED_DIRECT,
            "calibrated_frame_model_rows": EXPECTED_CALIBRATED,
            "calibration_groups": 5,
            "fragment_groups": EXPECTED_GROUPS,
            "inter_fragment_transitions": EXPECTED_TRANSITIONS,
            "excluded_noncanonical_derivatives": 5,
        }
        if counts != expected_counts:
            errors.append(f"validation_summary counts differ: {counts}")
    if validation.get("pinned_dataset_revision") != EXPECTED_SOURCE_REVISION:
        errors.append("validation_summary pinned revision differs")

    expected_repository_checks = {
        "timing_relationship_record_id_path_sets_equal": True,
        "timing_relationship_record_id_path_sha256_xet_matches": True,
        "canonical_metadata_record_id_size_xet_matches": True,
        "canonical_record_ids_paths_sha256_unique": True,
        "format_video_creation_times_equal": True,
        "exact_literal_capture_tag_preserved": "5.000000",
        "literal_capture_tag_used_in_timing_formula": False,
    }
    if validation.get("repository_identity_and_source_checks") != expected_repository_checks:
        errors.append("validation_summary repository identity/source checks differ")

    expected_local_claims = {
        "audit_relationship_path_sets_equal": True,
        "audit_record_id_sha256_size_matches": True,
        "all_rows_same_observable_technical_profile": True,
    }
    if validation.get("retained_local_audit_claims_not_reperformed") != expected_local_claims:
        errors.append("validation_summary retained local-audit claims differ")

    calibration_checks = validation.get("calibration_checks")
    if not isinstance(calibration_checks, dict):
        errors.append("validation_summary calibration_checks is missing")
    else:
        expected_calibration_values = {
            "model_id": MODEL_ID,
            "formula": "estimated_elapsed_seconds = 0.8 + video_frame_count * 7 / 30",
            "direct_observation_count": EXPECTED_DIRECT,
            "holdout_count": 0,
        }
        for name, expected in expected_calibration_values.items():
            if calibration_checks.get(name) != expected:
                errors.append(f"validation_summary calibration {name} differs")
        if residuals:
            close_decimal(
                parse_decimal(
                    str(calibration_checks.get("maximum_absolute_model_residual_seconds", "")),
                    "validation_summary maximum absolute residual",
                    errors,
                ),
                max(abs(value) for value in residuals),
                Decimal("0.0000006"),
                "validation_summary maximum absolute residual",
                errors,
            )
        if nominal_five_errors:
            for name, expected in (
                ("nominal_five_fps_minimum_error_seconds", min(nominal_five_errors)),
                ("nominal_five_fps_maximum_error_seconds", max(nominal_five_errors)),
            ):
                close_decimal(
                    parse_decimal(
                        str(calibration_checks.get(name, "")),
                        f"validation_summary {name}",
                        errors,
                    ),
                    expected,
                    Decimal("0.0006"),
                    f"validation_summary {name}",
                    errors,
                )

    expected_chronology = {
        "groups_with_contiguous_positions": EXPECTED_GROUPS,
        "strictly_increasing_creation_boundaries_within_groups": True,
        "gaps_positive_above_uncertainty": gap_counts["positive_above_uncertainty"],
        "gaps_within_uncertainty_of_zero": gap_counts["within_uncertainty_of_zero"],
        "gaps_negative_beyond_uncertainty": gap_counts["negative_beyond_uncertainty"],
    }
    if validation.get("chronology_checks") != expected_chronology:
        errors.append("validation_summary chronology checks differ")

    finish_summary = validation.get("documented_finish_crosscheck")
    if not isinstance(finish_summary, dict):
        errors.append("validation_summary documented finish crosscheck is missing")
    else:
        if finish_summary.get("threshold_seconds") != 120:
            errors.append("validation_summary finish threshold differs")
        if finish_summary.get("near_minute_groups") != len(near_finish_deltas):
            errors.append("validation_summary near-minute group count differs")
        if near_finish_deltas:
            close_decimal(
                parse_decimal(
                    str(finish_summary.get("maximum_near_minute_delta_seconds", "")),
                    "validation_summary maximum near-minute delta",
                    errors,
                ),
                max(near_finish_deltas),
                Decimal("0.001"),
                "validation_summary maximum near-minute delta",
                errors,
            )
        conflicts = finish_summary.get("conflict_groups")
        if not isinstance(conflicts, list) or len(conflicts) != 1:
            errors.append("validation_summary conflict group receipt differs")
        else:
            conflict = conflicts[0]
            if not isinstance(conflict, dict):
                errors.append("validation_summary conflict group is malformed")
            else:
                if conflict.get("fragment_set_label") != EXPECTED_CONFLICT_GROUP:
                    errors.append("validation_summary conflict label differs")
                close_decimal(
                    parse_decimal(
                        str(conflict.get("delta_seconds", "")),
                        "validation_summary conflict delta",
                        errors,
                    ),
                    EXPECTED_CONFLICT_DELTA,
                    Decimal("0"),
                    "validation_summary conflict delta",
                    errors,
                )

    serialized_total = sum(serialized_elapsed_values, Decimal(0))
    unrounded_total = sum(unrounded_elapsed_values, Decimal(0))
    aggregate = validation.get("aggregate_descriptors")
    if not isinstance(aggregate, dict):
        errors.append("validation_summary aggregate descriptors are missing")
    else:
        close_decimal(
            parse_decimal(
                str(aggregate.get("serialized_recording_elapsed_seconds_sum", "")),
                "validation_summary serialized elapsed sum",
                errors,
            ),
            serialized_total,
            Decimal("0"),
            "validation_summary serialized elapsed sum",
            errors,
        )
        close_decimal(
            parse_decimal(
                str(aggregate.get("serialized_recording_elapsed_hours_sum", "")),
                "validation_summary serialized elapsed hours",
                errors,
            ),
            serialized_total / Decimal(3600),
            Decimal("0.0000006"),
            "validation_summary serialized elapsed hours",
            errors,
        )
        note = aggregate.get("note")
        if not isinstance(note, str) or "0.001667 seconds" not in note:
            errors.append("validation_summary aggregate rounding note differs")
    close_decimal(
        unrounded_total,
        Decimal(1649602) / Decimal(15),
        Decimal("0.000000000000000000001"),
        "unrounded corpus elapsed total",
        errors,
    )

    expected_immutability = {
        "metadata_csv_sha256_unchanged": True,
        "relationship_sidecar_hashes_unchanged": True,
        "canonical_metadata_field_count_unchanged": True,
    }
    if validation.get("immutability_checks") != expected_immutability:
        errors.append("validation_summary immutability checks differ")

    expected_not_reperformed = {
        "source-media tag and frame-count probing",
        "source-media ordinary SHA-256 hashing",
        "retained local source-audit byte verification",
        "NTFS timestamp observation",
    }
    not_reperformed = validation.get("not_reperformed_by_repository_validator")
    if not isinstance(not_reperformed, list) or set(not_reperformed) != expected_not_reperformed:
        errors.append("validation_summary non-reperformed checks declaration differs")

    validate_bundle(timing_dir, errors)

    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        raise SystemExit(f"recording timing validation failed with {len(errors)} error(s)")

    print(
        json.dumps(
            {
                "status": "ok",
                "source_revision": EXPECTED_SOURCE_REVISION,
                "metadata_receipt_mode": (
                    "inverse_documented_correction_and_post_snapshot_provenance_and_"
                    "source_filename_backfills_exclude_verified_media_backfills_then_exact_pinned_snapshot"
                ),
                "pinned_metadata_rows": EXPECTED_CANONICAL_METADATA_RECEIPT["row_count"],
                "current_metadata_rows": len(metadata_rows),
                "documented_correction_rows": len(correction_by_id),
                "post_snapshot_provenance_backfill_rows": len(
                    EXPECTED_POST_SNAPSHOT_PROVENANCE_BACKFILL_IDS
                ),
                "post_snapshot_source_filename_backfill_rows": EXPECTED_SOURCE_FILENAME_BACKFILL_ROWS,
                "post_snapshot_media_backfill_rows": sum(
                    row.get("record_id") in EXPECTED_POST_SNAPSHOT_MEDIA_BACKFILLS
                    for row in metadata_rows
                ),
                "timing_rows": len(timing_rows),
                "direct_filename_timestamp_rows": basis_counts[
                    "direct_device_filename_start"
                ],
                "calibrated_rows": basis_counts["calibrated_frame_model"],
                "groups": len(groups),
                "transitions": transition_count,
                "gap_status_counts": dict(gap_counts),
                "historical_finish_conflicts": {
                    key: float(value) for key, value in conflict_groups.items()
                },
                "active_corrected_finish_crosscheck": {
                    "fragment_set_label": EXPECTED_CORRECTED_GROUP,
                    "delta_seconds": float(active_finish_delta),
                    "status": active_finish_status,
                },
                "active_sha256sum_paths_verified": len(correction_by_id),
                "bundle_files_verified": len(
                    [
                        path
                        for path in timing_dir.iterdir()
                        if path.is_file() and path.name != "bundle.sha256"
                    ]
                ),
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
