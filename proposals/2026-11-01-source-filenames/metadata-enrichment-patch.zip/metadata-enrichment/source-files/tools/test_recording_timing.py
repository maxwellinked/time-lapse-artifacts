#!/usr/bin/env python3
"""Focused regression tests for the recording-timing sidecar validator."""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


TOOLS = Path(__file__).resolve().parent
REPO_ROOT = TOOLS.parent
VALIDATOR = TOOLS / "validate_recording_timing.py"
TIMING_RELATIVE = Path(
    "Standard_Time_Lapses/Provenance/Recording_Timing"
)
CORRECTION_RELATIVE = Path(
    "Standard_Time_Lapses/Provenance/Corrections/"
    "2026-09-01.1413-finish-time/finish_time_correction.csv"
)
SOURCE_FILENAME_BACKFILL = Path(
    'Standard_Time_Lapses/Provenance/Corrections/'
    '2026-11-01-source-filenames/source_filename_backfill.json'
)
SOURCE_FILENAME_OBSERVATIONS = Path(
    'Standard_Time_Lapses/Provenance/Recording_Timing_v2/observations.json'
)
RELATIONSHIP_DATES = (
    "2026-08-27",
    "2026-08-29",
    "2026-08-30",
    "2026-08-31",
    "2026-09-01",
    "2026-09-02",
)


def rewrite_bundle(timing_dir: Path) -> None:
    entries = []
    for path in sorted(timing_dir.iterdir(), key=lambda item: item.name):
        if path.is_file() and path.name != "bundle.sha256":
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            entries.append(f"{digest}  {path.name}")
    (timing_dir / "bundle.sha256").write_text(
        "\n".join(entries) + "\n", encoding="utf-8", newline="\n"
    )


def read_csv_table(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def write_csv_table(
    path: Path, fieldnames: list[str], rows: list[dict[str, str]]
) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def synthetic_metadata_row(template: dict[str, str]) -> dict[str, str]:
    row = dict(template)
    row.update(
        {
            "file_name": (
                "Standard_Time_Lapses/2099-12-31.2359."
                "Pencil.Graphite.Paper.9x12.mp4"
            ),
            "record_id": "tla-0000000000000000",
            "date": "2099-12-31",
            "time": "23:59",
            "hub_xet_hash": "0" * 64,
            "original_filename": "",
            "legacy_provenance_path": "",
            "legacy_related_references": "",
            "provenance_reference_duration_delta_seconds": "",
            "notes": "Synthetic unrelated append-only validator fixture.",
        }
    )
    return row


class RecordingTimingValidatorTests(unittest.TestCase):
    def run_validator(self, root: Path) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(VALIDATOR), "--root", str(root)],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )

    def copy_fixture(self, destination: Path) -> Path:
        shutil.copy2(REPO_ROOT / "metadata.csv", destination / "metadata.csv")
        shutil.copy2(REPO_ROOT / "SHA256SUMS", destination / "SHA256SUMS")
        timing_destination = destination / TIMING_RELATIVE
        timing_destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(REPO_ROOT / TIMING_RELATIVE, timing_destination)
        for date in RELATIONSHIP_DATES:
            relative = Path(
                f"Standard_Time_Lapses/Provenance/{date}/fragment_sequence_relationships.csv"
            )
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(REPO_ROOT / relative, target)
        correction_target = destination / CORRECTION_RELATIVE
        correction_target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(REPO_ROOT / CORRECTION_RELATIVE, correction_target)
        for relative in (SOURCE_FILENAME_BACKFILL, SOURCE_FILENAME_OBSERVATIONS,
                         SOURCE_FILENAME_OBSERVATIONS.with_name('MANIFEST.json')):
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(REPO_ROOT / relative, target)
        # Current metadata retains its original rows and appends only the
        # registered F supplement. Its authority is separate from frozen timing.
        insertion = Path('Standard_Time_Lapses/Provenance/Sequence_Insertions')
        shutil.copytree(REPO_ROOT / insertion, destination / insertion)
        predecessor = Path('Standard_Time_Lapses/Provenance/2026-10-29/fragment_sequence_relationships.csv')
        (destination / predecessor).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(REPO_ROOT / predecessor, destination / predecessor)
        return timing_destination

    def test_source_filename_backfill_preserves_exact_frozen_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            before = (root / 'metadata.csv').read_bytes()
            self.assertEqual(hashlib.sha256(before).hexdigest(),
                             '3cbe9190b60cb15ced35ca5f1ffa123a3f4560d8f0b96dc4881b55ead33bce07')
            completed = self.run_validator(root)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            self.assertEqual(json.loads(completed.stdout)['post_snapshot_source_filename_backfill_rows'], 168)
            self.assertEqual(json.loads(completed.stdout)['pinned_metadata_rows'], 549)
            self.assertEqual((root / 'metadata.csv').read_bytes(), before)

    def test_source_filename_backfill_rejects_wrong_or_removed_name(self) -> None:
        for name in ('wrong-name.mp4', ''):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temp_dir:
                root = Path(temp_dir)
                self.copy_fixture(root)
                path = root / 'metadata.csv'
                fields, rows = read_csv_table(path)
                target = next(row for row in rows if row['record_id'] == 'tla-bed24891b6405ece')
                self.assertEqual(target['original_filename'],
                                 '2026-09-01.0213.BallpointPen.Ink.Paper.9x12.Rec01.mp4')
                target['original_filename'] = name
                write_csv_table(path, fields, rows)
                completed = self.run_validator(root)
                self.assertNotEqual(completed.returncode, 0)
                self.assertIn('source-filename backfill tla-bed24891b6405ece: current metadata original_filename differs', completed.stdout)

    def test_source_filename_inverse_does_not_hide_another_changed_cell(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            path = root / 'metadata.csv'
            fields, rows = read_csv_table(path)
            next(row for row in rows if row['record_id'] == 'tla-bed24891b6405ece')['notes'] += ' Unregistered change.'
            write_csv_table(path, fields, rows)
            completed = self.run_validator(root)
            self.assertNotEqual(completed.returncode, 0)
            self.assertIn('reconstructed pinned metadata snapshot differs from the source_manifest receipt', completed.stdout)

    def test_source_filename_backfill_checks_identity_outside_frozen_rows(self) -> None:
        for field, value in (('hub_xet_hash', '0' * 64), ('size_bytes', '1')):
            with self.subTest(field=field), tempfile.TemporaryDirectory() as temp_dir:
                root = Path(temp_dir)
                self.copy_fixture(root)
                path = root / 'metadata.csv'
                fields, rows = read_csv_table(path)
                next(row for row in rows if row['record_id'] == 'tla-5c6b8329390d241c')[field] = value
                write_csv_table(path, fields, rows)
                completed = self.run_validator(root)
                self.assertNotEqual(completed.returncode, 0)
                self.assertIn(f'source-filename backfill tla-5c6b8329390d241c: current metadata {field} differs', completed.stdout)

    def test_source_filename_backfill_rejects_changed_fixity(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            path = root / 'SHA256SUMS'
            changes = json.loads((root / SOURCE_FILENAME_BACKFILL).read_text())['changes']
            digest = next(change['sha256'] for change in changes if change['record_id'] == 'tla-5c6b8329390d241c')
            self.assertIn(digest, path.read_text())
            path.write_text(path.read_text().replace(digest, '0' * 64))
            completed = self.run_validator(root)
            self.assertNotEqual(completed.returncode, 0)
            self.assertIn('source-filename backfill tla-5c6b8329390d241c: active SHA256SUMS path/hash differs', completed.stdout)

    def test_source_filename_backfill_rejects_altered_receipt_or_observation(self) -> None:
        for relative, error in ((SOURCE_FILENAME_BACKFILL, 'source-filename backfill receipt SHA-256 differs'),
                                (SOURCE_FILENAME_OBSERVATIONS, 'source-filename backfill observation receipt differs')):
            with self.subTest(relative=relative), tempfile.TemporaryDirectory() as temp_dir:
                root = Path(temp_dir)
                self.copy_fixture(root)
                path = root / relative
                path.write_bytes(path.read_bytes() + b'\n')
                completed = self.run_validator(root)
                self.assertNotEqual(completed.returncode, 0)
                self.assertIn(error, completed.stdout)

    def test_registered_append_preserves_exact_metadata_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            before = (root / 'metadata.csv').read_bytes()
            completed = self.run_validator(root)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            self.assertEqual((root / 'metadata.csv').read_bytes(), before)
            self.assertEqual(json.loads(completed.stdout)['pinned_metadata_rows'], 549)

    def test_registered_append_does_not_exempt_existing_row_reordering(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            path = root / 'metadata.csv'
            fields, rows = read_csv_table(path)
            rows[0], rows[1] = rows[1], rows[0]
            write_csv_table(path, fields, rows)
            completed = self.run_validator(root)
        self.assertNotEqual(completed.returncode, 0)
        self.assertIn('rows are not sorted by file_name', completed.stdout)

    def test_unregistered_unsorted_addition_remains_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            path = root / 'metadata.csv'
            fields, rows = read_csv_table(path)
            addition = synthetic_metadata_row(rows[-1])
            addition['file_name'] = 'Standard_Time_Lapses/2026-10-24.2359.Pencil.Graphite.Paper.9x12.mp4'
            rows.append(addition)
            write_csv_table(path, fields, rows)
            completed = self.run_validator(root)
        self.assertNotEqual(completed.returncode, 0)
        self.assertIn('rows are not sorted by file_name', completed.stdout)

    def test_unsorted_append_requires_valid_registered_identity(self) -> None:
        insertion = Path('Standard_Time_Lapses/Provenance/Sequence_Insertions')
        for mutation in ('missing_registry', 'manifest_checksum', 'addition_identity'):
            with self.subTest(mutation=mutation), tempfile.TemporaryDirectory() as temp_dir:
                root = Path(temp_dir)
                self.copy_fixture(root)
                if mutation == 'missing_registry':
                    (root / insertion / 'registry.json').unlink()
                elif mutation == 'manifest_checksum':
                    path = root / insertion / '2026-10-29-F/sequence.json'
                    path.write_bytes(path.read_bytes() + b'\n')
                else:
                    path = root / 'metadata.csv'
                    fields, rows = read_csv_table(path)
                    next(row for row in rows if row['record_id'] == 'tla-f5575d594e459bfc')['hub_xet_hash'] = '0' * 64
                    write_csv_table(path, fields, rows)
                completed = self.run_validator(root)
                self.assertNotEqual(completed.returncode, 0)
                self.assertIn('rows are not sorted by file_name', completed.stdout)

    def test_current_repository_packet_passes(self) -> None:
        completed = self.run_validator(REPO_ROOT)
        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
        summary = json.loads(completed.stdout)
        self.assertEqual(summary["status"], "ok")
        self.assertEqual(summary["timing_rows"], 186)
        self.assertEqual(summary["documented_correction_rows"], 12)
        self.assertEqual(summary["post_snapshot_provenance_backfill_rows"], 12)
        self.assertEqual(summary["post_snapshot_media_backfill_rows"], 1)
        self.assertEqual(
            summary["active_corrected_finish_crosscheck"],
            {
                "fragment_set_label": (
                    "2026-09-01.1413.BallpointPen.Ink.Paper.9x12"
                ),
                "delta_seconds": 21.0,
                "status": "near_documented_finish_minute",
            },
        )

    def test_post_snapshot_provenance_backfill_drift_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-backfill-drift-") as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            metadata_path = root / "metadata.csv"
            fieldnames, rows = read_csv_table(metadata_path)
            target = next(
                row
                for row in rows
                if row["record_id"] == "tla-306b28137c489dcd"
            )
            self.assertEqual(target["evidence_method"], "commit_history")
            target["evidence_method"] = "manual_confirmation"
            write_csv_table(metadata_path, fieldnames, rows)
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(
            "post-snapshot provenance backfill tla-306b28137c489dcd: "
            "current metadata evidence_method differs",
            completed.stdout,
        )

    def test_correction_requires_exact_row_count_and_historical_ids(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-correction-count-") as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            correction_path = root / CORRECTION_RELATIVE
            fieldnames, rows = read_csv_table(correction_path)
            self.assertEqual(len(rows), 12)
            write_csv_table(correction_path, fieldnames, rows[:-1])
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn("expected 12 correction rows, found 11", completed.stdout)
        self.assertIn(
            "finish_time_correction.csv record IDs differ from the affected "
            "Sep-02 relationship rows",
            completed.stdout,
        )

    def test_correction_identity_tamper_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-correction-tamper-") as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            correction_path = root / CORRECTION_RELATIVE
            fieldnames, rows = read_csv_table(correction_path)
            rows[0]["sha256"] = "0" * 64
            write_csv_table(correction_path, fieldnames, rows)
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(
            "documented correction position 1: sha256 differs from Sep-02 relationship",
            completed.stdout,
        )

    def test_corrected_current_metadata_drift_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-corrected-drift-") as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            correction_path = root / CORRECTION_RELATIVE
            _, corrections = read_csv_table(correction_path)
            metadata_path = root / "metadata.csv"
            fieldnames, rows = read_csv_table(metadata_path)
            target = next(
                row for row in rows if row["record_id"] == corrections[0]["record_id"]
            )
            target["time"] = "14:12"
            write_csv_table(metadata_path, fieldnames, rows)
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(
            "documented correction position 1: current metadata time differs",
            completed.stdout,
        )

    def test_current_metadata_must_use_deterministic_lf_serialization(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-metadata-crlf-") as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            metadata_path = root / "metadata.csv"
            payload = metadata_path.read_bytes()
            self.assertNotIn(b"\r\n", payload)
            metadata_path.write_bytes(payload.replace(b"\n", b"\r\n"))
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(
            "metadata.csv is not deterministic UTF-8 CSV with LF line endings",
            completed.stdout,
        )

    def test_active_sha256sum_hash_tamper_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-sha-hash-") as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            _, corrections = read_csv_table(root / CORRECTION_RELATIVE)
            correction = corrections[0]
            manifest_path = root / "SHA256SUMS"
            lines = manifest_path.read_text(encoding="utf-8").splitlines()
            expected_suffix = f"  {correction['new_file_path']}"
            matches = [index for index, line in enumerate(lines) if line.endswith(expected_suffix)]
            self.assertEqual(len(matches), 1)
            lines[matches[0]] = f"{'0' * 64}{expected_suffix}"
            manifest_path.write_text(
                "\n".join(lines) + "\n", encoding="utf-8", newline="\n"
            )
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(
            "documented correction position 1: active SHA256SUMS path/hash differs",
            completed.stdout,
        )

    def test_old_path_must_be_absent_from_active_sha256sums(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-sha-old-path-") as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            _, corrections = read_csv_table(root / CORRECTION_RELATIVE)
            correction = corrections[0]
            manifest_path = root / "SHA256SUMS"
            with manifest_path.open("a", encoding="utf-8", newline="") as handle:
                handle.write(
                    f"{correction['sha256']}  {correction['old_file_path']}\n"
                )
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(
            "documented correction position 1: old path remains in active SHA256SUMS",
            completed.stdout,
        )

    def test_historical_relationship_packet_mutation_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-historical-packet-") as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            relationship_path = root / (
                "Standard_Time_Lapses/Provenance/2026-09-02/"
                "fragment_sequence_relationships.csv"
            )
            fieldnames, rows = read_csv_table(relationship_path)
            rows[0]["notes"] += " Synthetic historical mutation."
            write_csv_table(relationship_path, fieldnames, rows)
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(
            "relationship sidecar SHA-256 mismatch: "
            "Standard_Time_Lapses/Provenance/2026-09-02/"
            "fragment_sequence_relationships.csv",
            completed.stdout,
        )

    def test_undeclared_extra_metadata_column_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root=Path(temp_dir);self.copy_fixture(root)
            path=root/'metadata.csv';fields, rows=read_csv_table(path)
            fields.append('unregistered_field')
            for row in rows:row['unregistered_field']=''
            write_csv_table(path,fields,rows)
            completed=self.run_validator(root)
        self.assertNotEqual(completed.returncode,0)
        self.assertIn('original field count differs',completed.stdout)

    def test_pre_mode_metadata_still_reconstructs_the_exact_frozen_receipt(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            path = root / 'metadata.csv'
            fields, rows = read_csv_table(path)
            fields.remove('recording_mode')
            for row in rows:
                row.pop('recording_mode')
            write_csv_table(path, fields, rows)
            completed = self.run_validator(root)
        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
        self.assertEqual(json.loads(completed.stdout)['pinned_metadata_rows'], 549)

    def test_recording_mode_is_checked_on_historical_and_later_rows(self) -> None:
        for position in (0, -1):
            for mode in ('', 'real_time', 'unknown'):
                with self.subTest(position=position, mode=mode), tempfile.TemporaryDirectory() as temp_dir:
                    root = Path(temp_dir)
                    self.copy_fixture(root)
                    path = root / 'metadata.csv'
                    fields, rows = read_csv_table(path)
                    rows[position]['recording_mode'] = mode
                    write_csv_table(path, fields, rows)
                    completed = self.run_validator(root)
                    self.assertNotEqual(completed.returncode, 0)
                    self.assertIn('recording_mode must be time_lapse', completed.stdout)

    def test_duplicate_recording_mode_column_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            path = root / 'metadata.csv'
            fields, rows = read_csv_table(path)
            write_csv_table(path, fields + ['recording_mode'], rows)
            completed = self.run_validator(root)
        self.assertNotEqual(completed.returncode, 0)
        self.assertIn('recording_mode column must occur once', completed.stdout)

    def test_partial_timing_display_extension_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root=Path(temp_dir);self.copy_fixture(root)
            path=root/'metadata.csv';fields, rows=read_csv_table(path)
            fields.remove('recording_start_basis')
            for row in rows:row.pop('recording_start_basis')
            write_csv_table(path,fields,rows)
            completed=self.run_validator(root)
        self.assertNotEqual(completed.returncode,0)
        self.assertIn('incomplete timing display extension',completed.stdout)

    def test_unrelated_appended_metadata_row_is_accepted(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-append-") as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            metadata_path = root / "metadata.csv"
            fieldnames, rows = read_csv_table(metadata_path)
            addition = synthetic_metadata_row(rows[-1])
            self.assertNotIn(addition["record_id"], {row["record_id"] for row in rows})
            self.assertNotIn(addition["file_name"], {row["file_name"] for row in rows})
            self.assertTrue(metadata_path.read_bytes().endswith(b"\n"))
            with metadata_path.open("a", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(
                    handle, fieldnames=fieldnames, lineterminator="\n"
                )
                writer.writerow(addition)
            completed = self.run_validator(root)

        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
        summary = json.loads(completed.stdout)
        self.assertEqual(summary["status"], "ok")
        self.assertEqual(summary["timing_rows"], 186)
        self.assertEqual(summary["pinned_metadata_rows"], 549)
        self.assertEqual(summary["current_metadata_rows"], len(rows) + 1)
        self.assertEqual(
            summary["metadata_receipt_mode"],
            "inverse_documented_correction_and_post_snapshot_provenance_and_"
            "source_filename_backfills_exclude_verified_media_backfills_then_exact_pinned_snapshot",
        )

    def test_post_snapshot_media_backfill_identity_drift_is_rejected(self) -> None:
        for field, value in (
            ("file_name", "Standard_Time_Lapses/2026-08-20.other.mp4"),
            ("hub_xet_hash", "0" * 64),
            ("size_bytes", "1"),
            ("acquisition_protocol_version", "standard-2026-08-27"),
        ):
            with self.subTest(field=field), tempfile.TemporaryDirectory() as temp_dir:
                root = Path(temp_dir)
                self.copy_fixture(root)
                path = root / "metadata.csv"
                fields, rows = read_csv_table(path)
                target = next(row for row in rows if row["record_id"] == "tla-85cdf161df0b807e")
                target[field] = value
                rows.sort(key=lambda row: row["file_name"])
                write_csv_table(path, fields, rows)
                completed = self.run_validator(root)
                self.assertNotEqual(completed.returncode, 0)
                self.assertIn(f"post-snapshot media backfill tla-85cdf161df0b807e: current metadata {field} differs", completed.stdout)

    def test_post_snapshot_media_backfill_sha256_drift_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            path = root / "SHA256SUMS"
            text = path.read_text(encoding="utf-8")
            digest = "a9b9c6bb11c4da7d3a7e99ca72f86702999192b06009bccb447757a25ebbb074"
            self.assertIn(digest, text)
            path.write_text(text.replace(digest, "0" * 64), encoding="utf-8", newline="\n")
            completed = self.run_validator(root)
            self.assertNotEqual(completed.returncode, 0)
            self.assertIn("post-snapshot media backfill tla-85cdf161df0b807e: active SHA256SUMS path/hash differs", completed.stdout)

    def test_unregistered_historical_media_backfill_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            path = root / "metadata.csv"
            fields, rows = read_csv_table(path)
            addition = synthetic_metadata_row(rows[-1])
            addition["file_name"] = "Standard_Time_Lapses/2026-08-20.unknown.mp4"
            rows.append(addition)
            rows.sort(key=lambda row: row["file_name"])
            write_csv_table(path, fields, rows)
            completed = self.run_validator(root)
            self.assertNotEqual(completed.returncode, 0)
            self.assertIn("reconstructed pinned metadata snapshot differs", completed.stdout)

    def test_missing_covered_metadata_row_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-missing-covered-") as temp_dir:
            root = Path(temp_dir)
            timing_dir = self.copy_fixture(root)
            _, timing_rows = read_csv_table(timing_dir / "recording_timing.csv")
            covered_id = timing_rows[0]["record_id"]
            metadata_path = root / "metadata.csv"
            fieldnames, metadata_rows = read_csv_table(metadata_path)
            removed = [row for row in metadata_rows if row["record_id"] == covered_id]
            retained = [row for row in metadata_rows if row["record_id"] != covered_id]
            self.assertEqual(len(removed), 1)
            retained.append(synthetic_metadata_row(metadata_rows[-1]))
            self.assertEqual(len(retained), len(metadata_rows))
            write_csv_table(metadata_path, fieldnames, retained)
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(
            f"{covered_id}: record_id is absent from metadata.csv",
            completed.stdout,
        )

    def test_covered_metadata_identity_fields_are_immutable(self) -> None:
        cases = (
            (
                "record_id",
                "tla-0000000000000000",
                "record_id is absent from metadata.csv",
            ),
            (
                "file_name",
                "Standard_Time_Lapses/mutated-covered-row.mp4",
                "file_path differs from metadata.csv",
            ),
            ("hub_xet_hash", "0" * 64, "hub_xet_hash differs from metadata.csv"),
            ("date", "2099-01-01", "documented finish date differs from metadata.csv"),
            ("time", "00:00", "documented finish time differs from metadata.csv"),
        )
        for field, replacement, expected_error in cases:
            with self.subTest(field=field):
                with tempfile.TemporaryDirectory(
                    prefix=f"tla-timing-covered-{field}-"
                ) as temp_dir:
                    root = Path(temp_dir)
                    timing_dir = self.copy_fixture(root)
                    _, timing_rows = read_csv_table(timing_dir / "recording_timing.csv")
                    covered_id = timing_rows[0]["record_id"]
                    metadata_path = root / "metadata.csv"
                    fieldnames, metadata_rows = read_csv_table(metadata_path)
                    target = next(
                        row for row in metadata_rows if row["record_id"] == covered_id
                    )
                    self.assertNotEqual(target[field], replacement)
                    target[field] = replacement
                    write_csv_table(metadata_path, fieldnames, metadata_rows)
                    completed = self.run_validator(root)

                self.assertNotEqual(completed.returncode, 0)
                self.assertIn(
                    f"{covered_id}: {expected_error}",
                    completed.stdout,
                )

    def test_non_timing_historical_metadata_mutation_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-historical-") as temp_dir:
            root = Path(temp_dir)
            timing_dir = self.copy_fixture(root)
            _, timing_rows = read_csv_table(timing_dir / "recording_timing.csv")
            timing_ids = {row["record_id"] for row in timing_rows}
            metadata_path = root / "metadata.csv"
            fieldnames, metadata_rows = read_csv_table(metadata_path)
            target = next(
                row for row in metadata_rows if row["record_id"] not in timing_ids
            )
            target["notes"] += " Synthetic mutation."
            write_csv_table(metadata_path, fieldnames, metadata_rows)
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(
            "reconstructed pinned metadata snapshot differs from the source_manifest receipt",
            completed.stdout,
        )

    def test_appended_duplicate_identity_is_rejected(self) -> None:
        for field in ("record_id", "file_name", "hub_xet_hash"):
            with self.subTest(field=field):
                with tempfile.TemporaryDirectory(
                    prefix=f"tla-timing-duplicate-{field}-"
                ) as temp_dir:
                    root = Path(temp_dir)
                    self.copy_fixture(root)
                    metadata_path = root / "metadata.csv"
                    fieldnames, rows = read_csv_table(metadata_path)
                    duplicate = synthetic_metadata_row(rows[-1])
                    duplicate[field] = rows[0][field]
                    with metadata_path.open(
                        "a", encoding="utf-8", newline=""
                    ) as handle:
                        writer = csv.DictWriter(
                            handle, fieldnames=fieldnames, lineterminator="\n"
                        )
                        writer.writerow(duplicate)
                    completed = self.run_validator(root)

                self.assertNotEqual(completed.returncode, 0)
                self.assertIn(
                    f"metadata.csv {field} values must be nonblank and unique",
                    completed.stdout,
                )

    def test_appended_malformed_metadata_row_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-malformed-") as temp_dir:
            root = Path(temp_dir)
            self.copy_fixture(root)
            metadata_path = root / "metadata.csv"
            _, rows = read_csv_table(metadata_path)
            with metadata_path.open("a", encoding="utf-8", newline="") as handle:
                handle.write("bad,short,row\n")
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(
            f"metadata.csv row {len(rows) + 2} has malformed field width",
            completed.stdout,
        )

    def test_full_precision_metric_regression_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-metric-") as temp_dir:
            root = Path(temp_dir)
            timing_dir = self.copy_fixture(root)
            model_path = timing_dir / "calibration_model.json"
            model = json.loads(model_path.read_text(encoding="utf-8"))
            model["calibration"][
                "model_residual_seconds_observed_minus_estimated"
            ]["mean"] = 0.012227
            model_path.write_text(
                json.dumps(model, indent=2) + "\n", encoding="utf-8", newline="\n"
            )
            rewrite_bundle(timing_dir)
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn("calibration model residual metrics mean", completed.stdout)

    def test_frame_count_mutation_is_rejected_after_bundle_refresh(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-frame-") as temp_dir:
            root = Path(temp_dir)
            timing_dir = self.copy_fixture(root)
            timing_path = timing_dir / "recording_timing.csv"
            with timing_path.open("r", encoding="utf-8-sig", newline="") as handle:
                reader = csv.DictReader(handle)
                fieldnames = list(reader.fieldnames or [])
                rows = list(reader)
            calibrated = next(
                row for row in rows if row["timing_basis"] == "calibrated_frame_model"
            )
            calibrated["video_frame_count"] = str(
                int(calibrated["video_frame_count"]) + 30
            )
            with timing_path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
                writer.writeheader()
                writer.writerows(rows)
            rewrite_bundle(timing_dir)
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn("calibrated elapsed", completed.stdout)

    def test_bundle_path_traversal_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tla-timing-bundle-") as temp_dir:
            root = Path(temp_dir)
            timing_dir = self.copy_fixture(root)
            bundle = timing_dir / "bundle.sha256"
            bundle.write_text(
                bundle.read_text(encoding="utf-8")
                + f"{'0' * 64}  ../metadata.csv\n",
                encoding="utf-8",
                newline="\n",
            )
            completed = self.run_validator(root)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn("malformed entry", completed.stdout)

    def test_repository_validator_limits_are_explicit(self) -> None:
        summary_path = REPO_ROOT / TIMING_RELATIVE / "validation_summary.json"
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        self.assertEqual(
            summary["verification_level"], "repository_packet_self_consistency"
        )
        self.assertIn(
            "source-media tag and frame-count probing",
            summary["not_reperformed_by_repository_validator"],
        )
        self.assertIn(
            "NTFS timestamp observation",
            summary["not_reperformed_by_repository_validator"],
        )


if __name__ == "__main__":
    unittest.main()
