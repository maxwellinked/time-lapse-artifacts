# Schema

This document defines canonical filenames, the active video-object indexes,
and their relationship and timing sidecars. Filenames are human-readable
descriptions; `record_id` is the persistent identity of one published video
object. Archive-wide row counts are counts of indexed video files.

## Canonical Filename Format

`YYYY-MM-DD.HHMM.Tool.Medium.Support.Dimensions[.RecNN].ext`

Examples:

```text
2025-07-15.0448.FountainPen.Ink.Paper.9x12.mp4
2026-06-29.UnknownTime.FountainPen.Ink.IllustrationBoard.30x40.Rec11.mp4
2026-06-29.UnknownTime.FountainPen.Ink.IllustrationBoard.30x40.Rec12.mp4
```

### Filename fields

- `YYYY-MM-DD` — documented finish date.
- `HHMM` — documented finish time in 24-hour local civil time.
- `UnknownTime` — used when no reliable finish time is documented.
- `Tool` — drawing instrument, such as `Pencil`, `FountainPen`, `BallpointPen`,
  or `Brush`.
- `Medium` — applied material, such as `Graphite` or `Ink`.
- `Support` — drawing surface, such as `Paper`, `IllustrationBoard`, or
  `WatercolorPaper`.
- `Dimensions` — documented support-size text; order preserves the documented
  orientation, such as `9x12` or `12x9`. Units follow the applicable provenance
  declarations and qualifications described under **Support dimension units**.
- `RecNN` — optional file-order identifier used when documented order must be
  preserved or otherwise identical filenames require distinction.
  Numbering begins with `Rec01`. Historical numbering may continue across
  finish-date labels; the prospective protocol has the narrower timestamp rule
  defined below.
- `ext` — file extension.

### Filename rules

- Fields are separated by periods.
- Every tool listed in an active Standard metadata row must appear as one
  exact, case-sensitive filename token. Multiword tools remain one token, such
  as `BallpointPen` or `FountainPen`.
- Across both active tiers, every exact filename token in the documented tool
  vocabulary (`Pencil`, `FountainPen`, `BallpointPen`, and `Brush`) must appear
  in that row's metadata `tool` list. Historical Pre-Standard metadata may
  retain additional independently documented tools that are absent from a
  filename; a standalone historical `Pen` token is not normalized without
  separate documentation.
- Style and aesthetic classifications are excluded.
- `TL` is excluded because time-lapse is implicit in the primary collection.
- `0000` is reserved for a documented midnight finish time.
- `RecNN` specifies file order within a documented group only. It does not by
  itself establish a separate drawing, recording or session boundary, or
  completeness, and it does not reset merely because a historical documented
  finish-date label changes. Under
  `standard-2026-08-27`, all members of one documented prospective grouping
  instead share the grouping timestamp and `RecNN` records chronological
  file position within that group.
- `UnknownTime` records uncertainty; it is not replaced by an inferred time.
- Paper-surface variants such as `HotPress` and `ColdPress` may remain encoded
  in filenames until a dedicated metadata field is added.
- Historical relationships must not be inferred from filename similarity
  alone.
- Revision-pinned historical sidecars retain the path recorded at their source
  revision; an active filename correction does not rewrite that evidence.

Tool and medium tokens in a filename describe documented materials, but older
filenames do not always encode an unambiguous one-to-one pairing. Metadata must
therefore preserve tool and medium sets without manufacturing positional pairs.

## Registered sequence insertions (v1)

The ordinary dated `fragment_sequence_relationships.csv` contract remains
immutable: its `RecNN` suffix must equal its historical `sequence_position`.
A narrowly registered supplement can restore retained source files without
renaming or reidentifying previously published objects. Version 1 authorizes
only the F group `2026-10-25.0938.BallpointPen.Ink.Paper.9x12`, with `Rec03a` and
`Rec03b` inserted between the published `Rec03` and `Rec04`. Lettered suffixes
elsewhere remain invalid. These are persistent filename slots; the supplement's
explicit ordered `members` and contiguous `sequence_position` values define
current playback order. Consumers must use that order, not infer it from names.

The authoritative registry is
`Standard_Time_Lapses/Provenance/Sequence_Insertions/registry.json`. It contains
`schema_version: 1` and `sequences`, an array of `{manifest_path, sha256}` objects.
Each SHA-256 binds the exact referenced manifest bytes. Only one active successor
is allowed per group. The F manifest is
`Standard_Time_Lapses/Provenance/Sequence_Insertions/2026-10-29-F/sequence.json`.
Its required fields are:

- `schema_version`: integer `1`.
- `fragment_set_label`: the existing F label; no new work or sequence identity.
- `source_hub_revision`: immutable commit containing the metadata and media
  identities against which the supplement was validated. It can precede the
  commit publishing the supplement itself, avoiding a self-referential hash.
- `predecessor`: `{path, sha256, source_hub_revision}` binding the exact original
  dated packet at commit `4f563085afacfc454496ac2d61606614268b2cb8`. The packet's
  historical rows retain their original payload revision. This registered path
  and hash cannot be replaced by editing and rehashing the old receipt.
- `additions`: exactly the two new `record_id` strings in reviewed order.
- `members`: eleven ordered objects with `record_id`, `file_path`, ordinary
  `sha256`, `hub_xet_hash`, integer `size_bytes`, and integer `sequence_position`.
  All nine predecessor objects retain their IDs, paths, sizes, content identities,
  and relative order. The additions are the only new membership.
- `sequence_completeness`: `unknown`.
- `evidence`: `membership: owner-confirmed`,
  `order: visual-inference-with-device-metadata-corroboration`, and
  `gapless_capture: not-established`.
- `notes`: nonblank qualifications and source-coverage context.

Coverage of all eleven retained source recordings does not establish gapless
capture, recording/session boundaries, or complete observation of the drawing.
The shared finish label is still a drawing/group label, not a recording clock.
Blank `work_id` values remain blank; this supplement creates no work identity or
timing fit. Original packet and metadata notes describe the first release;
the registered supplement supplies current membership/order without rewriting
those historical statements.

Run `python tools/sequence_insertions.py --root . --metadata metadata.csv
--repo-inventory-json <inventory.json>` for strict validation. The inventory must
come from the declared immutable Hub commit and include actual media SHA-256,
Xet identities, sizes and revision receipts plus an exact-byte `metadata.csv`
receipt under `validationFiles`. A missing inventory cannot pass strict validation.
The metadata loader merges only structurally validated additions and keeps the
ordinary dated-packet duplicate-membership rule. Its local check alone is not
pinned-repository validation.

Before approved upload, use the explicit `--prepublication` mode. The local
candidate may retain `source_hub_revision: null` and `hub_xet_hash: null` only
for the two additions (blank Xet cells in candidate metadata); the nine original
objects must retain their real identities. Such output is reported as
`prepublication_unbound`, never as publishable data. Actual remote identities
and pinned metadata receipts must replace pending values before strict release
validation. No synthetic remote identity is permitted as a substitute.

### Bounded 2026-10-30 9x12 extension

The F registration and its historical requirements above remain unchanged.
Version 1 additionally registers exactly this path/label pair:

- Manifest: `Standard_Time_Lapses/Provenance/Sequence_Insertions/2026-10-30-9x12/sequence.json`.
- `fragment_set_label`: `2026-10-27.0100.Pencil.Graphite.FountainPen.Ink.Paper.9x12`.

This registration permits exactly one new `record_id`, at
`Standard_Time_Lapses/2026-10-27.0100.Pencil.Graphite.FountainPen.Ink.Paper.9x12.Rec03a.mp4`,
between the published `Rec03` and `Rec04`. Its eight ordered members preserve
all seven objects from the same immutable predecessor packet, retaining their
IDs, paths, sizes, content identities, and relative order. Only explicit
`sequence_position` values establish current playback order.

The evidence, notes, predecessor, registry hash, inventory binding, and
`sequence_completeness: unknown` requirements above apply. All member metadata
uses finish label date `2026-10-27`, time `01:00`, blank `work_id`, and protocol
`standard-2026-08-27`. In `--prepublication` mode, only this one addition may
have a null Xet identity and corresponding blank metadata cell; a null source
revision remains local preparation only. All seven predecessor identities
remain bound. This does not establish gapless capture, recording clocks,
session boundaries, or a work identity.

Only these two exact manifest path/label pairs are registered. A path from one
registration cannot authorize the other label, and no arbitrary lettered Rec
suffix, insertion group, or successor path is authorized. Strict validation
continues to require exact pinned inventories. The existing single-inventory
JSON input and its exact checks remain valid. The same CLI option additionally
accepts this explicit bundle:

```json
{
  "current_inventory": {"sha": "<current immutable revision>", "...": "..."},
  "inventories": [
    {
      "inventory": {"sha": "<manifest source revision>", "...": "..."},
      "metadata_path": "<absolute local path to exact source metadata.csv>"
    }
  ]
}
```

The illustrated inventory objects must contain the full captured inventory,
including `siblings` and `validationFiles`; the placeholders are not accepted
as receipts. Capture one source inventory and metadata snapshot for each unique
active `source_hub_revision`, plus a current inventory binding the CLI metadata
file and current media. Missing, duplicate, malformed, or mismatched source
entries fail. Source snapshot paths are explicit trusted local inputs.

For each active manifest, strict bundle validation first binds that manifest's
members and exact source metadata snapshot to its own immutable source
inventory. It also binds the current CLI metadata bytes and those same media
identities to `current_inventory`. Current metadata joins enforce all required
member fields. Thus the F manifest and its historical metadata receipt remain
unchanged, while a current pinned revision proves both groups' media and the
expanded current metadata. Neither an old receipt for different metadata bytes
nor a source-only inventory can authorize the current release.

## Canonical Metadata Contract

`metadata.csv` indexes the validated canonical subset of MP4 files stored
directly in `Standard_Time_Lapses/`. Direct placement alone does not make a file
canonical: every released canonical file must have exactly one metadata row,
complete required technical fields, and the necessary rights and provenance
clearance. Before publication, it must cover every MP4 stored directly in
`Standard_Time_Lapses/` at the exact reviewed revision.

Each metadata row and its `record_id` identify one published MP4 file. They do
not assert one drawing, one session, or one complete process. Documented
relationships among multiple video objects remain in sidecars and do not merge
or replace their `record_id` values.

Historical MP4 objects may represent one source recording or may combine
multiple recordings, including through InShot. That possibility is
record-specific; it does not mean every historical file is compiled. For the
documented `standard-2026-08-27` cohort, each canonical MP4 and metadata row
represents one unchanged source recording. Cohort membership is established by
the metadata protocol value and `record_id` membership in the revision-pinned
relationship packets, not by filename dates or a `RecNN` suffix alone. See the
prospective [`2026-08-27` packet](Standard_Time_Lapses/Provenance/2026-08-27/README.md)
and the separate
[June 18–30 historical relationship](Standard_Time_Lapses/Provenance/Historical_Relationships/2026-06-18--2026-06-30-fountain-pen-30x40.md).

The canonical index does not make provenance, unresolved, pre-standard, or
legacy files canonical.

### Identity and collection fields

| Field | Type | Meaning |
| --- | --- | --- |
| `file_name` | string | Repository-relative canonical video path. |
| `record_id` | string | Persistent identity in the form `tla-` plus 16 lowercase hexadecimal characters. |
| `work_id` | nullable string | Confirmed drawing identity, `tlaw-` plus 16 lowercase hexadecimal characters, copied from the authoritative work registry. Blank means unresolved. |
| `collection_tier` | enum | `standard` for this index. |
| `is_canonical` | boolean | `true` for every row in this index. |
| `acquisition_protocol_version` | enum | Governing Standard workflow: `standard-2025-07-13` for the earlier Standard workflow or `standard-2026-08-27` for canonical fragments reviewed into the prospective fragment-sequence workflow. Assignment is based on documented sidecar membership, not finish date or a `RecNN` suffix alone. |
| `recording_mode` | enum | Documented recording mode: `time_lapse` in the Standard and Pre-Standard indexes; `real_time` in the separate real-time index. Independent of acquisition protocol and encoded frame rate. |

The initial `record_id` values were generated from a namespaced SHA-256 of the
published repository path. Once assigned, the stored value is authoritative and
must be retained across filename corrections or tier changes. New tooling must
assign an ID only when a record does not already have one. When a genuinely new
record is promoted from a noncanonical holding, its ID is seeded from that
object's prior archival path; it must not inherit an ID already attached to a
different object at the corrected destination path.

### Pre-Standard collection contract

`Pre_Standard_Time_Lapses/metadata.csv` indexes the direct MP4 files in that
folder. Each row uses `collection_tier = pre_standard`, `is_canonical = false`,
and a blank `acquisition_protocol_version`. Pre-Standard status records a
different acquisition/documentation era; it does not remove the requirements
for stable identity, exact content hash and size, or encoded-stream metadata.

Dates, times, tools, media, support, and historical provenance may remain blank
when the surviving evidence is insufficient. Those blanks are historical
uncertainty, not failed technical ingestion.

### Recording mode and source authority

The two time-lapse indexes share a 36-field schema. `recording_mode` is appended
after the original 35 fields, with `time_lapse` on every current Standard and
Pre-Standard row. The separate
[`Real_Time_Recordings/metadata.csv`](Real_Time_Recordings/metadata.csv) appends
`recording_mode = real_time` to its original 23 fields. Collection membership
and its documented acquisition mode establish these values. Neither the file
extension nor encoded frame rate determines the mode.

Capture intervals, speed-up ratios and elapsed-time estimates are documented
through separate timing evidence. Matched MOV/time-lapse intervals can support
recording-specific timing and, with demonstrated applicability, estimates for
a defined cohort. Such estimates cite their reference evidence and uncertainty.
Existing candidate pairings retain their qualifications in the real-time index.
Session continuity, camera-original status and work identity retain their
separate evidence requirements. `acquisition_protocol_version` continues to
identify the Standard workflow; Pre-Standard protocol cells remain blank.

Recording facts and their field definitions are maintained in this Hugging Face
repository first. Native access tables and downstream GitHub browser views
project the source metadata at an explicit revision. A downstream view may
format labels and navigation, but must not originate or replace an archival
recording-mode, identity, timing, provenance, or relationship assertion.

Check the three source indexes with:

```sh
python tools/project_recording_modes.py --root .
```

The migration option `--write` appends an absent mode column using the documented
collection contracts and preserves every prior cell and row order. It rejects
explicit blank or conflicting mode values for review. Future ingests must
include the source field and pass this check before the workflow CSVs, native
Parquets, and downstream projections are refreshed. Historical revisions retain
their original schemas and validators.

### Confirmed drawing identity projection

Both active indexes include `work_id` immediately after `record_id`. The Viewer
declares it as `large_string`, with an empty CSV cell represented as null.
The 36-field schema retains every original field, the five timing-display
fields, and the explicit recording mode. `Work_Identity/works.csv` and `Work_Identity/work_record_links.csv` remain
the authoritative relationship source; the index column is a generated copy.
Join by exact `record_id` within the same repository revision.

Only positive, owner-confirmed links to active work IDs are projected. The
current 1,256 linked recordings share 435 active work IDs; 55 Standard and
128 Pre-Standard recordings have blank work IDs.
No IDs are minted, reassigned or inferred from dates, filenames, sequence
numbers, shared materials or appearance by this projection. A work ID does not
assert recording-set completeness, gapless capture, session boundaries or
physical-reference relationships. Different work IDs are not independently
verified negative pairs. See the [registry contract](Work_Identity/README.md)
for correction, retirement and supersession rules.

After an authorized registry update, rebuild the display column and validate:

```sh
python tools/project_work_ids.py --root . --write
python tools/project_work_ids.py --root .
python tools/project_recording_times.py --root .
```

The validator rejects duplicate or ambiguous links, inactive/missing work IDs,
unconfirmed links, unpinned source revisions, absent indexed records, malformed
rows and drift from the registry. It checks same-revision confirmation-file
checksums and the format of historical revision-pinned evidence references;
it does not repeat the historical source-media audit or refetch those URLs.
Both indexes and the registry are checked before either index is written.
Blank work IDs are valid and do not block ingestion. Historical source indexes
without this display column retain their original schema at their pinned revisions.

### Explicit timing display fields

The active indexes retain all original 29 columns and add the following five
string columns. These are a generated display projection, not a new timing
evidence source. Together with `work_id` and `recording_mode`, the Dataset Viewer
declares 36 columns for both tiers.

| Field | Meaning |
| --- | --- |
| `recording_start_local` | Reviewed device-filename start copied from the validated current timing view, including its explicit UTC offset. Blank if unknown or outside reviewed coverage. |
| `recording_start_basis` | `device_filename_interpreted_in_declared_timezone` or `unknown` for a covered record. The existing `not_in_timing_snapshot` value is retained for records outside this view's registered timing evidence at the selected repository revision. |
| `documented_finish_date` | Exact alias of the existing `date` value. |
| `documented_finish_time` | Exact alias of the existing `time` value. It is not a per-record stop time for prospective groups. |
| `finish_label_scope` | `complete_drawing_or_group` for `standard-2026-08-27`; `historical_scope_unspecified` for other surviving finish labels; `unknown` if both finish labels are blank. |

Recording starts are joined by `record_id` and checked against current paths,
byte lengths, SHA-256 and Xet identities. The
[Current recording-time view](Standard_Time_Lapses/Provenance/Recording_Timing_Current/README.md)
combines the unchanged Timing v2 snapshot with explicitly registered,
revision-bound ingest observations. It currently covers 841 recordings, with
607 filename-derived starts and 234 unknown starts; 636 of 1,477 indexed records
remain outside this view: 492 historical records, the 51 records in the
[October 23 ingest](Standard_Time_Lapses/Provenance/2026-10-23/README.md),
the 47 records in the [October 29 ingest](Standard_Time_Lapses/Provenance/2026-10-29/README.md),
and the two records in the [F restoration supplement](Standard_Time_Lapses/Provenance/Sequence_Insertions/2026-10-29-F/sequence.json), plus the six new Standard records in the joint movement cohort and the 38 originals in the [October 31 ingest](Standard_Time_Lapses/Provenance/2026-10-31/README.md).
The separate [wall-clock declaration ledger](Standard_Time_Lapses/Provenance/Wall_Clock_Declarations/README.md)
records the 106 earlier post-snapshot records as unresolved active candidates; it does not add supported
starts to this view. The October 31 cohort has no new filename-clock timezone declaration
or registered timing observations; its recording starts remain unknown.
New evidence does not rewrite frozen timing packets.
MP4 creation tags retain their creation/finalization meaning and are not
renamed as recording stops. Source filenames and media paths are unchanged.
The original 339 Timing v2 rows and their projected timing values are retained.

After an index update, rebuild the five display fields and then validate:

```sh
python tools/project_recording_times.py --root . --write
python tools/project_recording_times.py --root .
python tools/validate_recording_timing_v2.py --root .
```

The projection validator rejects missing columns, changed evidence values,
duplicate identities, mismatched source bindings and missing cohort records.
The metadata validator checks the current explicit source contract. Reproduce
historical inputs with the schema and validator at their pinned revision.

### Declared wall-clock provenance

The separate [declared wall-clock provenance layer](Standard_Time_Lapses/Provenance/Wall_Clock_Declarations/README.md)
and its [packet schema](Standard_Time_Lapses/Provenance/Wall_Clock_Declarations/SCHEMA.md)
define sealed candidate/event histories for `recording_start` only. Its
`timing_supported` status applies to that start declaration: filename-derived
starts are device-clock observations interpreted in declared timezones.
Creation tags retain their creation/finalization meaning. PTS, encoded duration,
frame counts and frame rate do not supply direct recording-start declarations
under this ledger contract. Separately supported
[elapsed-time models](Standard_Time_Lapses/Provenance/Recording_Timing/README.md)
retain their own evidence, applicability and uncertainty.

Active-ingest and historical-backfill coverage remain separate. Only cumulative
active unresolved coverage governs the greater-than-30% gate. Generated views
present registered evidence; the underlying source packets and ledger events
retain evidentiary authority. These views do not add stop or duration fields to
the source-index contract. Registered members remain immutable; later evidence
is recorded through additive events with exact prior-event references.

### Session and material fields

| Field | Type | Meaning |
| --- | --- | --- |
| `date` | `YYYY-MM-DD` | Documented finish date. For `standard-2026-08-27`, this is the finish date of the complete grouping/physical work shared by every member; earlier records retain their historically documented label. |
| `time` | `HH:MM` or blank | Documented finish time; blank means unknown. For `standard-2026-08-27`, this is the finish time of the complete grouping/physical work shared by every member. |
| `tool` | semicolon list | Ordered unique set of documented tools. |
| `medium` | semicolon list | Ordered unique set of documented media. |
| `support` | string | Physical drawing surface. |
| `dimensions` | string | Documented support-size text, such as `9x12`; see **Support dimension units** for unit authority and qualifications. |

### Support dimension units

Earlier records retain their published inches interpretation. For the 47 recordings
selected in the [October 29, 2026 ingest mapping](Standard_Time_Lapses/Provenance/2026-10-29/ingest_mapping.json),
the original [owner confirmation](Standard_Time_Lapses/Provenance/2026-10-29/owner_confirmation.json)
retains `dimension_unit: null`, reflecting the evidence available at ingest.
The later [owner unit confirmation](Standard_Time_Lapses/Provenance/Corrections/2026-10-29-support-dimension-units/owner_confirmation.json)
establishes that `9x12` means 9 × 12 inches for all nine reviewed groups A–I,
scoped by the 47 existing `record_id` values in that correction. Preserve the
published `9x12` dimension text and its documented order. This later declaration
does not alter the original receipt or establish units for records outside its
explicit scope.

Multiple values use semicolons:

```text
tool = Pencil;FountainPen
medium = Graphite;Ink
```

`tool` and `medium` are independent observed-value lists. Equal lengths and
positional correspondence are **not guaranteed**. Repeated media are collapsed
to one value. A future paired representation should use a structured field and
must be based on documented evidence rather than token position.

`date` and `time` preserve the best documented finish labels associated with a
row. For the earlier Standard workflow, the original 29-field schema does not
distinguish whether the source documentation scoped a label to an individual
recording, a recording session, a reviewed fragment sequence, or the physical
work. Equal values, differing values, and `RecNN` suffixes do not resolve that
historical scope. For `standard-2026-08-27`, the scope is explicit: every
`RecNN` member in one prospective grouping carries the documented finish date
and finish time of the complete grouping/physical work. The timestamp is not
the individual end time of each fragment; `RecNN` records chronological
position within the group.

### Encoded-video fields

| Field | Type | Meaning |
| --- | --- | --- |
| `duration_seconds` | float | Encoded playback duration. |
| `width_px` | integer | Stored encoded width. |
| `height_px` | integer | Stored encoded height. |
| `orientation` | enum | Stored pixel orientation derived from width and height. |
| `encoded_frame_rate` | float | Encoded playback frame rate as reported by the container; fractional values are allowed. |
| `video_codec` | string | Encoded video codec. |
| `pixel_format` | string | Encoded pixel format. |
| `container` | string | Media container. |
| `has_audio` | boolean | Whether the stored file contains an audio stream. |
| `hub_xet_hash` | string | Lowercase 64-character Xet file ID from the pinned Hub resolve response's `X-Xet-Hash` header. This is distinct from the LFS-compatible SHA-256. |
| `size_bytes` | integer | Stored file size in bytes. |

These fields describe the published encoded file. They do not establish the
original frame-capture interval, real drawing duration, speed-up factor, camera
calibration, capture orientation, rotation, crop, or transcode lineage.

Canonical status identifies the active representative of a Standard record; it
does not assert that the encoded file is an unaltered or full-duration capture
master. A shortened derivative may be canonical when it is the verified active
representative and its limitation is disclosed in `notes`.

`encoded_frame_rate`, including an encoded value of 30 fps, must not be
interpreted as the real capture interval or drawing-time sampling rate.

A matching ordinary SHA-256 establishes byte identity with the specific
comparison file. Direct-device or unchanged-source provenance additionally
requires evidence about that comparison file's origin. File size and container
or stream metadata may corroborate provenance, but they cannot independently
prove drawing membership, direct-device origin, or an untouched source. File
size alone also does not establish why one file is smaller than another; a
causal explanation requires supporting comparisons.

### Historical provenance fields

| Field | Type | Meaning |
| --- | --- | --- |
| `original_filename` | string or blank | Independently documented historical filename. |
| `provenance_status` | string or blank | Current relationship status. |
| `legacy_provenance_path` | string or blank | Verified historical repository path. |
| `legacy_related_references` | string or blank | Related candidates, aliases, or rejected references. |
| `evidence_method` | string or blank | Primary evidence used for the status. |
| `provenance_reference_duration_delta_seconds` | float or blank | Duration delta to a referenced historical file. |
| `notes` | string or blank | Human-readable evidence or qualification. |

Blank provenance values mean that the field is not documented or not
applicable in the active indexes. A blank must not be promoted to a verified
relationship.

The [November 1 source-filename backfill](Standard_Time_Lapses/Provenance/Corrections/2026-11-01-source-filenames/README.md)
fills exactly 168 previously blank `original_filename` cells from the literal
`source_filename` observations in the unchanged Timing v2 export. These are
retained local-ingest basenames; some already use the canonical naming convention.
They do not establish a device-original name, camera-original status, or any
recording clock, start or stop time. The SHA-bound correction receipt lists each
blank old value, exact new value and unchanged recording/media identity.

Observed provenance statuses include:

- `legacy_match_verified`
- `legacy_aliases_verified`
- `legacy_duplicate_removed`
- `legacy_candidates_rejected`
- `direct_root_upload`
- `tier_promotion_verified`

Observed evidence methods include:

- `blob_identity`
- `visual_continuity`
- `visual_comparison`
- `commit_history`
- `manual_confirmation`
- `blob_identity_and_physical_date`

New enumerated values must be documented here before use.

## Archive payload checksum manifest

The root `SHA256SUMS` file is the portable fixity index for published archival
payloads. It contains exactly one line for every repository path ending in
`.mp4` or `.zip`, sorted by repository-relative POSIX path:

```text
<64-character lowercase SHA-256><two spaces><repository-relative path>
```

Each digest is the ordinary byte-level SHA-256 of the represented file. It is
not encryption and is distinct from the `hub_xet_hash` Xet storage identity.
The LFS-compatible SHA-256 exposed by a pinned Hugging Face blob inventory is
the same portable content digest recorded in this manifest.

Documentation, scripts, CSV indexes, pointer files, and `SHA256SUMS` itself are
outside this payload manifest. Their versions remain bound by the repository
commit. Adding, deleting, renaming, or replacing an MP4 or ZIP requires updating
`SHA256SUMS` in the same review and validating it against the exact candidate
revision.

## Fragment-sequence relationship sidecar

Each revision-pinned packet
`Standard_Time_Lapses/Provenance/YYYY-MM-DD[.HHMM]/fragment_sequence_relationships.csv`
is a derived relationship table with one row per reviewed media object in that
ingestion. `YYYY-MM-DD` is used when one packet represents that calendar date;
an added `.HHMM` finish-label suffix disambiguates a later packet on the same
date without rewriting the earlier receipt. The suffix is a packet identifier,
not an individual recording end time. A bare-date packet may contain canonical
fragments and noncanonical derivatives under the existing placement rule; a
timestamp-qualified packet is currently restricted to canonical fragments.
This relationship table does not add sequence fields to either active video index.

| Field | Type | Meaning |
| --- | --- | --- |
| `fragment_set_label` | string | Descriptive canonical filename stem shared by one reviewed sequence; not a global `work_id`. |
| `object_role` | enum | `canonical_fragment` or `noncanonical_inshot_derivative`. |
| `record_id` | string or blank | Persistent canonical identity; required for canonical fragments and blank for noncanonical derivatives. |
| `file_path` | string | Unique repository-relative MP4 path. |
| `sha256` | string | Ordinary byte-level SHA-256 of the represented object. |
| `hub_xet_hash` | string | Hugging Face Xet identity at the pinned revision; distinct from ordinary SHA-256. |
| `size_bytes` | integer | Exact object size in bytes. |
| `sequence_position` | integer or blank | Contiguous one-based file position for a canonical fragment. |
| `sequence_count` | integer or blank | Total canonical fragment count for the sequence. |
| `sequence_completeness` | enum | Owner-reviewed completeness of the retained canonical source-file sequence; `owner_confirmed_complete` does not assert gapless capture, session completeness, or physical-work completeness. Derivative coverage remains separate. |
| `source_record_ids` | semicolon-delimited string or blank | Ordered canonical source IDs for a derivative; blank on canonical rows. |
| `derivative_coverage` | enum or blank | `complete_sequence` or `partial_sequence` for a derivative; blank on canonical rows. |
| `evidence_state` | semicolon-delimited string | Only evidence checks actually completed for the object and relationship. |
| `source_hub_revision` | string | Immutable 40-hex Hub commit that permits the canonical identity and path join to be checked. |
| `notes` | string or blank | Literal qualifications that do not belong in the categorical fields. |

Within each fragment set, canonical positions must be unique and contiguous
from one through `sequence_count`. A `complete_sequence` derivative must list
the full ordered canonical source sequence, and every derivative source must
belong to the same fragment set. Derivative rows and payloads remain outside
the canonical metadata and Viewer configurations even when stored in the
repository.

For canonical fragments governed by `standard-2026-08-27`, every member of a
`fragment_set_label` must have the same metadata `date` and `time`. Those values
document the finish of the complete grouping/physical work, not the individual
end time of each fragment. `sequence_position` and its matching `RecNN` suffix
carry chronological position.

Canonical-fragment evidence requires `owner-confirmed`, `checksum-computed`,
`media-probed`, `demux-verified`, and `sampled-decode-verified`.
`boundary-frame-verified` is included only when that separate visual check was
actually completed. Historical packets may additionally retain
`full-decode-verified` for a completed full-stream decode; this optional evidence
does not replace the required `sampled-decode-verified` check.

The registered `2026-10-30` packet for the five 11x14 recordings uses a
separate qualified-presentation profile. Its positions record reviewed
presentation order; capture chronology remains unestablished. The exact
evidence set is `owner-confirmed-grouping`, `checksum-computed`, `media-probed`,
`full-decode-verified`, and `order-inferred`. It requires the five registered
identities and paths, unknown completeness, blank work and recording-start
assignments, and the existing immutable metadata/media joins. The earlier
chronological-position and role-evidence rules remain unchanged for other packets.
Noncanonical-derivative evidence requires `sampled-frame-verified`,
`duration-arithmetic-verified`, `checksum-computed`, `media-probed`,
`demux-verified`, and `sampled-decode-verified`. Derivative
`sequence_position` is blank, `sequence_count` equals its canonical set size,
and any partial `source_record_ids` retain canonical sequence order.

`source_hub_revision` must be copied from an actual immutable remote commit; a
moving branch, placeholder, or inferred value is invalid. Remote inventory,
Xet-identity, and relationship-join validation must be completed against that
commit. The captured inventory also binds the exact bytes of that revision's
`metadata.csv`, so a local join cannot substitute metadata from a different
commit. The pinned receipt remains historical evidence and is not rewritten
when the active metadata later records a protocol boundary.

The canonical-fragment `record_id` values in the thirty-three packet sidecars
spanning thirty-one calendar dates (`2026-08-27`, `2026-08-29`, `2026-08-30`,
`2026-08-31`, `2026-09-01`, `2026-09-02`, `2026-09-14`, `2026-09-15`,
`2026-09-16`, the additional `2026-09-16.2043` packet, `2026-09-17`, and
`2026-09-18`, `2026-09-19`, `2026-09-20`, `2026-09-21`, `2026-09-22`,
`2026-09-23`, `2026-09-24`, `2026-09-25`, `2026-09-26`, the additional
`2026-09-26.1946` packet, `2026-09-27`, `2026-09-30`, `2026-10-01`, and `2026-10-02`, `2026-10-03`, `2026-10-04`, and `2026-10-05`, `2026-10-12`, `2026-10-13`, `2026-10-14`, `2026-10-15`, and `2026-10-16`) are the current membership authority for
`standard-2026-08-27`. Noncanonical derivative rows do not receive a canonical
protocol value. A dated sidecar does not introduce `work_id`, change any
`record_id`, or backfill unrelated historical rows. Consequently, an active
`RecNN` row absent from these dated sidecars retains
`standard-2025-07-13`; absence does not establish that no relationship exists.

## Active correction records

Focused corrections that change an active canonical path or documented finish
label without changing the represented media object are stored under
`Standard_Time_Lapses/Provenance/Corrections/`. They are separate from dated,
revision-pinned relationship packets and release receipts, whose bytes and
historical claims remain immutable.

The September 1 correction ledger is
`Corrections/2026-09-01.1413-finish-time/finish_time_correction.csv`:

| Field | Type | Meaning |
| --- | --- | --- |
| `record_id` | string | Persistent canonical identity; the active and historical rows must describe the same object. |
| `sequence_position` | integer | Original one-based position, retained unchanged. |
| `old_file_path` | string | Exact path in the pinned historical packets and metadata receipt. |
| `new_file_path` | string | Exact corrected path in the active metadata and payload manifest. |
| `old_finish_date` | `YYYY-MM-DD` | Historical documented finish date. |
| `old_finish_time` | `HH:MM` | Historical documented finish time. |
| `new_finish_date` | `YYYY-MM-DD` | Corrected active documented finish date. |
| `new_finish_time` | `HH:MM` | Corrected active documented finish time. |
| `sha256` | string | Unchanged ordinary byte-level media SHA-256. |
| `hub_xet_hash` | string | Unchanged Hub Xet identity. |
| `size_bytes` | integer | Unchanged media byte size. |
| `acquisition_protocol_version` | enum | Unchanged protocol assignment. |

Each row must map one unique `record_id`, old path, and new path. Validation
must require an exact active join on the new path/date/time and unchanged
identity fields; it must also require an exact historical join on the old
path/date/time at the pinned source revision. A correction ledger cannot add or
remove records, reorder a sequence, replace media, or rewrite historical
evidence.

When a fixed historical metadata receipt overlaps a later declared change,
receipt validation reconstructs the historical bytes by applying only the
exact documented inverses in memory. For timing v1 these are the 12-row
September 1 finish-time correction and the separate PR #67 provenance
classification backfill: exactly 12 named `record_id` values and exactly the
`provenance_status`, `evidence_method`, and `notes` fields populated by commit
`57a465ea69a4a6444e668f3267095a1b9fdfff6b` (merged as
`6758d92f07f233166a1fa8a5c04e46c6cd96382e`). The validator first requires
each active backfill value exactly, then reverses only those 36 cells in its
temporary copy. The reconstructed fixed rows must match the original receipt
exactly, and any later current rows must remain append-only. This is narrower
than accepting general edits to the historical prefix: an undeclared
difference, a changed identity field, or a mapping that does not round-trip is
an error.

The separate November 1 source-filename receipt additionally authorizes only
the 168 named `original_filename` cells. Its exact SHA-256 is pinned in the
timing-v1 validator. Before applying its blank-value inverse in memory, validation
binds the immutable Timing v2 observation and manifest bytes, exact literal
basenames, and all 168 current record IDs, paths, ordinary SHA-256 values, Xet
identities and byte sizes. Only 164 of these rows occur in the original 549-row
snapshot; the four later rows receive the same checks. No other field is
excluded from the original exact-byte snapshot reconstruction. Frozen timing
packets and their original metadata receipts remain unchanged.

## Recording-timing sidecar

`Standard_Time_Lapses/Provenance/Recording_Timing/recording_timing.csv` is an
exploratory derived table for the 186 canonical fragments in the six fixed
timing-v1 source sidecars dated `2026-08-27` through `2026-09-02`. It joins to the canonical Standard index on `record_id`
and declares the exact source Hub revision. It is outside both active video
indexes and does not add or replace canonical metadata fields.

Timing v1's source revision, packet bytes, and 186-row membership are fixed.
Current metadata compatibility is established by exact inverse reconstruction
of the 12 documented September 1 path/time corrections plus the exact
12-record, 36-cell PR #67 provenance backfill to the historical 549-row
receipt after excluding the named timing-display and `work_id` projections,
followed by append-only rows in the original 29-field schema.
Those appended rows must pass the canonical metadata validator and remain
outside timing coverage until a separately reviewed, versioned timing layer
includes them.

The sidecar keeps three timing concepts separate:

- `device_filename_start_local` is present only when a retained
  `VID_YYYYMMDD_HHMMSS.mp4` source name supplies a whole-second timestamp
  interpreted as recording start.
- `format_creation_time_utc` and `video_creation_time_utc` preserve literal MP4
  tags treated as the best-supported file-finalization boundary, not a
  universally guaranteed stop time.
- `capture_start_time_utc` and `recording_elapsed_seconds` are direct for 22
  rows and profile-specific model estimates for 164 rows, as declared by
  `timing_basis`, `calibration_profile_status`, and `timing_model_id`.

Canonical `date` and `time` remain documented group-finish labels. They are not
overwritten by sidecar starts or MP4 boundaries. The model has no independent
holdout; its allowances are operational review thresholds, not proven error
bounds. The sidecar does not establish drawing-active time, continuous work,
source-frame timestamps, pen contact, or physical motion. Its complete field
and auxiliary-file contracts are defined in
[`Recording_Timing/SCHEMA.md`](Standard_Time_Lapses/Provenance/Recording_Timing/SCHEMA.md).

## Work-image layer

`Work_Images/manifest.csv` is the canonical work-level image ledger. It is
additive and independent of the historical physical-reference sidecars.

| Role | Cardinality and meaning |
| --- | --- |
| `high_res_primary` | Zero or one active authority-selected high-resolution reference image per active `work_id`. This is a selection role, not a general qualification for research use. |
| `low_res_display` | Zero or one active browser derivative whose `derived_from_sha256` is the exact active primary. |
| `supplemental` | Reserved non-primary work view; absent from schema v1 ingest. |
| `process` | Reserved non-primary process image; absent from schema v1 ingest. |

The full asset, authority-event, repository-event, receipt, derivation, path,
identifier, and append-only supersession contracts are defined in
[`Work_Images/SCHEMA.md`](Work_Images/SCHEMA.md). Recording linkage is always
derived through `work_id`; the layer contains no per-record authority rows and
makes no recording endpoint, timing, completeness, finish-state, or
frame-alignment claim. Historical `Physical_References` objects and relationship
states are not rewritten when a work image is selected.

## Physical-reference sidecar

`Physical_References/endpoint_references.csv` is an optional derived
relationship table joined to the canonical Standard index on `record_id`. It
must declare the exact `source_hub_revision`; it does not determine canonical
video status or duplicate editable video metadata.

Each row has a stable `reference_id`, reviewed photograph filename and role,
explicit surface and temporal scope, evidence state, hash state, and machine-use
caution. Blank values mean unknown or not documented. Reference-media
availability must be explicit, and blank proposed-path fields must not be
interpreted as public media locations.

`longitudinal_continuation` identifies a later or otherwise changed physical
state and is not an exact endpoint target. Two-sided references preserve
side-specific evidence and do not imply one shared visual target. Validators
must require unique identities, canonical filename agreement at the pinned
revision, allowed relationship values, explicit owner-confirmation state, and
valid SHA-256 syntax whenever a hash is present. The complete contract is in
[`Physical_References/SCHEMA.md`](Physical_References/SCHEMA.md).

## Missing-Value Rules

- Blank means unknown, not documented, or not applicable according to the field
  description.
- Blank numeric values must remain blank; they are not zero.
- Blank booleans must remain blank; they are not `false`.
- Uncertain dates and times must not be reconstructed from unsupported clues.
- Pre-Standard descriptive/provenance metadata may be less complete, but every
  published record must carry a collection-tier distinction, stable ID, exact
  content identity, and complete core encoded-video metadata.

## Required Validation

Before publication, the validator must confirm:

- unique `record_id`, `file_name`, and nonblank `hub_xet_hash`
- canonical paths remain directly under `Standard_Time_Lapses/`
- one consistent semicolon convention for multi-value fields
- valid dates, times, and dimensions
- complete core encoded-video metadata for every active Standard and
  Pre-Standard row
- orientation agrees with stored width and height
- canonical metadata paths match the canonical Viewer records
- every active standard and pre-standard metadata path resolves to a published
  repository file
- repository media absent from an active index is reported explicitly rather
  than silently treated as released data
- material lacking the necessary ownership or provenance clearance is absent
  from both active indexes
- fragment-sequence positions are contiguous and complete-sequence derivative
  source lists exactly match their own ordered fragment set
- `standard-2026-08-27` appears on exactly the canonical-fragment IDs in the
  supplied dated sidecars, every other Standard row remains
  `standard-2025-07-13`, and each prospective group shares one finish timestamp
- noncanonical derivative payloads remain absent from both active indexes and
  Viewer configurations
- relationship paths, Xet identities, sizes, and canonical `record_id` joins
  resolve at the exact declared `source_hub_revision`
- every work-image row resolves to an active work, satisfies per-role active
  cardinality, and matches its full hash, content-addressed path, byte size,
  dimensions, normalized orientation, ICC identity, authority and lineage
  receipt; every display resolves to the exact active primary and remains at
  most 1024 pixels on its long edge and 512 KiB
- recording-timing identities, direct timestamp arithmetic, calibration
  formulas, sequence chronology, retained historical conflicts, correction
  round-trips, unchanged media identities, and bundle hashes resolve at the
  exact declared source revision and current active index
- `SHA256SUMS` exactly covers every published MP4 and ZIP at the reviewed
  revision, with no missing, extra, duplicate, or mismatched entries

Run:

```bash
python tools/validate_metadata.py metadata.csv \
  --pre-standard-metadata Pre_Standard_Time_Lapses/metadata.csv \
  --fragment-relationships-root Standard_Time_Lapses/Provenance

python tools/validate_sha256sums.py SHA256SUMS \
  --repo-json repo_api_blobs.json \
  --revision "<40-hex-commit>"

python tools/validate_recording_timing.py --root .
```

## Uniform current media names

The existing readable Standard/Pre-Standard convention above stays valid. Other currently published media follow [Media_Naming/policy.json](Media_Naming/policy.json): documented date/time context, explicit media role, qualified candidate/relationship state where documented, recording number when known, stable ID, sequence suffix and content-hash prefix. A work with multiple documented finish labels uses an explicit date range and `MultipleTimes`; missing facts use `UnknownDate`/`UnknownTime`. Photograph and MOV names never assert inferred capture times.

The immutable-base relocation map preserves all record/work/asset IDs, original/source filename values, SHA-256, sizes, encoded bytes, memberships and timing claims. Current CSV/JSON path fields expose new paths directly. SHA-bound alias resolution projects historical receipts at read time; it does not rewrite their evidence or pinned historical URLs. Native Video and Image tables advance current access cells at an explicit source revision, preserving schemas, row identities and embedded image bytes. See [the migration contract](Media_Naming/README.md).

## Current photograph selection authority

The [work-level selected-front registry](Physical_References/Selected_Front_Downloads/selections.json)
is authoritative for current photo choices. Its [schema](Physical_References/Selected_Front_Downloads/SCHEMA.md)
separates selected source, downloadable JPEG, bounded display and optional
Work_Images roles. Work/recording tables are generated projections. Recording
identities, confirmed membership, true nulls and historical evidence
qualifications retain their existing meanings.

