Prepared metadata enrichment — NOT PUBLISHED

Exactly 168 blank Standard original_filename cells are filled from literal source_filename values already published in frozen Recording_Timing_v2/observations.json. These are documented historical local-ingest basenames. They do not establish device-original filenames, camera-original status, or recording clocks.

Only those 168 canonical cells change. Every other canonical cell, row order, record identity, checksum and media byte remains unchanged. Forty-five original filenames and the 37 Standard finish times remain unknown. No further work-identity or recording-start fills were supported by the inspected evidence.

Source baseline: fcbe6277ca34c6a5dd4a15d82e4f0654b46ffbee
Local source candidate: d0510b7df4afee331d0b34ff5377d470e7b9cd1a
Candidate metadata SHA-256: 3cbe9190b60cb15ced35ca5f1ffa123a3f4560d8f0b96dc4881b55ead33bce07
Correction receipt SHA-256: a3e73cc220f99e049559ead64ca8559d27751eb35b859c0bc13f933ae03116e9

Publication status
Hugging Face rejected direct commit and PR creation with HTTP 403. Its main branch remains at the baseline. No Hugging Face PR was created. The GitHub main branch and live website are unchanged. All current browser metadata fields match the candidate source; original_filename is outside the browser's current field projection.

Contents
- metadata-fills.csv: the 168 exact proposed values, record IDs and evidence audit IDs.
- source.patch: the complete authoritative source patch, including metadata, generated workflow CSV, documentation, receipt and validator regression tests.
- source-files/: the same eight complete source files.
- files.json: their SHA-256 bindings.
- native-preview/: regenerated native tables for local review, pinned to the unpublished local candidate above. The publication helper regenerates these with the actual published source revision.
- validation/: test and generation results, including the complete broader-suite failure log.
- publish.py: validates/installs the prepared source files; --publish performs guarded source and table publication using a write-capable Hugging Face login.

Validation
- Exact cell comparison: 168 blank-to-literal-name changes across 1,349 rows; every other cell and row position retained.
- All 168 media SHA-256 and byte lengths match the immutable baseline Hub inventory.
- Canonical metadata, timing v1/v2/current validators passed.
- 60 timing tests passed, including evidence, receipt, identity, unrelated-cell and wrong-filename mutation rejection.
- Native tables passed exact cell/schema/null/order checks and decode-disabled loading.
- Browser: 211 tests passed; site validator passed; all 1,349 exposed records match candidate source values.
- Full source suite: 419 tests, 7 failures and 1 error. One existing README assertion fails (test_card_preserves_archive_origin_semantics). Seven Work_Images cases cannot exercise their intended checks because this lightweight checkout retains image LFS pointers: test_repository_layer_passes (error), test_endpoint_claim_is_rejected, test_external_parent_path_mismatch_is_rejected, test_missing_primary_derivation_is_rejected, test_package_invariant_drift_is_rejected, test_receipt_geometry_drift_is_rejected, test_recipe_tamper_is_rejected. Their code and image files were unchanged. Full log included.
- Handoff helper validation was run against a separate clean baseline checkout and passed without publishing.

To publish
Use a clean Git clone at the exact baseline and a Hugging Face credential with repository write access. Keep credentials out of chat and source files. The helper stops if the source branch has advanced; review against the new source before proceeding.

Dependencies tested:
  huggingface_hub
  pyarrow==24.0.0
  PyYAML
  Pillow==12.2.0
  datasets==4.8.5

Example, from this extracted folder:
  GIT_LFS_SKIP_SMUDGE=1 git clone https://huggingface.co/datasets/maxwellinked/time-lapse-artifacts hf-checkout
  git -C hf-checkout checkout fcbe6277ca34c6a5dd4a15d82e4f0654b46ffbee
  python publish.py --source-root hf-checkout --publish

Without --publish, the helper installs and validates the prepared source files locally. For a later publish run, start from a fresh clean baseline checkout. The publish path first commits source metadata with a guarded parent, then rebuilds and publishes the five native artifacts at the actual source revision and checks every uploaded file hash. It downloads the existing paired table if its LFS body is needed; it does not read original video payloads.
